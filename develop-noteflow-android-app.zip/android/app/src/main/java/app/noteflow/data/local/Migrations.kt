package app.noteflow.data.local

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Database migrations.
 *
 * Version 1 is the first published schema, so [ALL] is empty today. The pattern below is the
 * template to follow for every future change — copy it, bump [NoteFlowDatabase.VERSION],
 * and add the new migration to [ALL]. Room's exported JSON schemas (app/schemas) let
 * `MigrationTestHelper` verify each step in an instrumented test.
 *
 * Rules that keep user data safe:
 *  1. Never use fallbackToDestructiveMigration().
 *  2. Only additive changes when possible (ADD COLUMN with a default).
 *  3. For table rewrites: create new table -> copy rows -> drop old -> rename.
 */
object Migrations {

    /** Example of the exact shape a future migration must take (kept for reference only). */
    @Suppress("unused")
    val EXAMPLE_1_2 = Migration(1, 2) { db: SupportSQLiteDatabase ->
        db.execSQL("ALTER TABLE notes ADD COLUMN reminderAt INTEGER")
    }

    val ALL: Array<Migration> = arrayOf()
}
