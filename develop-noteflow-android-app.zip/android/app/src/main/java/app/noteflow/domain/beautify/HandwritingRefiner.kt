package app.noteflow.domain.beautify

import app.noteflow.domain.model.STRIDE
import app.noteflow.domain.model.Stroke
import app.noteflow.ink.StrokeSmoother
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.tan

/**
 * "Tidy handwriting" — HONEST SCOPE STATEMENT
 * ============================================
 * This is **geometric stroke refinement**, not a neural handwriting-generation model.
 * It never changes what you wrote: every original stroke keeps its identity, its order and
 * its point count order; only the coordinates are nudged. Words, maths and diagrams survive
 * because nothing is recognised, re-typed or re-synthesised.
 *
 * What it actually does, in this order:
 *   1. Re-fits each stroke to a Catmull-Rom spline (removes tremor and digitiser noise).
 *   2. Groups strokes into text lines by vertical overlap.
 *   3. Estimates each line's baseline and x-height, then gently aligns strokes to a common
 *      baseline and equalises letter height within a line (strength controlled by `neatness`).
 *   4. Optionally normalises slant, so inconsistent italic drift becomes consistent.
 *   5. Optionally equalises spacing between strokes on a line.
 *
 * Why not a real AI model (checked, documented, not invented):
 *   - Offline handwriting *generation* models that preserve arbitrary content are research
 *     code (e.g. diffusion/RNN handwriting synthesis). Running one on a phone would need a
 *     converted model of hundreds of MB and typically ≥2 GB RAM, with non-commercial or
 *     unclear licences for the pretrained weights.
 *   - A handwriting→text→font pipeline is NOT handwriting beautification; if NoteFlow ever
 *     ships it, it will be labelled "Convert to typed text", which is exactly what it is.
 *   - So the shipped feature is deliberately named "Tidy handwriting (geometric)" in the UI.
 *     No model is downloaded, no server is contacted, no permission is needed.
 *
 * The caller (editor view-model) always keeps the original strokes for preview / reject /
 * undo — see EditorViewModel.beautifyPreview / acceptBeautify / rejectBeautify.
 */
object HandwritingRefiner {

    data class Options(
        /** 0 = barely touch it, 1 = maximum tidy. */
        val neatness: Float = 0.6f,
        val alignBaselines: Boolean = true,
        val equaliseHeight: Boolean = true,
        val normaliseSlant: Boolean = false,
        val equaliseSpacing: Boolean = false
    )

    data class LineGroup(val strokes: List<Stroke>, val baseline: Float, val xHeight: Float)

    fun refine(strokes: List<Stroke>, options: Options): List<Stroke> {
        if (strokes.isEmpty()) return emptyList()
        val k = options.neatness.coerceIn(0f, 1f)

        // 1. de-noise every stroke
        var work = strokes.map { s ->
            val (pts, count) = StrokeSmoother.resampleCatmullRom(s.points, s.pointCount, spacing = 1.0f + 0.8f * k)
            s.copy(points = pts, pointCount = count).also { it.recomputeBounds() }
        }

        // 2. group into lines
        val lines = groupIntoLines(work)

        // 3..5 per line adjustments
        val result = ArrayList<Stroke>(work.size)
        for (line in lines) {
            var lineStrokes = line.strokes
            if (options.alignBaselines) lineStrokes = alignBaselines(lineStrokes, line.baseline, k)
            if (options.equaliseHeight) lineStrokes = equaliseHeights(lineStrokes, line.xHeight, k * 0.7f)
            if (options.normaliseSlant) lineStrokes = normaliseSlant(lineStrokes, line.baseline, k)
            if (options.equaliseSpacing) lineStrokes = equaliseSpacing(lineStrokes, k * 0.5f)
            result += lineStrokes
        }
        work = result
        return work
    }

    /** Strokes whose vertical ranges overlap are treated as one written line. */
    fun groupIntoLines(strokes: List<Stroke>): List<LineGroup> {
        if (strokes.isEmpty()) return emptyList()
        val sorted = strokes.sortedBy { (it.minY + it.maxY) / 2f }
        val groups = mutableListOf<MutableList<Stroke>>()
        for (s in sorted) {
            val centre = (s.minY + s.maxY) / 2f
            val group = groups.lastOrNull()
            val fits = group != null && group.any { other ->
                val oCentre = (other.minY + other.maxY) / 2f
                val tolerance = ((other.maxY - other.minY) + (s.maxY - s.minY)) * 0.4f + 6f
                abs(centre - oCentre) < tolerance
            }
            if (fits) group!!.add(s) else groups.add(mutableListOf(s))
        }
        return groups.map { group ->
            val baseline = group.map { it.maxY }.sorted().let { it[it.size / 2] }   // median bottom
            val heights = group.map { it.maxY - it.minY }.sorted()
            val xHeight = heights[heights.size / 2].coerceAtLeast(1f)
            LineGroup(group.sortedBy { it.minX }, baseline, xHeight)
        }
    }

    private fun alignBaselines(strokes: List<Stroke>, baseline: Float, k: Float): List<Stroke> =
        strokes.map { s ->
            // Only pull strokes that sit close to the baseline (ignore descenders like g, y, p).
            val delta = baseline - s.maxY
            val height = (s.maxY - s.minY).coerceAtLeast(1f)
            if (abs(delta) > height * 0.6f) s else s.translated(0f, delta * k)
        }

    private fun equaliseHeights(strokes: List<Stroke>, target: Float, k: Float): List<Stroke> =
        strokes.map { s ->
            val h = (s.maxY - s.minY).coerceAtLeast(0.5f)
            val ratio = target / h
            // Never resize by more than ±25 % — big letters (capitals) must stay big.
            val clamped = ratio.coerceIn(0.8f, 1.25f)
            val factor = 1f + (clamped - 1f) * k
            if (abs(factor - 1f) < 0.01f) return@map s
            val anchorY = s.maxY
            val anchorX = (s.minX + s.maxX) / 2f
            val m = floatArrayOf(factor, 0f, anchorX - factor * anchorX, 0f, factor, anchorY - factor * anchorY)
            s.transformed(m, 1f)
        }

    /** Shears strokes so every letter leans by the line's median slant. */
    private fun normaliseSlant(strokes: List<Stroke>, baseline: Float, k: Float): List<Stroke> {
        val slants = strokes.mapNotNull { estimateSlant(it) }
        if (slants.isEmpty()) return strokes
        val median = slants.sorted()[slants.size / 2]
        return strokes.map { s ->
            val own = estimateSlant(s) ?: return@map s
            val correction = (median - own) * k
            if (abs(correction) < 0.02f) return@map s
            val shear = tan(correction.toDouble()).toFloat()
            val pts = s.points.copyOf()
            for (i in 0 until s.pointCount) {
                val y = pts[i * STRIDE + 1]
                pts[i * STRIDE] += (baseline - y) * shear
            }
            s.copy(points = pts).also { it.recomputeBounds() }
        }
    }

    /** Dominant direction of the stroke's "vertical" movement, in radians from vertical. */
    private fun estimateSlant(stroke: Stroke): Float? {
        if (stroke.pointCount < 4) return null
        var sumX = 0f
        var sumY = 0f
        for (i in 0 until stroke.pointCount - 1) {
            val dx = stroke.x(i + 1) - stroke.x(i)
            val dy = stroke.y(i + 1) - stroke.y(i)
            if (abs(dy) > abs(dx)) { sumX += dx; sumY += dy }
        }
        if (abs(sumY) < 1f) return null
        return kotlin.math.atan2(sumX, -sumY)
    }

    /** Evens out the horizontal gaps between consecutive strokes on a line. */
    private fun equaliseSpacing(strokes: List<Stroke>, k: Float): List<Stroke> {
        if (strokes.size < 3) return strokes
        val gaps = (0 until strokes.size - 1).map { strokes[it + 1].minX - strokes[it].maxX }
        val positive = gaps.filter { it > 0 }
        if (positive.isEmpty()) return strokes
        val target = positive.sorted()[positive.size / 2]
        var shift = 0f
        return strokes.mapIndexed { index, s ->
            val moved = if (index == 0) s else s.translated(shift, 0f)
            if (index < strokes.size - 1) {
                val gap = gaps[index]
                if (gap > 0) shift += (target - gap) * k
            }
            moved
        }
    }

    /** Human-readable description shown in the preview sheet, so nothing is over-promised. */
    fun describe(options: Options): String = buildString {
        append("Geometric tidy at ")
        append((options.neatness * 100).roundToInt())
        append("% strength: smoothing")
        if (options.alignBaselines) append(", baseline alignment")
        if (options.equaliseHeight) append(", height evening")
        if (options.normaliseSlant) append(", slant normalisation")
        if (options.equaliseSpacing) append(", spacing evening")
        append(". Your words are never re-generated or re-typed.")
    }
}
