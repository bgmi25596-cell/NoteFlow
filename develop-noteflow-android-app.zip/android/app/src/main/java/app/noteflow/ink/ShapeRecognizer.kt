package app.noteflow.ink

import app.noteflow.domain.model.InkBrush
import app.noteflow.domain.model.STRIDE
import app.noteflow.domain.model.Stroke
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Geometry clean-up ("snap to shape").
 *
 * Pure maths, no model, no network. It inspects the just-finished stroke and, if it is
 * confidently a line / arrow / rectangle / triangle / ellipse, returns an idealised stroke
 * made of real ink points (still fully editable vector data — nothing becomes an image).
 *
 * Returns null when it is not confident, so normal handwriting is never "corrected".
 */
object ShapeRecognizer {

    enum class Shape { LINE, ARROW, RECTANGLE, TRIANGLE, ELLIPSE }

    data class Result(val shape: Shape, val stroke: Stroke)

    fun recognize(stroke: Stroke, enabled: Set<Shape> = Shape.entries.toSet()): Result? {
        val n = stroke.pointCount
        if (n < 8) return null

        val w = stroke.maxX - stroke.minX
        val h = stroke.maxY - stroke.minY
        val diag = hypot(w, h)
        if (diag < 24f) return null // too small to be an intentional shape

        var pathLen = 0f
        for (i in 0 until n - 1) pathLen += hypot(stroke.x(i + 1) - stroke.x(i), stroke.y(i + 1) - stroke.y(i))
        if (pathLen < 1f) return null

        val startEnd = hypot(stroke.x(n - 1) - stroke.x(0), stroke.y(n - 1) - stroke.y(0))
        val closed = startEnd < diag * 0.25f

        // --- straight line / arrow ---
        if (!closed && pathLen / startEnd < 1.12f && Shape.LINE in enabled) {
            val head = arrowHead(stroke)
            return if (head != null && Shape.ARROW in enabled) {
                Result(Shape.ARROW, buildArrow(stroke, head))
            } else {
                Result(Shape.LINE, build(stroke, listOf(stroke.x(0) to stroke.y(0), stroke.x(n - 1) to stroke.y(n - 1))))
            }
        }

        if (!closed) return null

        // --- closed shapes: compare against ideal circle and ideal rectangle ---
        val cx = (stroke.minX + stroke.maxX) / 2f
        val cy = (stroke.minY + stroke.maxY) / 2f
        val rx = w / 2f
        val ry = h / 2f

        var circleErr = 0f
        for (i in 0 until n) {
            val dx = (stroke.x(i) - cx) / rx.coerceAtLeast(0.01f)
            val dy = (stroke.y(i) - cy) / ry.coerceAtLeast(0.01f)
            circleErr += abs(hypot(dx, dy) - 1f)
        }
        circleErr /= n

        val perimeterRect = 2 * (w + h)
        val rectErr = abs(pathLen - perimeterRect) / perimeterRect
        val corners = countCorners(stroke)

        return when {
            circleErr < 0.12f && corners <= 1 && Shape.ELLIPSE in enabled ->
                Result(Shape.ELLIPSE, build(stroke, ellipsePoints(cx, cy, rx, ry)))
            corners == 3 && Shape.TRIANGLE in enabled ->
                Result(Shape.TRIANGLE, build(stroke, trianglePoints(stroke)))
            rectErr < 0.22f && corners in 3..5 && Shape.RECTANGLE in enabled ->
                Result(Shape.RECTANGLE, build(stroke, listOf(
                    stroke.minX to stroke.minY, stroke.maxX to stroke.minY,
                    stroke.maxX to stroke.maxY, stroke.minX to stroke.maxY,
                    stroke.minX to stroke.minY
                )))
            else -> null
        }
    }

    private fun countCorners(stroke: Stroke): Int {
        val n = stroke.pointCount
        val step = (n / 24).coerceAtLeast(1)
        var corners = 0
        var i = step
        while (i < n - step) {
            val a = atan2(stroke.y(i) - stroke.y(i - step), stroke.x(i) - stroke.x(i - step))
            val b = atan2(stroke.y(i + step) - stroke.y(i), stroke.x(i + step) - stroke.x(i))
            var d = abs(b - a)
            if (d > Math.PI) d = (2 * Math.PI - d).toFloat()
            if (d > 0.9f) { corners++; i += step * 2 } else i += step
        }
        return corners
    }

    /** Detects the little V at the end of a hand drawn arrow. */
    private fun arrowHead(stroke: Stroke): Pair<Float, Float>? {
        val n = stroke.pointCount
        val tailIdx = (n * 0.8f).toInt()
        val mainAngle = atan2(stroke.y(tailIdx) - stroke.y(0), stroke.x(tailIdx) - stroke.x(0))
        var maxDeviation = 0f
        for (i in tailIdx until n - 1) {
            val a = atan2(stroke.y(i + 1) - stroke.y(i), stroke.x(i + 1) - stroke.x(i))
            var d = abs(a - mainAngle)
            if (d > Math.PI) d = (2 * Math.PI - d).toFloat()
            if (d > maxDeviation) maxDeviation = d
        }
        return if (maxDeviation > 1.2f) stroke.x(tailIdx) to stroke.y(tailIdx) else null
    }

    private fun buildArrow(stroke: Stroke, head: Pair<Float, Float>): Stroke {
        val sx = stroke.x(0); val sy = stroke.y(0)
        val (ex, ey) = head
        val angle = atan2(ey - sy, ex - sx)
        val size = hypot(ex - sx, ey - sy) * 0.18f
        val left = (ex - size * cos(angle - 0.4f)) to (ey - size * sin(angle - 0.4f))
        val right = (ex - size * cos(angle + 0.4f)) to (ey - size * sin(angle + 0.4f))
        return build(stroke, listOf(sx to sy, ex to ey, left, ex to ey, right))
    }

    private fun trianglePoints(stroke: Stroke): List<Pair<Float, Float>> {
        val apexX = (stroke.minX + stroke.maxX) / 2f
        return listOf(
            apexX to stroke.minY,
            stroke.maxX to stroke.maxY,
            stroke.minX to stroke.maxY,
            apexX to stroke.minY
        )
    }

    private fun ellipsePoints(cx: Float, cy: Float, rx: Float, ry: Float): List<Pair<Float, Float>> =
        (0..72).map { i ->
            val t = i / 72f * 2f * Math.PI
            (cx + rx * cos(t)).toFloat() to (cy + ry * sin(t)).toFloat()
        }

    /** Densifies the ideal outline into evenly spaced ink points so it renders like ink. */
    private fun build(source: Stroke, corners: List<Pair<Float, Float>>): Stroke {
        val pts = ArrayList<Float>()
        val spacing = 2f
        for (i in 0 until corners.size - 1) {
            val (x1, y1) = corners[i]
            val (x2, y2) = corners[i + 1]
            val len = hypot(x2 - x1, y2 - y1)
            val steps = (len / spacing).toInt().coerceAtLeast(1)
            for (s in 0..steps) {
                val t = s.toFloat() / steps
                pts.add(x1 + (x2 - x1) * t); pts.add(y1 + (y2 - y1) * t); pts.add(1f); pts.add(0f)
            }
        }
        val array = FloatArray(pts.size) { pts[it] }
        val brush: InkBrush = source.brush.copy(pressureResponse = 0f)
        return Stroke(source.id, brush, array, array.size / STRIDE).also { it.recomputeBounds() }
    }
}
