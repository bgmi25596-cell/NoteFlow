import { useState } from "react";
import CodeBrowser from "./components/CodeBrowser";
import DocsViewer from "./components/DocsViewer";
import PhoneMockup from "./components/PhoneMockup";
import { sourceStats } from "./data/sources";
import { cn } from "./utils/cn";

const nav = [
  { id: "overview", label: "Overview" },
  { id: "engine", label: "Ink engine" },
  { id: "status", label: "Honest status" },
  { id: "build", label: "Build the APK" },
  { id: "code", label: "Source code" },
  { id: "docs", label: "Docs" },
];

const pillars = [
  {
    title: "Native ink, not a bitmap",
    body: "InkCanvasView reads raw MotionEvent batches — historical samples, tool type, pressure, touchMajor, barrel button — filters them live and stores [x, y, pressure, t] in page points. Zoom to 1200 % and the stroke is still crisp.",
    tag: "ink/InkCanvasView.kt",
  },
  {
    title: "Real paper geometry",
    body: "A2–A6 and Letter are computed from millimetres with pt = mm × 72 ÷ 25.4, so A4 is 595.28 × 841.89 pt on screen and in the exported PDF. Unit-tested to 0.05 pt.",
    tag: "domain/model/PageSpec.kt",
  },
  {
    title: "Two stores, one owner",
    body: "Room keeps notes, folders, tags, pages and presets; the file store keeps stroke payloads. Only NotesRepository touches both, so deleting a note always deletes its ink files.",
    tag: "data/repository/NotesRepository.kt",
  },
  {
    title: "Crash-safe autosave",
    body: "Debounced saves, atomic temp-file + rename writes, a tolerant ink reader that recovers a truncated file, flush on ON_PAUSE, and a visible Saving / Saved / Retry status chip.",
    tag: "ui/editor/EditorViewModel.kt",
  },
  {
    title: "Offline by construction",
    body: "The manifest has no INTERNET permission at all. No login screen, no subscription, no ads, no analytics, no model download — the app physically cannot phone home.",
    tag: "AndroidManifest.xml",
  },
  {
    title: "Export that matches the screen",
    body: "PdfExporter draws with the same InkRenderer and TemplateRenderer used in the editor, into android.graphics.pdf.PdfDocument. Platform API, zero third-party PDF licence risk.",
    tag: "export/PdfExporter.kt",
  },
];

const engine = [
  {
    heading: "Input pipeline",
    items: [
      "Stylus pointers always win; fingers are dropped for ~900 ms after any pen sample and oversized contacts (touchMajor) are treated as palm.",
      "TOOL_TYPE_ERASER or BUTTON_STYLUS_PRIMARY switches to the eraser while held, then switches back.",
      "Finger behaviour is user-configurable: draw, scroll, zoom-only or ignore.",
      "Historical samples inside each MotionEvent are replayed, so fast writing keeps its detail.",
    ],
  },
  {
    heading: "Stroke maths",
    items: [
      "Live speed-adaptive low-pass filter removes tremor without visible lag.",
      "On lift, points are re-fitted to a Catmull-Rom spline at uniform spacing and pressure is median-smoothed.",
      "Shape snapping recognises line, arrow, rectangle, triangle and ellipse — and returns null for handwriting so your words are never 'corrected'.",
      "Ruler mode projects every sample onto a chosen angle; grid snap aligns the stroke origin.",
    ],
  },
  {
    heading: "Editing model",
    items: [
      "Undo/redo is command based (Add / Remove / Replace) — bounded memory, no page snapshots.",
      "Stroke eraser deletes whole strokes; the partial eraser splits one stroke into the pieces outside the eraser disc.",
      "Lasso selection supports move, scale, rotate, copy, paste, duplicate and delete, all reversible.",
      "Seven pens: pen, ballpoint, fountain (nib angle + pressure), pencil (grain passes), brush (tapered), calligraphy (chisel), highlighter (multiply blend).",
    ],
  },
];

const implemented = [
  "Notes: create, rename, duplicate, pin, favourite, archive, bin, restore, delete forever",
  "Folders with subfolders, tags, full-text search over title and snippet, five sort orders",
  "Debounced autosave + explicit save status and Retry on failure",
  "Vector ink engine with 7 pens, 2 erasers, lasso, shapes, ruler, undo/redo",
  "Pinch zoom, pan, zoom lock, double-tap fit, per-page viewport persistence",
  "A2 / A3 / A4 / A5 / A6 / Letter + infinite canvas, portrait and landscape",
  "11 paper templates, custom page + line colours, grid spacing, margins, saved presets",
  "Multi-page notes: add, duplicate, reorder, delete, navigate",
  "PDF export with true page sizes and vector strokes",
  "Validated local JSON backup and import (merge or replace, with warning)",
  "Light / dark themes, six accents, larger-touch-target mode, phone + tablet layouts",
  "First-run screen with no account and no permission prompts",
];

const notYet = [
  ["PDF import and annotation", "Phase 4 — platform PdfRenderer is the planned, licence-free route"],
  ["Images, crop/rotate, text boxes, tables, connectors", "Phase 4 — needs a page_overlays table and a real migration"],
  ["Audio recording and playback", "Phase 4 — RECORD_AUDIO will be added in the same commit as the recorder"],
  ["Neural handwriting beautification", "Phase 5 — no free, offline, appropriately licensed model found; the shipped feature is geometric refinement and is labelled as such"],
  ["OCR, handwriting text search, flashcards and quizzes", "Phase 6 — candidate is Tesseract (Apache-2.0), weak on cursive; will be labelled honestly"],
  ["Verified palm rejection on stylus hardware", "Device-dependent — the code uses only public APIs; it has not been run on a physical active-pen device by this commit"],
  ["C++/NDK ink renderer", "Not needed yet — profiling must prove it before any native code is added"],
];

const phases = [
  { name: "Phase 1 · Skeleton, Room, autosave", state: "done" },
  { name: "Phase 2 · Ink engine, stylus, erasers, undo", state: "done" },
  { name: "Phase 3 · Page sizes, templates, themes, export", state: "done" },
  { name: "Phase 4 · PDF import, images, text, audio", state: "next" },
  { name: "Phase 5 · Handwriting beautification research", state: "planned" },
  { name: "Phase 6 · OCR and study tools", state: "planned" },
  { name: "Phase 7 · Profiling, release APK", state: "planned" },
];

const steps = [
  {
    title: "Make a free GitHub account",
    body: "On your phone, in any browser. No payment details, no Android Studio, no computer.",
  },
  {
    title: "Create a repository and upload this project",
    body: "Keep the folders exactly as they are: android/ and .github/. Use GitHub's 'Add file → Upload files', or the free Acode / MGit apps.",
  },
  {
    title: "Run the build workflow",
    body: "Actions tab → 'Build NoteFlow APK' → Run workflow. GitHub builds it on a free Linux runner with JDK 17 and Gradle 8.9, and also runs the unit tests.",
  },
  {
    title: "Download and install",
    body: "Open the finished run → Artifacts → NoteFlow-debug-apk → unzip → tap app-debug.apk → allow 'Install unknown apps' once. It is signed with the standard debug key, so nothing else is needed.",
  },
];

export default function App() {
  const [active, setActive] = useState("overview");

  const go = (id: string) => {
    setActive(id);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="min-h-screen bg-[#0a0f0f] text-slate-300">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(60rem_40rem_at_80%_-10%,rgba(14,124,123,0.25),transparent),radial-gradient(40rem_30rem_at_0%_20%,rgba(43,91,215,0.12),transparent)]" />

      <header className="sticky top-0 z-30 border-b border-slate-800/80 bg-[#0a0f0f]/85 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-4 px-5 py-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600">
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round">
                <path d="M6 19c3-8 5-11 7-11s1 7 3 7 2-3 3-5" />
                <path d="M5 4h9l5 5v3" />
              </svg>
            </div>
            <div className="leading-tight">
              <p className="text-sm font-semibold text-white">NoteFlow</p>
              <p className="text-[11px] text-slate-500">Android · Kotlin · offline</p>
            </div>
          </div>
          <nav className="ml-auto hidden gap-1 md:flex">
            {nav.map((item) => (
              <button
                key={item.id}
                onClick={() => go(item.id)}
                className={cn(
                  "rounded-lg px-3 py-1.5 text-sm transition",
                  active === item.id ? "bg-slate-800 text-teal-200" : "text-slate-400 hover:text-slate-100",
                )}
              >
                {item.label}
              </button>
            ))}
          </nav>
          <button
            onClick={() => go("build")}
            className="ml-auto rounded-lg bg-teal-500 px-3 py-1.5 text-sm font-medium text-slate-950 transition hover:bg-teal-400 md:ml-0"
          >
            Build APK
          </button>
        </div>
      </header>

      <main className="relative mx-auto max-w-6xl px-5 pb-24">
        {/* HERO */}
        <section id="overview" className="grid items-center gap-10 py-14 lg:grid-cols-[1.05fr_0.95fr]">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-teal-500/30 bg-teal-500/10 px-3 py-1 text-xs text-teal-300">
              Phases 1–3 implemented · {sourceStats.kotlinFiles} Kotlin files · {sourceStats.lines.toLocaleString()} lines
            </span>
            <h1 className="mt-5 text-4xl font-semibold leading-[1.1] tracking-tight text-white sm:text-5xl">
              A premium handwriting notebook that never asks who you are.
            </h1>
            <p className="mt-5 max-w-xl text-[17px] leading-relaxed text-slate-400">
              NoteFlow is a complete, original Android project: Kotlin, Jetpack Compose, a custom
              Canvas ink engine built on MotionEvent, Room/SQLite storage and a local file store for
              strokes. No account, no subscription, no paid API — and no INTERNET permission in the
              manifest at all.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <button
                onClick={() => go("code")}
                className="rounded-xl bg-white px-5 py-2.5 text-sm font-medium text-slate-900 transition hover:bg-slate-200"
              >
                Browse the real source
              </button>
              <button
                onClick={() => go("status")}
                className="rounded-xl border border-slate-700 px-5 py-2.5 text-sm text-slate-300 transition hover:border-teal-500 hover:text-teal-200"
              >
                What is and isn&apos;t finished
              </button>
            </div>
            <dl className="mt-9 grid max-w-lg grid-cols-3 gap-4">
              {[
                ["Source files", sourceStats.files],
                ["Kotlin lines", sourceStats.kotlinLines.toLocaleString()],
                ["Unit test files", sourceStats.testFiles],
              ].map(([label, value]) => (
                <div key={String(label)} className="rounded-xl border border-slate-800 bg-slate-900/50 p-3">
                  <dt className="text-[11px] uppercase tracking-wide text-slate-500">{label}</dt>
                  <dd className="mt-1 text-xl font-semibold text-white">{value}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div className="flex justify-center lg:justify-end">
            <PhoneMockup />
          </div>
        </section>

        {/* PILLARS */}
        <section className="grid gap-4 py-6 sm:grid-cols-2 lg:grid-cols-3">
          {pillars.map((p) => (
            <article
              key={p.title}
              className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5 transition hover:border-teal-500/40"
            >
              <h3 className="text-base font-semibold text-white">{p.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-400">{p.body}</p>
              <p className="mt-3 font-mono text-[11px] text-teal-400/80">{p.tag}</p>
            </article>
          ))}
        </section>

        {/* ENGINE */}
        <section id="engine" className="scroll-mt-20 py-14">
          <h2 className="text-2xl font-semibold text-white">Inside the handwriting engine</h2>
          <p className="mt-2 max-w-3xl text-slate-400">
            Compose draws the chrome; a plain Android <code className="rounded bg-slate-800 px-1.5 py-0.5 text-teal-200">View</code> draws the ink.
            That split is deliberate: touch events reach the stroke buffer without going through
            recomposition, which is what keeps the line under the pen tip.
          </p>
          <div className="mt-6 grid gap-4 lg:grid-cols-3">
            {engine.map((block) => (
              <div key={block.heading} className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5">
                <h3 className="text-sm font-semibold uppercase tracking-wide text-teal-300">{block.heading}</h3>
                <ul className="mt-3 space-y-2.5">
                  {block.items.map((item) => (
                    <li key={item} className="flex gap-2 text-sm leading-relaxed text-slate-400">
                      <span className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-teal-500" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="mt-6 rounded-2xl border border-amber-500/30 bg-amber-500/5 p-5">
            <h3 className="text-sm font-semibold text-amber-200">About “Beautify Handwriting”</h3>
            <p className="mt-2 text-sm leading-relaxed text-slate-300">
              The shipped feature is called <strong className="text-white">Tidy handwriting (geometric)</strong>, because that
              is exactly what it is: Catmull-Rom re-fitting, baseline alignment, letter-height
              evening, optional slant and spacing normalisation applied to your own strokes, with
              preview / accept / reject and a normal undo step. No model is bundled, downloaded or
              contacted. A neural handwriting generator was evaluated and rejected: the available
              pretrained checkpoints are research artefacts with non-commercial or unclear licences
              and unrealistic size/RAM for a phone. A recognition-then-font pipeline would be text
              conversion, not beautification, and would be labelled that way if it is ever added.
            </p>
          </div>
        </section>

        {/* STATUS */}
        <section id="status" className="scroll-mt-20 py-10">
          <h2 className="text-2xl font-semibold text-white">Honest status</h2>
          <p className="mt-2 max-w-3xl text-slate-400">
            Nothing here is claimed to work unless the code for it exists in this repository. The
            app contains no placeholder buttons for unfinished features.
          </p>
          <div className="mt-6 grid gap-4 lg:grid-cols-2">
            <div className="rounded-2xl border border-emerald-600/30 bg-emerald-500/5 p-5">
              <h3 className="text-sm font-semibold uppercase tracking-wide text-emerald-300">Implemented</h3>
              <ul className="mt-3 space-y-2">
                {implemented.map((item) => (
                  <li key={item} className="flex gap-2 text-sm text-slate-300">
                    <span className="text-emerald-400">✓</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-2xl border border-slate-700 bg-slate-900/50 p-5">
              <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-300">Not implemented yet</h3>
              <ul className="mt-3 space-y-3">
                {notYet.map(([item, why]) => (
                  <li key={item} className="text-sm">
                    <p className="text-slate-200">{item}</p>
                    <p className="text-slate-500">{why}</p>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="mt-6 rounded-2xl border border-slate-800 bg-slate-900/50 p-5">
            <h3 className="text-sm font-semibold uppercase tracking-wide text-teal-300">Verification</h3>
            <p className="mt-2 text-sm text-slate-400">
              Machine-verified today: page geometry, the binary ink format (including recovery from a
              truncated file), resampling, shape recognition and the refiner, via JVM unit tests that
              run in the same GitHub Action that builds the APK. Everything that needs a screen or a
              digitiser — drawing feel, palm rejection, PDF viewing, rotation, backup round-trips — is
              a manual checklist in <span className="font-mono text-teal-300">docs/TESTING.md</span>, and has not been executed on
              physical hardware by this commit. Treat it as a checklist, not a result.
            </p>
          </div>

          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {phases.map((phase) => (
              <div
                key={phase.name}
                className={cn(
                  "rounded-xl border p-4 text-sm",
                  phase.state === "done"
                    ? "border-emerald-600/40 bg-emerald-500/5 text-slate-200"
                    : phase.state === "next"
                      ? "border-teal-500/40 bg-teal-500/5 text-slate-200"
                      : "border-slate-800 bg-slate-900/40 text-slate-400",
                )}
              >
                <p className="text-[11px] uppercase tracking-wide text-slate-500">
                  {phase.state === "done" ? "Complete" : phase.state === "next" ? "Up next" : "Planned"}
                </p>
                <p className="mt-1">{phase.name}</p>
              </div>
            ))}
          </div>
        </section>

        {/* BUILD */}
        <section id="build" className="scroll-mt-20 py-10">
          <h2 className="text-2xl font-semibold text-white">Build the APK with only your phone</h2>
          <p className="mt-2 max-w-3xl text-slate-400">
            Compiling Android apps needs the Android SDK, which does not run on a phone. The project
            therefore ships a GitHub Actions workflow so a free Linux runner does the compiling for
            you — zero budget, zero code to write.
          </p>
          <ol className="mt-6 grid gap-4 md:grid-cols-2">
            {steps.map((step, index) => (
              <li key={step.title} className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-teal-500/15 text-sm font-semibold text-teal-300">
                  {index + 1}
                </div>
                <h3 className="mt-3 text-base font-semibold text-white">{step.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-slate-400">{step.body}</p>
              </li>
            ))}
          </ol>
          <div className="mt-5 rounded-2xl border border-slate-800 bg-slate-950/70 p-5 font-mono text-[12.5px] text-slate-400">
            <p className="text-slate-500"># optional: on a computer instead</p>
            <p className="mt-1 text-teal-300">cd android</p>
            <p className="text-teal-300">gradle assembleDebug</p>
            <p className="text-teal-300">gradle testDebugUnitTest</p>
            <p className="mt-2 text-slate-500"># requires JDK 17 + Gradle 8.9 + Android SDK 34</p>
          </div>
        </section>

        {/* CODE */}
        <section id="code" className="scroll-mt-20 py-10">
          <h2 className="text-2xl font-semibold text-white">Source code</h2>
          <p className="mt-2 max-w-3xl text-slate-400">
            Every file below is loaded straight out of the repository, so this page and the project
            can never disagree. Use Copy file if you want to paste a file into an editor on your
            phone.
          </p>
          <div className="mt-6">
            <CodeBrowser />
          </div>
        </section>

        {/* DOCS */}
        <section id="docs" className="scroll-mt-20 py-10">
          <h2 className="text-2xl font-semibold text-white">Project documentation</h2>
          <p className="mt-2 max-w-3xl text-slate-400">
            Install guide, architecture, licence inventory, testing checklist and the beginner-sized
            milestones for continuing the build with AI help.
          </p>
          <div className="mt-6">
            <DocsViewer />
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-800/80 bg-[#080c0c]">
        <div className="mx-auto max-w-6xl px-5 py-8 text-sm text-slate-500">
          <p className="text-slate-300">NoteFlow — original MIT-licensed project.</p>
          <p className="mt-2 max-w-3xl">
            No trademarks, proprietary code or private assets from any other product are used. Notes
            are stored only on the device: that is private, but it is not a backup — export a
            .noteflow.json file regularly and keep it somewhere safe.
          </p>
        </div>
      </footer>
    </div>
  );
}
