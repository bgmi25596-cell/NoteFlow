package app.noteflow.data.backup

import android.content.Context
import android.net.Uri
import android.util.Base64
import android.util.Log
import app.noteflow.data.files.FileStore
import app.noteflow.data.local.NoteFlowDatabase
import app.noteflow.data.local.entity.AttachmentEntity
import app.noteflow.data.local.entity.FolderEntity
import app.noteflow.data.local.entity.NoteEntity
import app.noteflow.data.local.entity.NoteTagCrossRef
import app.noteflow.data.local.entity.PageEntity
import app.noteflow.data.local.entity.TagEntity
import app.noteflow.data.local.entity.TemplatePresetEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Local JSON backup / restore.
 *
 * The file is a single self-contained .noteflow.json that the user saves wherever they
 * like through the system file picker (Storage Access Framework — no storage permission
 * and no cloud account). Ink pages are embedded as Base64 of their .nfink payload so the
 * backup is lossless and still fully vector.
 *
 * Import is validated before anything is written, and two modes are offered:
 *   MERGE   — keeps existing notes, adds/overwrites by id
 *   REPLACE — wipes the library first (the UI must show a clear warning)
 */
@Serializable data class BackupNote(
    val id: String, val title: String, val snippet: String, val folderId: String?,
    val isPinned: Boolean, val isFavorite: Boolean, val isArchived: Boolean,
    val accentArgb: Int?, val createdAt: Long, val updatedAt: Long, val openedAt: Long, val deletedAt: Long?
)

@Serializable data class BackupFolder(
    val id: String, val name: String, val parentId: String?, val colorArgb: Int?,
    val sortIndex: Int, val createdAt: Long, val updatedAt: Long, val deletedAt: Long?
)

@Serializable data class BackupPage(
    val id: String, val noteId: String, val pageIndex: Int, val kind: String,
    val pageSizeId: String, val orientation: String, val widthPt: Float, val heightPt: Float,
    val templateId: String, val backgroundArgb: Int, val lineArgb: Int,
    val gridSpacingMm: Float, val marginMm: Float, val textJson: String?,
    /** Base64 of the .nfink vector payload, or null for an empty page. */
    val inkBase64: String?
)

@Serializable data class BackupTag(val id: String, val name: String, val colorArgb: Int?)
@Serializable data class BackupTagLink(val noteId: String, val tagId: String)
@Serializable data class BackupPreset(
    val id: String, val name: String, val builtIn: Boolean, val templateId: String,
    val pageSizeId: String, val orientation: String, val backgroundArgb: Int,
    val lineArgb: Int, val gridSpacingMm: Float, val marginMm: Float, val sortIndex: Int
)

@Serializable data class BackupFile(
    val format: String = FORMAT,
    val formatVersion: Int = VERSION,
    val appVersion: String,
    val exportedAt: Long,
    val notes: List<BackupNote>,
    val folders: List<BackupFolder>,
    val pages: List<BackupPage>,
    val tags: List<BackupTag>,
    val tagLinks: List<BackupTagLink>,
    val presets: List<BackupPreset>
) {
    companion object {
        const val FORMAT = "noteflow-backup"
        const val VERSION = 1
    }
}

sealed interface ImportResult {
    data class Success(val notes: Int, val pages: Int, val folders: Int) : ImportResult
    data class Invalid(val reason: String) : ImportResult
    data class Failure(val reason: String) : ImportResult
}

enum class ImportMode { MERGE, REPLACE }

class BackupManager(
    private val context: Context,
    private val db: NoteFlowDatabase,
    private val files: FileStore
) {
    private val json = Json { prettyPrint = false; ignoreUnknownKeys = true; encodeDefaults = true }

    suspend fun export(target: Uri, appVersion: String): Result<Long> = withContext(Dispatchers.IO) {
        runCatching {
            val noteDao = db.noteDao()
            val pageDao = db.pageDao()
            val backup = BackupFile(
                appVersion = appVersion,
                exportedAt = System.currentTimeMillis(),
                notes = noteDao.allForBackup().map { it.toBackup() },
                folders = db.folderDao().allForBackup().map { it.toBackup() },
                pages = pageDao.allForBackup().map { it.toBackup() },
                tags = noteDao.allTagsForBackup().map { BackupTag(it.id, it.name, it.colorArgb) },
                tagLinks = noteDao.allTagLinksForBackup().map { BackupTagLink(it.noteId, it.tagId) },
                presets = pageDao.allPresetsForBackup().map { it.toBackup() }
            )
            val bytes = json.encodeToString(BackupFile.serializer(), backup).toByteArray()
            context.contentResolver.openOutputStream(target, "wt")?.use { it.write(bytes) }
                ?: error("Could not open the selected file for writing")
            bytes.size.toLong()
        }
    }

    suspend fun import(source: Uri, mode: ImportMode): ImportResult = withContext(Dispatchers.IO) {
        val text = try {
            context.contentResolver.openInputStream(source)?.bufferedReader()?.use { it.readText() }
                ?: return@withContext ImportResult.Failure("The file could not be opened.")
        } catch (t: Throwable) {
            Log.e(TAG, "read failed", t)
            return@withContext ImportResult.Failure("The file could not be read: ${t.message}")
        }

        val parsed = try {
            json.decodeFromString(BackupFile.serializer(), text)
        } catch (t: Throwable) {
            return@withContext ImportResult.Invalid("This is not a valid NoteFlow backup file.")
        }

        if (parsed.format != BackupFile.FORMAT) {
            return@withContext ImportResult.Invalid("Unknown format \"${parsed.format}\".")
        }
        if (parsed.formatVersion > BackupFile.VERSION) {
            return@withContext ImportResult.Invalid(
                "This backup was made by a newer NoteFlow (format ${parsed.formatVersion}). Please update the app."
            )
        }
        val noteIds = parsed.notes.map { it.id }.toSet()
        val orphanPages = parsed.pages.count { it.noteId !in noteIds }
        if (orphanPages > 0) {
            return@withContext ImportResult.Invalid("Backup is inconsistent: $orphanPages page(s) reference a missing note.")
        }
        val estimatedBytes = text.length.toLong() * 2
        if (!files.hasRoomFor(estimatedBytes)) {
            return@withContext ImportResult.Failure("Not enough free storage to import this backup.")
        }

        try {
            if (mode == ImportMode.REPLACE) {
                db.clearAllTables()
                files.notesDir.deleteRecursively()
            }
            // Folders first (parents may come after children, so insert twice: flat then re-link)
            parsed.folders.forEach { db.folderDao().upsert(it.toEntity(parentId = null)) }
            parsed.folders.forEach { db.folderDao().upsert(it.toEntity()) }
            parsed.notes.forEach { db.noteDao().upsert(it.toEntity()) }
            parsed.tags.forEach { db.noteDao().insertTag(TagEntity(it.id, it.name, it.colorArgb)) }
            parsed.tagLinks.forEach { db.noteDao().link(NoteTagCrossRef(it.noteId, it.tagId)) }
            parsed.presets.forEach { db.pageDao().upsertPreset(it.toEntity()) }

            parsed.pages.forEach { page ->
                val relative = files.inkFileName(page.noteId, page.id)
                page.inkBase64?.let { encoded ->
                    val bytes = Base64.decode(encoded, Base64.NO_WRAP)
                    files.writeAtomically(files.resolve(relative)) { it.write(bytes) }
                }
                db.pageDao().upsert(page.toEntity(relative))
            }
            ImportResult.Success(parsed.notes.size, parsed.pages.size, parsed.folders.size)
        } catch (t: Throwable) {
            Log.e(TAG, "import failed", t)
            ImportResult.Failure("Import failed: ${t.message}")
        }
    }

    // ---------- mapping ----------
    private fun NoteEntity.toBackup() = BackupNote(
        id, title, snippet, folderId, isPinned, isFavorite, isArchived, accentArgb,
        createdAt, updatedAt, openedAt, deletedAt
    )

    private fun BackupNote.toEntity() = NoteEntity(
        id, title, snippet, folderId, isPinned, isFavorite, isArchived, accentArgb,
        createdAt, updatedAt, openedAt, deletedAt
    )

    private fun FolderEntity.toBackup() =
        BackupFolder(id, name, parentId, colorArgb, sortIndex, createdAt, updatedAt, deletedAt)

    private fun BackupFolder.toEntity(parentId: String? = this.parentId) =
        FolderEntity(id, name, parentId, colorArgb, sortIndex, createdAt, updatedAt, deletedAt)

    private fun PageEntity.toBackup(): BackupPage {
        val ink = inkFile?.let { path ->
            val file = files.resolve(path)
            if (file.exists() && file.length() > 0) Base64.encodeToString(file.readBytes(), Base64.NO_WRAP) else null
        }
        return BackupPage(
            id, noteId, pageIndex, kind, pageSizeId, orientation, widthPt, heightPt,
            templateId, backgroundArgb, lineArgb, gridSpacingMm, marginMm, textJson, ink
        )
    }

    private fun BackupPage.toEntity(relative: String) = PageEntity(
        id = id, noteId = noteId, pageIndex = pageIndex, kind = kind, pageSizeId = pageSizeId,
        orientation = orientation, widthPt = widthPt, heightPt = heightPt, templateId = templateId,
        backgroundArgb = backgroundArgb, lineArgb = lineArgb, gridSpacingMm = gridSpacingMm,
        marginMm = marginMm, inkFile = relative, textJson = textJson
    )

    private fun TemplatePresetEntity.toBackup() = BackupPreset(
        id, name, builtIn, templateId, pageSizeId, orientation, backgroundArgb, lineArgb,
        gridSpacingMm, marginMm, sortIndex
    )

    private fun BackupPreset.toEntity() = TemplatePresetEntity(
        id, name, builtIn, templateId, pageSizeId, orientation, backgroundArgb, lineArgb,
        gridSpacingMm, marginMm, sortIndex
    )

    @Suppress("unused")
    private fun AttachmentEntity.unusedForNow() = Unit // attachments land in Phase 4

    companion object { private const val TAG = "BackupManager" }
}
