package app.noteflow

import android.app.Application
import app.noteflow.data.backup.BackupManager
import app.noteflow.data.files.FileStore
import app.noteflow.data.local.NoteFlowDatabase
import app.noteflow.data.repository.NotesRepository
import app.noteflow.data.settings.SettingsStore
import app.noteflow.export.PdfExporter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Tiny hand-rolled dependency container.
 *
 * A full DI framework (Hilt/Koin) would add build complexity for a beginner with no
 * benefit at this size: there is exactly one database, one file store and one repository.
 * Everything is created lazily and lives for the process lifetime.
 */
class AppContainer(app: Application) {
    val database: NoteFlowDatabase by lazy { NoteFlowDatabase.get(app) }
    val fileStore: FileStore by lazy { FileStore(app) }
    val repository: NotesRepository by lazy { NotesRepository(database, fileStore) }
    val settings: SettingsStore by lazy { SettingsStore(app) }
    val backup: BackupManager by lazy { BackupManager(app, database, fileStore) }
    val pdfExporter: PdfExporter by lazy { PdfExporter(app, repository) }
}

class NoteFlowApplication : Application() {

    lateinit var container: AppContainer
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        scope.launch {
            runCatching {
                container.repository.seedBuiltInPresetsIfNeeded()
                container.repository.pruneOrphanFiles()
            }
        }
    }
}

/** Convenience accessor used by AndroidViewModel subclasses. */
val Application.container: AppContainer
    get() = (this as NoteFlowApplication).container
