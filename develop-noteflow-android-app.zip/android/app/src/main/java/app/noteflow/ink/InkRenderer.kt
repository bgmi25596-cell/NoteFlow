package app.noteflow.ink

import android.graphics.BlendMode
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.os.Build
import app.noteflow.domain.model.InkTool
import app.noteflow.domain.model.STRIDE
import app.noteflow.domain.model.Stroke
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Draws vector strokes onto any Canvas — the live editor view AND the PDF export canvas
 * use exactly the same code, so what you see is what you export.
 *
 * The canvas is expected to be pre-scaled to page points (canvas.scale(pxPerPt, pxPerPt)),
 * therefore all widths here are in points.
 *
 * Per-tool behaviour (all implemented with platform Canvas/Paint, no third-party engine):
 *  PEN          constant-ish width, slight pressure response
 *  BALLPOINT    thin, very little pressure response, fully opaque
 *  FOUNTAIN     width from pressure AND direction relative to the nib angle
 *  PENCIL       grainy: multiple low-alpha offset passes
 *  BRUSH        strong pressure response, soft tapering ends
 *  CALLIGRAPHY  chisel nib: width purely from stroke direction
 *  HIGHLIGHTER  constant wide, translucent, multiplied so overlaps do not darken endlessly
 */
class InkRenderer {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()

    fun drawAll(canvas: Canvas, strokes: List<Stroke>, clipLeft: Float = Float.NEGATIVE_INFINITY,
                clipTop: Float = Float.NEGATIVE_INFINITY, clipRight: Float = Float.POSITIVE_INFINITY,
                clipBottom: Float = Float.POSITIVE_INFINITY) {
        for (s in strokes) {
            if (s.intersectsRect(clipLeft, clipTop, clipRight, clipBottom)) draw(canvas, s)
        }
    }

    fun draw(canvas: Canvas, stroke: Stroke) {
        if (stroke.pointCount == 0) return
        val brush = stroke.brush
        setMultiply(brush.tool == InkTool.HIGHLIGHTER)
        val alpha = (brush.opacity.coerceIn(0f, 1f) * 255).toInt()
        paint.color = Color.argb(
            (Color.alpha(brush.colorArgb) * alpha) / 255,
            Color.red(brush.colorArgb), Color.green(brush.colorArgb), Color.blue(brush.colorArgb)
        )

        when (brush.tool) {
            InkTool.HIGHLIGHTER -> drawConstant(canvas, stroke, brush.widthPt, Paint.Cap.SQUARE)
            InkTool.BALLPOINT -> drawVariable(canvas, stroke, response = 0.2f)
            InkTool.PEN -> drawVariable(canvas, stroke, response = brush.pressureResponse * 0.6f)
            InkTool.BRUSH -> drawVariable(canvas, stroke, response = brush.pressureResponse, taper = true)
            InkTool.FOUNTAIN -> drawDirectional(canvas, stroke, pressureWeight = brush.pressureResponse, minRatio = 0.35f)
            InkTool.CALLIGRAPHY -> drawDirectional(canvas, stroke, pressureWeight = 0f, minRatio = 0.15f)
            InkTool.PENCIL -> drawPencil(canvas, stroke)
        }
        setMultiply(false)
    }

    /**
     * Highlighter ink multiplies with what is underneath so text stays readable.
     * `Paint.blendMode` only exists from API 29, so API 26–28 falls back to the
     * equivalent PorterDuff mode. Both paths produce the same visual result.
     */
    private fun setMultiply(enabled: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            paint.blendMode = if (enabled) BlendMode.MULTIPLY else BlendMode.SRC_OVER
        } else {
            @Suppress("DEPRECATION")
            paint.xfermode = if (enabled) PorterDuffXfermode(PorterDuff.Mode.MULTIPLY) else null
        }
    }

    // --- single-width fast path (also used for the highlighter) ---
    private fun drawConstant(canvas: Canvas, stroke: Stroke, width: Float, cap: Paint.Cap) {
        paint.strokeCap = cap
        paint.strokeWidth = width
        buildPath(stroke)
        canvas.drawPath(path, paint)
        paint.strokeCap = Paint.Cap.ROUND
    }

    // --- pressure driven width, drawn segment by segment ---
    private fun drawVariable(canvas: Canvas, stroke: Stroke, response: Float, taper: Boolean = false) {
        val base = stroke.brush.widthPt
        if (response <= 0.02f) { drawConstant(canvas, stroke, base, Paint.Cap.ROUND); return }
        val n = stroke.pointCount
        if (n == 1) { paint.strokeWidth = base; canvas.drawPoint(stroke.x(0), stroke.y(0), paint); return }
        for (i in 0 until n - 1) {
            var w = base * (1f - response + response * stroke.pressure(i).coerceIn(0.05f, 1.5f))
            if (taper) {
                val edge = minOf(i, n - 2 - i).toFloat()
                val ramp = (edge / 6f).coerceIn(0.35f, 1f)
                w *= ramp
            }
            paint.strokeWidth = w
            canvas.drawLine(stroke.x(i), stroke.y(i), stroke.x(i + 1), stroke.y(i + 1), paint)
        }
    }

    // --- chisel / nib: width depends on the angle between the stroke and the nib ---
    private fun drawDirectional(canvas: Canvas, stroke: Stroke, pressureWeight: Float, minRatio: Float) {
        val base = stroke.brush.widthPt
        val nib = Math.toRadians(stroke.brush.nibAngleDeg.toDouble())
        val nx = cos(nib).toFloat()
        val ny = sin(nib).toFloat()
        for (i in 0 until stroke.pointCount - 1) {
            val dx = stroke.x(i + 1) - stroke.x(i)
            val dy = stroke.y(i + 1) - stroke.y(i)
            val len = hypot(dx, dy)
            val ratio = if (len < 0.0001f) 1f else {
                // perpendicular component against the nib direction
                abs(dx / len * ny - dy / len * nx).coerceIn(minRatio, 1f)
            }
            val press = 1f - pressureWeight + pressureWeight * stroke.pressure(i).coerceIn(0.05f, 1.5f)
            paint.strokeWidth = base * ratio * press
            canvas.drawLine(stroke.x(i), stroke.y(i), stroke.x(i + 1), stroke.y(i + 1), paint)
        }
    }

    // --- pencil grain: three offset passes at low alpha, deterministic per stroke id ---
    private fun drawPencil(canvas: Canvas, stroke: Stroke) {
        val base = stroke.brush.widthPt
        val baseAlpha = paint.alpha
        var seed = (stroke.id * 2654435761L).toInt()
        fun rnd(): Float { seed = seed * 1103515245 + 12345; return ((seed ushr 16) and 0x7fff) / 32767f - 0.5f }
        paint.alpha = (baseAlpha * 0.42f).toInt()
        repeat(3) { pass ->
            val jitter = base * 0.22f * (pass - 1)
            for (i in 0 until stroke.pointCount - 1) {
                paint.strokeWidth = base * (0.55f + 0.45f * stroke.pressure(i).coerceIn(0.1f, 1.2f))
                val ox = jitter + rnd() * base * 0.18f
                val oy = jitter + rnd() * base * 0.18f
                canvas.drawLine(stroke.x(i) + ox, stroke.y(i) + oy, stroke.x(i + 1) + ox, stroke.y(i + 1) + oy, paint)
            }
        }
        paint.alpha = baseAlpha
    }

    private fun buildPath(stroke: Stroke) {
        path.rewind()
        val p = stroke.points
        path.moveTo(p[0], p[1])
        if (stroke.pointCount == 1) { path.lineTo(p[0] + 0.1f, p[1] + 0.1f); return }
        for (i in 1 until stroke.pointCount - 1) {
            val cx = p[i * STRIDE]; val cy = p[i * STRIDE + 1]
            val mx = (cx + p[(i + 1) * STRIDE]) * 0.5f
            val my = (cy + p[(i + 1) * STRIDE + 1]) * 0.5f
            path.quadTo(cx, cy, mx, my)
        }
        val last = stroke.pointCount - 1
        path.lineTo(p[last * STRIDE], p[last * STRIDE + 1])
    }
}
