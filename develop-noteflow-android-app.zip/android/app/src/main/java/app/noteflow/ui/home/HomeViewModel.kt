package app.noteflow.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.noteflow.container
import app.noteflow.data.local.entity.FolderEntity
import app.noteflow.data.local.entity.NoteWithTags
import app.noteflow.data.local.entity.TagEntity
import app.noteflow.data.repository.NoteSort
import app.noteflow.domain.model.PageOrientation
import app.noteflow.domain.model.PageSizePreset
import app.noteflow.domain.model.PageSpec
import app.noteflow.domain.model.PageTemplate
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeFilter(
    val folderId: String? = null,
    val query: String = "",
    val sort: NoteSort = NoteSort.UPDATED,
    val archived: Boolean = false,
    val favoritesOnly: Boolean = false,
    val tagId: String? = null,
    val showBin: Boolean = false
)

@OptIn(ExperimentalCoroutinesApi::class)
class HomeViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = app.container.repository
    private val settingsStore = app.container.settings

    private val _filter = MutableStateFlow(HomeFilter())
    val filter: StateFlow<HomeFilter> = _filter

    val settings = settingsStore.settings.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), app.noteflow.data.settings.AppSettings()
    )

    val notes: StateFlow<List<NoteWithTags>> = _filter.flatMapLatest { f ->
        when {
            f.showBin -> repo.observeBin()
            f.tagId != null -> repo.observeByTag(f.tagId)
            else -> repo.observeLibrary(f.folderId, f.query, f.sort, f.archived, f.favoritesOnly)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val folders: StateFlow<List<FolderEntity>> =
        repo.observeFolders().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val folderCounts: StateFlow<Map<String, Int>> = repo.observeFolderCounts()
        .combine(MutableStateFlow(Unit)) { counts, _ -> counts.associate { it.folderId to it.noteCount } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyMap())

    val tags: StateFlow<List<TagEntity>> =
        repo.observeTags().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val recent: StateFlow<List<NoteWithTags>> =
        repo.observeRecent().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    // ---- filter mutations ----
    fun setQuery(q: String) { _filter.value = _filter.value.copy(query = q) }
    fun setFolder(id: String?) { _filter.value = _filter.value.copy(folderId = id, tagId = null, showBin = false, archived = false) }
    fun setTag(id: String?) { _filter.value = _filter.value.copy(tagId = id, showBin = false) }
    fun setSort(sort: NoteSort) { _filter.value = _filter.value.copy(sort = sort) }
    fun setArchived(value: Boolean) { _filter.value = _filter.value.copy(archived = value, showBin = false, tagId = null) }
    fun setFavoritesOnly(value: Boolean) { _filter.value = _filter.value.copy(favoritesOnly = value) }
    fun setShowBin(value: Boolean) { _filter.value = _filter.value.copy(showBin = value, tagId = null, archived = false) }

    // ---- note actions ----
    fun createNote(onCreated: (String) -> Unit) = viewModelScope.launch {
        val s = settings.value
        val spec = PageSpec(
            size = PageSizePreset.fromId(s.defaultPageSizeId),
            orientation = PageOrientation.fromId(s.defaultOrientation),
            template = PageTemplate.fromId(s.defaultTemplateId)
        )
        onCreated(repo.createNote(folderId = _filter.value.folderId, spec = spec))
    }

    fun rename(id: String, title: String) = viewModelScope.launch { repo.rename(id, title) }
    fun duplicate(id: String) = viewModelScope.launch { repo.duplicateNote(id) }
    fun pin(id: String, value: Boolean) = viewModelScope.launch { repo.setPinned(id, value) }
    fun favorite(id: String, value: Boolean) = viewModelScope.launch { repo.setFavorite(id, value) }
    fun archive(id: String, value: Boolean) = viewModelScope.launch { repo.setArchived(id, value) }
    fun moveToFolder(id: String, folderId: String?) = viewModelScope.launch { repo.move(id, folderId) }
    fun delete(id: String) = viewModelScope.launch { repo.moveToBin(id) }
    fun restore(id: String) = viewModelScope.launch { repo.restore(id) }
    fun deleteForever(id: String) = viewModelScope.launch { repo.deleteForever(id) }
    fun emptyBin() = viewModelScope.launch { repo.emptyBin() }
    fun addTag(noteId: String, tag: String) = viewModelScope.launch { repo.addTag(noteId, tag) }
    fun removeTag(noteId: String, tagId: String) = viewModelScope.launch { repo.removeTag(noteId, tagId) }

    // ---- folders ----
    fun createFolder(name: String, parentId: String? = null) = viewModelScope.launch { repo.createFolder(name, parentId) }
    fun renameFolder(id: String, name: String) = viewModelScope.launch { repo.renameFolder(id, name) }
    fun deleteFolder(id: String) = viewModelScope.launch {
        if (_filter.value.folderId == id) setFolder(null)
        repo.deleteFolder(id)
    }
}
