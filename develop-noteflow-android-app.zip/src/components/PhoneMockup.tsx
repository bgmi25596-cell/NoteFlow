export default function PhoneMockup() {
  const ruleYs = Array.from({ length: 12 }, (_, i) => 150 + i * 26);

  return (
    <svg viewBox="0 0 320 620" className="h-[min(72vh,620px)] w-auto drop-shadow-2xl" role="img" aria-label="NoteFlow editor preview">
      <defs>
        <linearGradient id="glass" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#1b2423" />
          <stop offset="100%" stopColor="#0d1312" />
        </linearGradient>
        <linearGradient id="ink" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#0E7C7B" />
          <stop offset="100%" stopColor="#2f9f8e" />
        </linearGradient>
      </defs>

      <rect x="2" y="2" width="316" height="616" rx="40" fill="url(#glass)" stroke="#2c3a39" strokeWidth="2" />
      <rect x="14" y="14" width="292" height="592" rx="30" fill="#FBFAF7" />

      {/* top bar */}
      <rect x="14" y="14" width="292" height="60" rx="30" fill="#ffffff" />
      <rect x="14" y="54" width="292" height="20" fill="#ffffff" />
      <path d="M38 44l-8 0M34 40l-4 4 4 4" stroke="#14181A" strokeWidth="2" strokeLinecap="round" fill="none" />
      <text x="56" y="40" fontSize="13" fontWeight="600" fill="#14181A">Chemistry · Week 4</text>
      <text x="56" y="56" fontSize="9.5" fill="#6b7775">Saved 10:24:07 · local only</text>
      <circle cx="250" cy="44" r="10" fill="#EAF4F3" />
      <path d="M246 44h8M250 40v8" stroke="#0E7C7B" strokeWidth="1.8" strokeLinecap="round" />
      <circle cx="280" cy="44" r="10" fill="#EAF4F3" />
      <circle cx="276.5" cy="44" r="1.3" fill="#0E7C7B" />
      <circle cx="280" cy="44" r="1.3" fill="#0E7C7B" />
      <circle cx="283.5" cy="44" r="1.3" fill="#0E7C7B" />

      {/* page sheet */}
      <rect x="28" y="86" width="264" height="378" rx="6" fill="#ffffff" stroke="#e4e9e8" />
      {ruleYs.map((y) => (
        <line key={y} x1="40" y1={y} x2="280" y2={y} stroke="#cfe3e1" strokeWidth="0.9" />
      ))}
      <line x1="66" y1="96" x2="66" y2="456" stroke="#f0c9c9" strokeWidth="1" />

      {/* handwriting */}
      <path
        d="M78 142c6-16 11-18 14-6s2 16 7 16 7-10 11-16 8-4 9 4 3 10 8 6 8-12 13-12"
        stroke="url(#ink)"
        strokeWidth="2.6"
        fill="none"
        strokeLinecap="round"
      />
      <path
        d="M78 170c10-2 18-10 28-10s10 12 20 12 14-12 24-12 12 10 22 8"
        stroke="#101418"
        strokeWidth="2.1"
        fill="none"
        strokeLinecap="round"
      />
      <path
        d="M78 198h120"
        stroke="#f2d24b"
        strokeWidth="12"
        strokeLinecap="round"
        opacity="0.45"
      />
      <path
        d="M78 196c14-3 26 4 40 1s28-6 42 2"
        stroke="#101418"
        strokeWidth="2"
        fill="none"
        strokeLinecap="round"
      />
      {/* snapped shapes */}
      <rect x="80" y="226" width="78" height="52" rx="3" stroke="#2B5BD7" strokeWidth="2" fill="none" />
      <circle cx="210" cy="252" r="26" stroke="#B3261E" strokeWidth="2" fill="none" />
      <path d="M160 252h22" stroke="#1B7F3B" strokeWidth="2" strokeLinecap="round" />
      <path d="M176 247l6 5-6 5" stroke="#1B7F3B" strokeWidth="2" strokeLinecap="round" fill="none" />
      <path
        d="M80 310c12-14 20 10 32-2s16-16 26-4 18 16 30 2 20-12 32 2"
        stroke="#4b4f55"
        strokeWidth="1.8"
        fill="none"
        strokeLinecap="round"
        opacity="0.75"
      />
      <path
        d="M80 352c18-6 26 8 44 2s30-10 46-2 28 8 44-4"
        stroke="#101418"
        strokeWidth="2.2"
        fill="none"
        strokeLinecap="round"
      />
      <rect x="76" y="388" width="140" height="40" rx="4" stroke="#0E7C7B" strokeDasharray="7 5" strokeWidth="1.6" fill="#0E7C7B0f" />
      <text x="84" y="412" fontSize="10" fill="#0E7C7B">lasso selection · 12 strokes</text>

      {/* pen toolbar */}
      <rect x="20" y="474" width="280" height="62" rx="16" fill="#ffffff" stroke="#e4e9e8" />
      {["Pen", "Fountain", "Pencil", "Mark"].map((label, i) => (
        <g key={label}>
          <rect x={30 + i * 67} y={484} width="60" height="22" rx="11" fill={i === 0 ? "#D2F1EF" : "#F2F4F3"} />
          <text x={60 + i * 67} y={499} fontSize="9" textAnchor="middle" fill={i === 0 ? "#0E7C7B" : "#6b7775"}>
            {label}
          </text>
        </g>
      ))}
      {["#101418", "#0E7C7B", "#2B5BD7", "#B3261E", "#1B7F3B", "#B4690E"].map((color, i) => (
        <circle key={color} cx={40 + i * 26} cy={520} r={8} fill={color} stroke={i === 1 ? "#0E7C7B" : "#dfe4e3"} strokeWidth={i === 1 ? 2.5 : 1} />
      ))}
      <rect x="206" y="512" width="84" height="16" rx="8" fill="#F2F4F3" />
      <text x="248" y="523" fontSize="8.5" textAnchor="middle" fill="#6b7775">Finger: scroll</text>

      {/* page bar */}
      <rect x="20" y="544" width="280" height="44" rx="14" fill="#F7F9F8" stroke="#e4e9e8" />
      <text x="40" y="571" fontSize="10" fill="#14181A">Page 2 / 6</text>
      <rect x="150" y="556" width="104" height="20" rx="10" fill="#EAF4F3" />
      <text x="202" y="570" fontSize="8.5" textAnchor="middle" fill="#0E7C7B">A4 · 210 × 297 mm</text>
      <circle cx="276" cy="566" r="11" fill="#0E7C7B" />
      <path d="M271 566h10M276 561v10" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}
