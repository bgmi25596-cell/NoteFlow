package app.noteflow

import app.noteflow.domain.model.PageOrientation
import app.noteflow.domain.model.PageSizePreset
import app.noteflow.domain.model.PageSpec
import app.noteflow.domain.model.Units
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Verifies the physical page geometry that PDF export depends on. */
class PageSpecTest {

    @Test
    fun `mm to pt conversion matches the PDF point convention`() {
        assertEquals(72f, Units.mmToPt(25.4f), 0.001f)
        assertEquals(25.4f, Units.ptToMm(72f), 0.001f)
    }

    @Test
    fun `A series sizes are correct in points`() {
        assertEquals(595.28f, PageSizePreset.A4.widthPt, 0.05f)
        assertEquals(841.89f, PageSizePreset.A4.heightPt, 0.05f)
        assertEquals(841.89f, PageSizePreset.A3.widthPt, 0.05f)
        assertEquals(1190.55f, PageSizePreset.A3.heightPt, 0.05f)
        assertEquals(1190.55f, PageSizePreset.A2.widthPt, 0.05f)
        assertEquals(1683.78f, PageSizePreset.A2.heightPt, 0.05f)
        assertEquals(419.53f, PageSizePreset.A5.widthPt, 0.05f)
        assertEquals(595.28f, PageSizePreset.A5.heightPt, 0.05f)
        assertEquals(297.64f, PageSizePreset.A6.widthPt, 0.05f)
        assertEquals(419.53f, PageSizePreset.A6.heightPt, 0.05f)
    }

    @Test
    fun `landscape swaps width and height but keeps the sheet`() {
        val portrait = PageSpec(size = PageSizePreset.A4, orientation = PageOrientation.PORTRAIT)
        val landscape = portrait.copy(orientation = PageOrientation.LANDSCAPE)
        assertEquals(portrait.widthPt, landscape.heightPt, 0.001f)
        assertEquals(portrait.heightPt, landscape.widthPt, 0.001f)
        assertTrue(landscape.aspectRatio > 1f)
    }

    @Test
    fun `A series halves area each step so aspect ratio is constant`() {
        val ratios = listOf(PageSizePreset.A2, PageSizePreset.A3, PageSizePreset.A4, PageSizePreset.A5, PageSizePreset.A6)
            .map { it.heightPt / it.widthPt }
        ratios.forEach { assertEquals(1.414f, it, 0.01f) }
    }

    @Test
    fun `infinite canvas is not treated as a fixed sheet`() {
        assertTrue(PageSizePreset.A4.isFixedSheet)
        assertTrue(!PageSizePreset.INFINITE.isFixedSheet)
    }
}
