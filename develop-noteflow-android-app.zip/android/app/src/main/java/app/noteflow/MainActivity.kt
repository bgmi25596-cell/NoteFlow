package app.noteflow

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import app.noteflow.ui.NoteFlowApp

class MainActivity : ComponentActivity() {

    @OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            // Window size class drives the phone / tablet layouts; the activity handles
            // rotation itself (configChanges) so a drawing is never torn down mid-stroke.
            val sizeClass = calculateWindowSizeClass(this)
            NoteFlowApp(windowSizeClass = sizeClass)
        }
    }
}
