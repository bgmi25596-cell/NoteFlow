package app.noteflow.data.local.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import app.noteflow.data.local.entity.FolderEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FolderDao {

    @Upsert
    suspend fun upsert(folder: FolderEntity)

    @Query("SELECT * FROM folders WHERE deletedAt IS NULL ORDER BY sortIndex ASC, LOWER(name) ASC")
    fun observeAll(): Flow<List<FolderEntity>>

    @Query("SELECT * FROM folders WHERE deletedAt IS NULL AND parentId IS :parentId ORDER BY sortIndex ASC, LOWER(name) ASC")
    fun observeChildren(parentId: String?): Flow<List<FolderEntity>>

    @Query("SELECT * FROM folders WHERE id = :id")
    suspend fun findById(id: String): FolderEntity?

    @Query("UPDATE folders SET name = :name, updatedAt = :now WHERE id = :id")
    suspend fun rename(id: String, name: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE folders SET parentId = :parentId, updatedAt = :now WHERE id = :id")
    suspend fun move(id: String, parentId: String?, now: Long = System.currentTimeMillis())

    @Query("DELETE FROM folders WHERE id = :id")
    suspend fun delete(id: String)

    @Query(
        """
        SELECT folders.id AS folderId, COUNT(notes.id) AS noteCount
        FROM folders LEFT JOIN notes
          ON notes.folderId = folders.id AND notes.deletedAt IS NULL AND notes.isArchived = 0
        GROUP BY folders.id
        """
    )
    fun observeCounts(): Flow<List<FolderCount>>

    @Query("SELECT * FROM folders")
    suspend fun allForBackup(): List<FolderEntity>
}

data class FolderCount(val folderId: String, val noteCount: Int)
