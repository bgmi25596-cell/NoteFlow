package app.noteflow.ink

import app.noteflow.domain.model.STRIDE

/**
 * Stroke conditioning.
 *
 * Raw touch input is noisy and arrives in irregular bursts. Two independent steps:
 *
 *  1. [filter] — a one-euro-style low pass applied LIVE while the finger/pen is down.
 *     It removes tremor without adding the visible lag a plain moving average causes.
 *  2. [resampleCatmullRom] — applied ONCE when the stroke is lifted. It produces evenly
 *     spaced points along a Catmull-Rom spline, which makes stored strokes compact,
 *     stable to re-render at any zoom, and well behaved for later beautification.
 *
 * Both work on the packed [x, y, pressure, tMs] buffer, so no object allocation per point.
 */
object StrokeSmoother {

    /** Live smoothing: exponential filter whose strength falls as speed rises. */
    class LiveFilter(private val minAlpha: Float = 0.35f, private val maxAlpha: Float = 0.95f) {
        private var hasPrev = false
        private var px = 0f
        private var py = 0f

        fun reset() { hasPrev = false }

        fun filter(x: Float, y: Float): FloatArray {
            if (!hasPrev) {
                px = x; py = y; hasPrev = true
                return floatArrayOf(x, y)
            }
            val dist = kotlin.math.hypot(x - px, y - py)
            // Fast movement -> trust the input (alpha high). Slow -> smooth hard.
            val alpha = (minAlpha + (maxAlpha - minAlpha) * (dist / 12f)).coerceIn(minAlpha, maxAlpha)
            px += (x - px) * alpha
            py += (y - py) * alpha
            return floatArrayOf(px, py)
        }
    }

    /**
     * Uniformly resample a packed buffer along a Catmull-Rom spline.
     * @param spacing target distance between output points, in page points.
     */
    fun resampleCatmullRom(src: FloatArray, count: Int, spacing: Float = 1.2f): Pair<FloatArray, Int> {
        if (count < 3) return src.copyOf(count * STRIDE) to count

        val out = ArrayList<Float>(count * STRIDE)
        fun emit(x: Float, y: Float, p: Float, t: Float) { out.add(x); out.add(y); out.add(p); out.add(t) }

        emit(src[0], src[1], src[2], src[3])
        var carry = 0f

        for (i in 0 until count - 1) {
            val i0 = (i - 1).coerceAtLeast(0)
            val i1 = i
            val i2 = (i + 1).coerceAtMost(count - 1)
            val i3 = (i + 2).coerceAtMost(count - 1)

            val x0 = src[i0 * STRIDE]; val y0 = src[i0 * STRIDE + 1]
            val x1 = src[i1 * STRIDE]; val y1 = src[i1 * STRIDE + 1]
            val x2 = src[i2 * STRIDE]; val y2 = src[i2 * STRIDE + 1]
            val x3 = src[i3 * STRIDE]; val y3 = src[i3 * STRIDE + 1]

            val segLen = kotlin.math.hypot(x2 - x1, y2 - y1)
            val steps = kotlin.math.max(1, kotlin.math.ceil((segLen + carry) / spacing).toInt())

            for (s in 1..steps) {
                val t = s.toFloat() / steps
                val t2 = t * t
                val t3 = t2 * t
                val x = 0.5f * ((2 * x1) + (-x0 + x2) * t + (2 * x0 - 5 * x1 + 4 * x2 - x3) * t2 + (-x0 + 3 * x1 - 3 * x2 + x3) * t3)
                val y = 0.5f * ((2 * y1) + (-y0 + y2) * t + (2 * y0 - 5 * y1 + 4 * y2 - y3) * t2 + (-y0 + 3 * y1 - 3 * y2 + y3) * t3)
                val p = src[i1 * STRIDE + 2] + (src[i2 * STRIDE + 2] - src[i1 * STRIDE + 2]) * t
                val tm = src[i1 * STRIDE + 3] + (src[i2 * STRIDE + 3] - src[i1 * STRIDE + 3]) * t
                emit(x, y, p, tm)
            }
            carry = 0f
        }

        val array = FloatArray(out.size) { out[it] }
        return array to (array.size / STRIDE)
    }

    /** Pressure smoothing so a shaky pressure sensor does not create lumpy strokes. */
    fun smoothPressure(buffer: FloatArray, count: Int, window: Int = 3) {
        if (count < window * 2) return
        val original = FloatArray(count) { buffer[it * STRIDE + 2] }
        for (i in 0 until count) {
            var sum = 0f
            var n = 0
            for (k in -window..window) {
                val j = i + k
                if (j in 0 until count) { sum += original[j]; n++ }
            }
            buffer[i * STRIDE + 2] = sum / n
        }
    }
}
