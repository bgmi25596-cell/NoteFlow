package app.noteflow.ui.settings

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.noteflow.NoteFlowApplication
import app.noteflow.data.backup.ImportMode
import app.noteflow.data.backup.ImportResult
import app.noteflow.data.settings.AppSettings
import app.noteflow.data.settings.ThemeMode
import app.noteflow.domain.model.PageSizePreset
import app.noteflow.domain.model.PageTemplate
import app.noteflow.ink.InkCanvasView
import app.noteflow.ui.theme.Accents
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val container = (context.applicationContext as NoteFlowApplication).container
    val scope = rememberCoroutineScope()
    val settings by container.settings.settings.collectAsStateWithLifecycle(initialValue = AppSettings())
    var pendingImportUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var busy by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val result = container.backup.export(uri, "0.3.0-phase2")
            busy = false
            Toast.makeText(
                context,
                result.fold({ "Backup saved (${it / 1024} KB)" }, { "Backup failed: ${it.message}" }),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) pendingImportUri = uri }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Section("Appearance")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(
                        selected = settings.themeMode == mode,
                        onClick = { scope.launch { container.settings.setTheme(mode) } },
                        label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) }
                    )
                }
            }
            Text("Accent colour", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Accents.forEachIndexed { index, palette ->
                    Surface(
                        shape = CircleShape,
                        color = palette.primary,
                        modifier = Modifier
                            .size(36.dp)
                            .clickable { scope.launch { container.settings.setAccent(index) } }
                    ) {
                        if (settings.accentIndex == index) {
                            Icon(Icons.Filled.Check, null, tint = palette.onPrimary, modifier = Modifier.padding(8.dp))
                        }
                    }
                }
            }
            SwitchRow("Larger controls (bigger touch targets)", settings.largeTouchTargets) {
                scope.launch { container.settings.setLargeTargets(it) }
            }

            Section("New pages")
            Text("Default size", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(PageSizePreset.A4, PageSizePreset.A5, PageSizePreset.A6, PageSizePreset.A3).forEach { size ->
                    FilterChip(
                        selected = settings.defaultPageSizeId == size.id,
                        onClick = {
                            scope.launch {
                                container.settings.setDefaultPage(size.id, settings.defaultTemplateId, settings.defaultOrientation)
                            }
                        },
                        label = { Text(size.id) }
                    )
                }
            }
            Text("Default template", style = MaterialTheme.typography.labelLarge)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                PageTemplate.entries.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { t ->
                            FilterChip(
                                selected = settings.defaultTemplateId == t.id,
                                onClick = {
                                    scope.launch {
                                        container.settings.setDefaultPage(settings.defaultPageSizeId, t.id, settings.defaultOrientation)
                                    }
                                },
                                label = { Text(t.label) }
                            )
                        }
                    }
                }
            }

            Section("Writing")
            Text("What a finger does", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                InkCanvasView.FingerPolicy.entries.forEach { policy ->
                    FilterChip(
                        selected = settings.fingerPolicy == policy,
                        onClick = { scope.launch { container.settings.setFingerPolicy(policy) } },
                        label = { Text(policy.name.lowercase().replaceFirstChar { it.uppercase() }) }
                    )
                }
            }
            Text(
                "When a stylus is detected it always takes priority and finger touches are " +
                    "ignored for about a second (palm rejection). Quality depends on your " +
                    "hardware: phones without a digitiser report every contact as a finger.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text("Pressure response ${(settings.pressureResponse * 100).toInt()}%", style = MaterialTheme.typography.labelLarge)
            Slider(
                value = settings.pressureResponse,
                onValueChange = { scope.launch { container.settings.setPressure(it) } },
                valueRange = 0f..1f
            )
            SwitchRow("Snap hand-drawn shapes", settings.shapeSnap) {
                scope.launch { container.settings.setShapeSnap(it) }
            }
            SwitchRow("Lock zoom while writing", settings.zoomLock) {
                scope.launch { container.settings.setZoomLock(it) }
            }
            Text("Autosave delay: ${settings.autosaveSeconds}s", style = MaterialTheme.typography.labelLarge)
            Slider(
                value = settings.autosaveSeconds.toFloat(),
                onValueChange = { scope.launch { container.settings.setAutosaveSeconds(it.toInt()) } },
                valueRange = 1f..10f,
                steps = 8
            )

            Section("Backup (local file)")
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        "Notes live only on this phone. If the device is lost, reset or the app is " +
                            "uninstalled, the notes go with it — on-device storage is not a backup.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        "Export writes one .noteflow.json file containing every note, folder, tag and " +
                            "page, with handwriting stored as lossless vector data.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = !busy, onClick = { exportLauncher.launch("noteflow-backup.json") }) { Text("Export backup") }
                OutlinedButton(enabled = !busy, onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }) { Text("Import backup") }
            }

            Section("About")
            Text(
                "NoteFlow 0.3.0 (Phases 1–3 implemented). No account, no subscription, no ads, " +
                    "no analytics, and the app does not request the INTERNET permission.",
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                "Implemented and testable today: notes, folders, subfolders, tags, search, sort, " +
                    "pin, favourite, archive, recycle bin, autosave, vector ink engine with seven " +
                    "pens, two erasers, lasso, shape snapping, ruler, undo/redo, A2–A6 + Letter " +
                    "pages in both orientations, 11 templates, custom template presets, PDF export " +
                    "and JSON backup/restore.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                "Not implemented yet (Phases 4–6): PDF import/annotation, images, audio recording, " +
                    "OCR/text search of handwriting and study tools. They are not shown as buttons " +
                    "anywhere, because a control that does nothing is worse than no control.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(32.dp))
        }
    }

    pendingImportUri?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingImportUri = null },
            title = { Text("Import backup") },
            text = {
                Text(
                    "MERGE keeps your current notes and adds the ones in the file (a note with the " +
                        "same id is overwritten).\n\nREPLACE deletes everything currently in NoteFlow " +
                        "first — including handwriting files — and cannot be undone."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    pendingImportUri = null
                    scope.launch {
                        busy = true
                        val result = container.backup.import(uri, ImportMode.MERGE)
                        busy = false
                        Toast.makeText(context, result.describe(), Toast.LENGTH_LONG).show()
                    }
                }) { Text("Merge") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { pendingImportUri = null }) { Text("Cancel") }
                    TextButton(onClick = {
                        pendingImportUri = null
                        scope.launch {
                            busy = true
                            val result = container.backup.import(uri, ImportMode.REPLACE)
                            busy = false
                            Toast.makeText(context, result.describe(), Toast.LENGTH_LONG).show()
                        }
                    }) { Text("Replace everything") }
                }
            }
        )
    }
}

private fun ImportResult.describe(): String = when (this) {
    is ImportResult.Success -> "Imported $notes note(s), $pages page(s), $folders folder(s)."
    is ImportResult.Invalid -> "Invalid backup: $reason"
    is ImportResult.Failure -> reason
}

@Composable
private fun Section(title: String) {
    Spacer(Modifier.height(6.dp))
    HorizontalDivider()
    Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Suppress("unused")
@Composable
private fun UnusedBoxKeepsImport() { Box(Modifier.size(0.dp)) }
