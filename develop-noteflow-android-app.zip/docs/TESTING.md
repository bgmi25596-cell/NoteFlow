# Testing NoteFlow

## What is automatically verified in CI

`gradle testDebugUnitTest` runs on every workflow run (JVM, no device needed):

| Test | File | Checks |
|---|---|---|
| Page geometry | `PageSpecTest.kt` | mm→pt conversion, exact A2–A6 point sizes, landscape swap, √2 aspect ratio, infinite-canvas flag |
| Ink format | `InkCodecTest.kt` | lossless save/load of strokes, pressure and tool; graceful recovery from a truncated file; id continuity |
| Ink tools | `InkToolsTest.kt` | Catmull-Rom resampling stays in bounds; line & ellipse recognition; handwriting is *not* "corrected"; refiner preserves stroke count and position; text-line grouping |

These are the only claims that are machine-verified today. **Everything below must be run
by hand on a real device** — this build has not been executed on physical hardware by the
author of this commit, so treat the list as a checklist, not as a passed result.

## Manual checklist (Phase 1–3)

### Notes & storage
1. Create a note, draw, wait 2 s → top bar shows "Saved HH:MM:SS".
2. Kill the app from Recents, reopen → the strokes are still there.
3. Rename, duplicate, pin, favourite, archive a note; verify each in the list.
4. Move a note to the bin → it disappears from All notes, appears in Recycle bin.
5. Restore it; then bin it again and use Empty bin → confirm it is gone and
   `files/notes/<id>/` has been removed (visible via the backup export size).
6. Create folders and a subfolder; move notes between them; delete a folder and confirm
   the notes survive in All notes.
7. Search by title and by snippet; try each sort order.
8. Add tags, filter by tag chip.
9. Settings → Export backup, then Import backup (Merge) → counts reported in the toast.
10. Import a deliberately broken JSON → must show "Invalid backup: …" and change nothing.
11. Import with **Replace everything** on a throwaway device/profile only — confirm the
    warning text appears first.

### Pages & templates
12. For each of A2, A3, A4, A5, A6, Letter: create a page, confirm the aspect ratio looks
    right and the chip in the page bar shows the mm size.
13. Switch each one to landscape, confirm the sheet rotates (width/height swap).
14. Walk through all 11 templates; change grid spacing, margin, page colour, line colour.
15. Save a custom preset, create a new page from it, delete the preset.
16. Add, duplicate, reorder and delete pages; confirm the last page cannot be deleted.
17. Switch to Infinite canvas and confirm the UI labels it as not a fixed sheet.

### Ink engine
18. Draw with every pen; vary speed and (with a stylus) pressure.
19. Highlighter over text: colour multiplies instead of covering.
20. Stroke eraser removes whole strokes; "Erase part" splits a stroke into two pieces.
21. Undo/redo 10+ operations including erase, lasso move, scale, rotate, tidy.
22. Lasso: select, drag, scale ±, rotate, copy, paste, duplicate, delete.
23. Shape snapping on: draw a line, arrow, rectangle, triangle, circle.
24. Ruler on: strokes become perfectly straight at the chosen angle.
25. Pinch zoom, two-finger pan, double-tap to fit, zoom lock.
26. Finger policy: Draw / Scroll / Zoom-only / Ignore all behave as labelled.
27. Rotate the device mid-note: no crash, no lost ink (the activity handles the config
    change itself).

### Stylus & palm rejection (hardware dependent)
28. On a device with an active pen (e.g. a tablet with an EMR/AES stylus): rest your palm
    and write — palm contacts within ~0.9 s of pen input are dropped.
29. Flip the pen (if it reports `TOOL_TYPE_ERASER`) or hold the barrel button → erases.
30. On a phone with no digitiser, confirm the app still works with the finger policy and
    **does not claim** palm rejection.
Record the device model and result; limitations must be documented, not hidden.

### Export
31. Export a multi-page note to PDF; open it in a PDF viewer; check page count, page size
    (A4 should report 210 × 297 mm) and that strokes are crisp when zoomed (vector, not a
    screenshot).

### Privacy
32. Settings → App info → Permissions: NoteFlow requests **no** permissions.
33. Turn on flight mode and use every feature — nothing degrades.

## Reporting
Please record failures with: device, Android version, stylus (yes/no), steps, expected vs
actual. Attach the exported backup JSON when the bug involves data.
