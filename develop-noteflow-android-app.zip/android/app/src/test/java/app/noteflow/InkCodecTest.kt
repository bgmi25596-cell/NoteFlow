package app.noteflow

import app.noteflow.data.files.InkCodec
import app.noteflow.domain.model.InkBrush
import app.noteflow.domain.model.InkDocument
import app.noteflow.domain.model.InkTool
import app.noteflow.domain.model.Stroke
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

/** Round-trips the vector ink format: strokes must survive save/load bit-for-bit. */
class InkCodecTest {

    private fun stroke(id: Long, tool: InkTool, points: Int): Stroke {
        val buffer = FloatArray(points * 4)
        for (i in 0 until points) {
            buffer[i * 4] = i * 1.5f
            buffer[i * 4 + 1] = 10f + i * 0.75f
            buffer[i * 4 + 2] = 0.2f + (i % 5) * 0.1f
            buffer[i * 4 + 3] = i.toFloat()
        }
        return Stroke(id, InkBrush(tool = tool, colorArgb = 0xFF112233.toInt(), widthPt = 3.25f), buffer, points)
            .also { it.recomputeBounds() }
    }

    @Test
    fun `round trip preserves strokes, points, pressure and tool`() {
        val doc = InkDocument()
        doc.add(stroke(1, InkTool.PEN, 120))
        doc.add(stroke(2, InkTool.HIGHLIGHTER, 40))
        doc.add(stroke(3, InkTool.FOUNTAIN, 400))

        val out = ByteArrayOutputStream()
        InkCodec.write(out, doc)
        val restored = InkCodec.read(ByteArrayInputStream(out.toByteArray()))

        assertEquals(3, restored.strokes.size)
        doc.strokes.forEachIndexed { index, original ->
            val copy = restored.strokes[index]
            assertEquals(original.id, copy.id)
            assertEquals(original.pointCount, copy.pointCount)
            assertEquals(original.brush.tool, copy.brush.tool)
            assertEquals(original.brush.colorArgb, copy.brush.colorArgb)
            assertEquals(original.brush.widthPt, copy.brush.widthPt, 0.0001f)
            for (i in 0 until original.pointCount) {
                assertEquals(original.x(i), copy.x(i), 0.0001f)
                assertEquals(original.y(i), copy.y(i), 0.0001f)
                assertEquals(original.pressure(i), copy.pressure(i), 0.0001f)
            }
        }
    }

    @Test
    fun `truncated file recovers the strokes that were fully written`() {
        val doc = InkDocument()
        doc.add(stroke(1, InkTool.PEN, 50))
        doc.add(stroke(2, InkTool.PENCIL, 50))
        val bytes = ByteArrayOutputStream().also { InkCodec.write(it, doc) }.toByteArray()

        val truncated = bytes.copyOf(bytes.size - 120)
        val restored = InkCodec.read(ByteArrayInputStream(truncated))
        assertTrue("expected a partial but non-crashing read", restored.strokes.size in 0..2)
    }

    @Test
    fun `next id continues after the highest restored id`() {
        val doc = InkDocument()
        doc.add(stroke(7, InkTool.BRUSH, 10))
        val bytes = ByteArrayOutputStream().also { InkCodec.write(it, doc) }.toByteArray()
        val restored = InkCodec.read(ByteArrayInputStream(bytes))
        assertEquals(8L, restored.newId())
    }
}
