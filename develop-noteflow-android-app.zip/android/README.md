# NoteFlow — local-first Android notes & handwriting

Kotlin · Jetpack Compose · custom Canvas ink engine · Room/SQLite · 100 % offline.
No account, no subscription, no ads, no analytics, **no INTERNET permission**.

---

## Build the APK with only an Android phone (free, no PC)

You never have to type code or install Android Studio.

1. Create a free GitHub account in your phone browser.
2. Create a new **public** repository, e.g. `noteflow`.
3. Upload this project (keep the folder structure: `android/`, `.github/`).
   *Easiest path on a phone:* open your repo → **Add file → Upload files**, or use the
   free **Acode**/**MGit** apps to clone & push.
4. Open the **Actions** tab → **Build NoteFlow APK** → **Run workflow**.
5. Wait ~5–8 minutes. Open the finished run → **Artifacts** → download
   `NoteFlow-debug-apk`.
6. Unzip it with any file manager, tap `app-debug.apk`, allow
   “Install unknown apps” for your browser/file manager, and install.

The workflow (`.github/workflows/android-build.yml`) also runs the unit tests and uploads
the HTML test report as a second artifact.

### Building on a computer (optional)

```bash
cd android
./gradlew assembleDebug        # or: gradle assembleDebug  (Gradle 8.9, JDK 17)
./gradlew testDebugUnitTest
```

The debug APK is signed with the automatically generated debug keystore, so there is
nothing to configure. For a release build you would create your own keystore — not needed
for personal use.

---

## Where each feature lives

| Feature | Files |
|---|---|
| App entry, DI container | `app/src/main/java/app/noteflow/NoteFlowApplication.kt`, `MainActivity.kt` |
| Navigation, theming | `ui/NoteFlowApp.kt`, `ui/theme/Theme.kt` |
| First-run experience | `ui/onboarding/WelcomeScreen.kt` |
| Home: search, folders, tags, sort, bin | `ui/home/HomeScreen.kt`, `ui/home/HomeViewModel.kt` |
| Editor UI, pen toolbar, page bar | `ui/editor/EditorScreen.kt` |
| Page setup / templates / tidy sheets | `ui/editor/EditorSheets.kt` |
| Editor state + autosave | `ui/editor/EditorViewModel.kt` |
| **Ink engine (MotionEvent, stylus, palm rejection)** | `ink/InkCanvasView.kt` |
| Stroke rendering (7 pens) | `ink/InkRenderer.kt` |
| Smoothing / resampling | `ink/StrokeSmoother.kt` |
| Undo/redo commands | `ink/InkHistory.kt` |
| Shape snapping | `ink/ShapeRecognizer.kt` |
| Paper templates | `ink/TemplateRenderer.kt` |
| Page geometry (A2–A6, pt maths) | `domain/model/PageSpec.kt` |
| Vector stroke model | `domain/model/Ink.kt` |
| Tidy handwriting (geometric) | `domain/beautify/HandwritingRefiner.kt` |
| Room schema | `data/local/entity/Entities.kt`, `data/local/NoteFlowDatabase.kt`, `data/local/Migrations.kt` |
| DAOs | `data/local/dao/*.kt` |
| Repository (single source of truth) | `data/repository/NotesRepository.kt` |
| File store (ink/media, atomic writes) | `data/files/FileStore.kt` |
| Ink binary format | `data/files/InkCodec.kt` |
| JSON backup/restore + validation | `data/backup/BackupManager.kt` |
| PDF export | `export/PdfExporter.kt` |
| Settings (DataStore) | `data/settings/SettingsStore.kt`, `ui/settings/SettingsScreen.kt` |
| Unit tests | `app/src/test/java/app/noteflow/*.kt` |

---

## Honest status

Implemented (Phases 1–3) and covered by unit tests or manual test steps in
`docs/TESTING.md`:

* notes, folders + subfolders, tags, search, sorting, pin, favourite, archive,
  duplicate, rename, recycle bin with restore, empty bin
* debounced autosave with visible *Saving / Saved / error + Retry* status
* vector ink engine: pen, ballpoint, fountain, pencil, brush, calligraphy, highlighter
* stroke eraser **and** partial ("pixel") eraser that splits strokes
* lasso select → move, scale, rotate, copy, paste, duplicate, delete
* shape snapping (line, arrow, rectangle, triangle, ellipse), ruler, grid snap
* pinch zoom, pan, zoom lock, double-tap fit, per-page viewport persistence
* undo/redo for strokes, erases, transforms and tidy operations
* A2/A3/A4/A5/A6/Letter + infinite canvas, portrait & landscape, 11 templates,
  custom colours/spacing/margins, built-in and user template presets
* multi-page notes: add, duplicate, reorder, delete, navigate
* PDF export via the platform `PdfDocument` (true page sizes, vector strokes)
* local JSON backup/import with format validation and explicit overwrite warning

Not implemented yet — and deliberately not shown as dead buttons anywhere in the UI:

* Phase 4: PDF **import**/annotation, images, text boxes, tables, audio recording
* Phase 5: any neural handwriting beautifier (see the honest note in
  `domain/beautify/HandwritingRefiner.kt`)
* Phase 6: OCR, handwriting text search, summaries/flashcards/quizzes

Device-dependent: pressure, tilt and palm rejection depend on the digitiser. Phones with
no active stylus report every contact as a finger, so "stylus priority" has nothing to
prioritise there. This has **not** been verified on physical stylus hardware by the author
of this commit — see `docs/TESTING.md` for the exact checklist to run on your device.
