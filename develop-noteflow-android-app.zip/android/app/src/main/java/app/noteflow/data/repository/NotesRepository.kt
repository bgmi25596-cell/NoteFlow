package app.noteflow.data.repository

import android.util.Log
import app.noteflow.data.files.FileStore
import app.noteflow.data.files.InkCodec
import app.noteflow.data.local.NoteFlowDatabase
import app.noteflow.data.local.entity.AttachmentEntity
import app.noteflow.data.local.entity.FolderEntity
import app.noteflow.data.local.entity.NoteEntity
import app.noteflow.data.local.entity.NoteTagCrossRef
import app.noteflow.data.local.entity.NoteWithTags
import app.noteflow.data.local.entity.PageEntity
import app.noteflow.data.local.entity.TagEntity
import app.noteflow.data.local.entity.TemplatePresetEntity
import app.noteflow.domain.model.InkDocument
import app.noteflow.domain.model.PageOrientation
import app.noteflow.domain.model.PageSizePreset
import app.noteflow.domain.model.PageSpec
import app.noteflow.domain.model.PageTemplate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

/** Sort options exposed in the home screen; the integer is what NoteDao's SQL switches on. */
enum class NoteSort(val sqlIndex: Int, val label: String) {
    UPDATED(0, "Last edited"),
    CREATED(1, "Date created"),
    TITLE_ASC(2, "Title A–Z"),
    TITLE_DESC(3, "Title Z–A"),
    OPENED(4, "Recently opened")
}

/**
 * The single place the UI talks to for notes. It coordinates the two storage systems —
 * Room (metadata) and the file store (ink/media) — so they can never drift apart:
 * deleting a note's row also deletes its files, duplicating a note copies its ink files.
 */
class NotesRepository(
    private val db: NoteFlowDatabase,
    val files: FileStore
) {
    private val notes get() = db.noteDao()
    private val folders get() = db.folderDao()
    private val pages get() = db.pageDao()

    // ----------------------------------------------------------- observation
    fun observeLibrary(folderId: String?, query: String, sort: NoteSort, archived: Boolean, favoritesOnly: Boolean) =
        notes.observeLibrary(folderId, query.trim(), sort.sqlIndex, archived, favoritesOnly)

    fun observeRecent(): Flow<List<NoteWithTags>> = notes.observeRecent()
    fun observeBin(): Flow<List<NoteWithTags>> = notes.observeRecycleBin()
    fun observeFolders(): Flow<List<FolderEntity>> = folders.observeAll()
    fun observeFolderCounts() = folders.observeCounts()
    fun observeTags(): Flow<List<TagEntity>> = notes.observeTags()
    fun observeNote(id: String) = notes.observe(id)
    fun observePages(noteId: String) = pages.observePages(noteId)
    fun observeAttachments(noteId: String) = pages.observeAttachments(noteId)
    fun observePresets() = pages.observePresets()

    // ----------------------------------------------------------- notes
    suspend fun createNote(
        title: String = "",
        folderId: String? = null,
        spec: PageSpec = PageSpec()
    ): String = withContext(Dispatchers.IO) {
        val noteId = UUID.randomUUID().toString()
        notes.upsert(NoteEntity(id = noteId, title = title, folderId = folderId))
        addPage(noteId, spec)
        noteId
    }

    suspend fun addPage(noteId: String, spec: PageSpec, atIndex: Int? = null): String = withContext(Dispatchers.IO) {
        val pageId = UUID.randomUUID().toString()
        val existing = pages.pagesOf(noteId)
        val index = atIndex ?: existing.size
        existing.filter { it.pageIndex >= index }.forEach { pages.setIndex(it.id, it.pageIndex + 1) }
        pages.upsert(
            PageEntity(
                id = pageId,
                noteId = noteId,
                pageIndex = index,
                pageSizeId = spec.size.id,
                orientation = spec.orientation.name,
                widthPt = spec.widthPt,
                heightPt = spec.heightPt,
                templateId = spec.template.id,
                backgroundArgb = spec.backgroundArgb,
                lineArgb = spec.lineArgb,
                gridSpacingMm = spec.gridSpacingMm,
                marginMm = spec.marginMm,
                inkFile = files.inkFileName(noteId, pageId)
            )
        )
        touch(noteId)
        pageId
    }

    suspend fun duplicatePage(pageId: String) = withContext(Dispatchers.IO) {
        val page = pages.findById(pageId) ?: return@withContext
        val newId = UUID.randomUUID().toString()
        val newRelative = files.inkFileName(page.noteId, newId)
        page.inkFile?.let { src ->
            val source = files.resolve(src)
            if (source.exists()) {
                files.writeAtomically(files.resolve(newRelative)) { out -> source.inputStream().use { it.copyTo(out) } }
            }
        }
        pages.pagesOf(page.noteId).filter { it.pageIndex > page.pageIndex }
            .forEach { pages.setIndex(it.id, it.pageIndex + 1) }
        pages.upsert(page.copy(id = newId, pageIndex = page.pageIndex + 1, inkFile = newRelative))
        touch(page.noteId)
    }

    suspend fun deletePage(pageId: String) = withContext(Dispatchers.IO) {
        val page = pages.findById(pageId) ?: return@withContext
        if (pages.countOf(page.noteId) <= 1) return@withContext // a note always keeps one page
        files.deleteQuietly(page.inkFile)
        pages.delete(pageId)
        pages.renumber(page.noteId)
        touch(page.noteId)
    }

    suspend fun movePage(pageId: String, newIndex: Int) = withContext(Dispatchers.IO) {
        val page = pages.findById(pageId) ?: return@withContext
        val list = pages.pagesOf(page.noteId).toMutableList()
        val from = list.indexOfFirst { it.id == pageId }
        if (from < 0) return@withContext
        val item = list.removeAt(from)
        list.add(newIndex.coerceIn(0, list.size), item)
        list.forEachIndexed { i, p -> pages.setIndex(p.id, i) }
        touch(page.noteId)
    }

    suspend fun updatePageSpec(pageId: String, spec: PageSpec) = withContext(Dispatchers.IO) {
        val page = pages.findById(pageId) ?: return@withContext
        pages.upsert(
            page.copy(
                pageSizeId = spec.size.id,
                orientation = spec.orientation.name,
                widthPt = spec.widthPt,
                heightPt = spec.heightPt,
                templateId = spec.template.id,
                backgroundArgb = spec.backgroundArgb,
                lineArgb = spec.lineArgb,
                gridSpacingMm = spec.gridSpacingMm,
                marginMm = spec.marginMm,
                updatedAt = System.currentTimeMillis()
            )
        )
        touch(page.noteId)
    }

    suspend fun duplicateNote(noteId: String): String? = withContext(Dispatchers.IO) {
        val note = notes.findById(noteId) ?: return@withContext null
        val copyId = UUID.randomUUID().toString()
        notes.upsert(
            note.copy(
                id = copyId,
                title = note.title.ifBlank { "Untitled" } + " (copy)",
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis(),
                isPinned = false
            )
        )
        pages.pagesOf(noteId).forEach { page ->
            val newPageId = UUID.randomUUID().toString()
            val relative = files.inkFileName(copyId, newPageId)
            page.inkFile?.let { src ->
                val source = files.resolve(src)
                if (source.exists()) {
                    files.writeAtomically(files.resolve(relative)) { out -> source.inputStream().use { it.copyTo(out) } }
                }
            }
            pages.upsert(page.copy(id = newPageId, noteId = copyId, inkFile = relative))
        }
        copyId
    }

    suspend fun rename(noteId: String, title: String) = notes.rename(noteId, title.trim())
    suspend fun setPinned(noteId: String, pinned: Boolean) = notes.setPinned(noteId, pinned)
    suspend fun setFavorite(noteId: String, favorite: Boolean) = notes.setFavorite(noteId, favorite)
    suspend fun setArchived(noteId: String, archived: Boolean) = notes.setArchived(noteId, archived)
    suspend fun move(noteId: String, folderId: String?) = notes.move(noteId, folderId)
    suspend fun moveToBin(noteId: String) = notes.moveToBin(noteId)
    suspend fun restore(noteId: String) = notes.restore(noteId)
    suspend fun touchOpened(noteId: String) = notes.touchOpened(noteId)
    suspend fun updateSnippet(noteId: String, snippet: String) = notes.updateSnippet(noteId, snippet.take(180))
    private suspend fun touch(noteId: String) = notes.findById(noteId)?.let {
        notes.update(it.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteForever(noteId: String) = withContext(Dispatchers.IO) {
        notes.hardDelete(noteId)       // CASCADE removes pages + attachments rows
        files.deleteNoteFiles(noteId)  // then the bytes on disk
    }

    suspend fun emptyBin() = withContext(Dispatchers.IO) {
        val ids = notes.binIds()
        notes.emptyBin()
        ids.forEach { files.deleteNoteFiles(it) }
    }

    // ----------------------------------------------------------- folders & tags
    suspend fun createFolder(name: String, parentId: String? = null): String = withContext(Dispatchers.IO) {
        val id = UUID.randomUUID().toString()
        folders.upsert(FolderEntity(id = id, name = name.trim().ifBlank { "New folder" }, parentId = parentId))
        id
    }

    suspend fun renameFolder(id: String, name: String) = folders.rename(id, name.trim())
    suspend fun moveFolder(id: String, parentId: String?) = folders.move(id, parentId)

    /** Deleting a folder keeps its notes: they fall back to "All notes" (FK SET NULL). */
    suspend fun deleteFolder(id: String) = folders.delete(id)

    suspend fun addTag(noteId: String, name: String) = withContext(Dispatchers.IO) {
        val clean = name.trim().removePrefix("#")
        if (clean.isEmpty()) return@withContext
        val tagId = "tag-" + clean.lowercase()
        notes.insertTag(TagEntity(id = tagId, name = clean))
        notes.link(NoteTagCrossRef(noteId, tagId))
        touch(noteId)
    }

    suspend fun removeTag(noteId: String, tagId: String) = notes.unlink(noteId, tagId)
    fun observeByTag(tagId: String) = notes.observeByTag(tagId)

    // ----------------------------------------------------------- ink i/o
    suspend fun loadInk(page: PageEntity): InkDocument = withContext(Dispatchers.IO) {
        val relative = page.inkFile ?: return@withContext InkDocument()
        try {
            InkCodec.readFile(files.resolve(relative))
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to load ink for page ${page.id}", t)
            InkDocument()
        }
    }

    /** Returns true on success. False means the UI must show a save-error banner. */
    suspend fun saveInk(page: PageEntity, doc: InkDocument): Boolean = withContext(Dispatchers.IO) {
        val relative = page.inkFile ?: files.inkFileName(page.noteId, page.id).also {
            pages.setInkFile(page.id, it)
        }
        if (!files.hasRoomFor(doc.strokes.sumOf { it.pointCount.toLong() } * 16 + 4096)) return@withContext false
        val ok = InkCodec.writeFile(files, files.resolve(relative), doc)
        if (ok) {
            pages.upsert(page.copy(inkFile = relative, updatedAt = System.currentTimeMillis()))
            touch(page.noteId)
        }
        ok
    }

    suspend fun saveViewport(pageId: String, zoom: Float, panX: Float, panY: Float) =
        pages.saveViewport(pageId, zoom, panX, panY)

    suspend fun savePageText(pageId: String, json: String) = pages.setTextJson(pageId, json)

    suspend fun page(pageId: String) = pages.findById(pageId)
    suspend fun pagesOf(noteId: String) = pages.pagesOf(noteId)
    suspend fun note(noteId: String) = notes.findById(noteId)

    // ----------------------------------------------------------- attachments
    suspend fun addAttachment(entity: AttachmentEntity) = pages.upsertAttachment(entity)
    suspend fun attachment(id: String) = pages.attachment(id)
    suspend fun deleteAttachment(id: String) = withContext(Dispatchers.IO) {
        pages.attachment(id)?.let { files.deleteQuietly(it.relativePath) }
        pages.deleteAttachment(id)
    }

    // ----------------------------------------------------------- templates
    suspend fun savePreset(preset: TemplatePresetEntity) = pages.upsertPreset(preset)
    suspend fun deletePreset(id: String) = pages.deletePreset(id)

    /** Seeds the built-in presets once, on first launch. */
    suspend fun seedBuiltInPresetsIfNeeded() = withContext(Dispatchers.IO) {
        if (pages.builtInPresetCount() > 0) return@withContext
        val seeds = listOf(
            Triple("Plain A4", PageTemplate.BLANK, PageSizePreset.A4),
            Triple("Lined A4", PageTemplate.LINED, PageSizePreset.A4),
            Triple("Dot grid A5", PageTemplate.DOTTED, PageSizePreset.A5),
            Triple("Cornell A4", PageTemplate.CORNELL, PageSizePreset.A4),
            Triple("Graph A4", PageTemplate.GRAPH, PageSizePreset.A4),
            Triple("Music A4", PageTemplate.MUSIC, PageSizePreset.A4),
            Triple("Planner A5", PageTemplate.PLANNER, PageSizePreset.A5),
            Triple("Timetable A3 landscape", PageTemplate.TIMETABLE, PageSizePreset.A3),
            Triple("Engineering A3", PageTemplate.ENGINEERING, PageSizePreset.A3),
            Triple("Sketch A2", PageTemplate.BLANK, PageSizePreset.A2),
            Triple("Pocket A6", PageTemplate.LINED, PageSizePreset.A6)
        )
        seeds.forEachIndexed { index, (name, template, size) ->
            pages.upsertPreset(
                TemplatePresetEntity(
                    id = "builtin-${template.id}-${size.id}",
                    name = name,
                    builtIn = true,
                    templateId = template.id,
                    pageSizeId = size.id,
                    orientation = if (template == PageTemplate.TIMETABLE) PageOrientation.LANDSCAPE.name else PageOrientation.PORTRAIT.name,
                    backgroundArgb = 0xFFFFFFFF.toInt(),
                    lineArgb = 0xFFBFD7D6.toInt(),
                    gridSpacingMm = 5f,
                    marginMm = 0f,
                    sortIndex = index
                )
            )
        }
    }

    suspend fun pruneOrphanFiles() = withContext(Dispatchers.IO) {
        val live = notes.allForBackup().map { it.id }.toSet()
        files.pruneOrphans(live)
        files.pruneExportCache()
    }

    companion object { private const val TAG = "NotesRepository" }
}

fun PageEntity.toSpec() = PageSpec(
    size = PageSizePreset.fromId(pageSizeId),
    orientation = PageOrientation.fromId(orientation),
    template = PageTemplate.fromId(templateId),
    backgroundArgb = backgroundArgb,
    lineArgb = lineArgb,
    gridSpacingMm = gridSpacingMm,
    marginMm = marginMm
)
