package app.noteflow.ink

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import app.noteflow.domain.model.InkBrush
import app.noteflow.domain.model.InkDocument
import app.noteflow.domain.model.PageSizePreset
import app.noteflow.domain.model.PageSpec
import app.noteflow.domain.model.STRIDE
import app.noteflow.domain.model.Stroke
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * NoteFlow handwriting surface.
 *
 * A plain [View] (not Compose) is used on purpose: direct access to [MotionEvent] gives the
 * batched historical samples, per-pointer tool type, pressure, tilt and button state that a
 * low-latency ink engine needs. Compose hosts it through `AndroidView` in the editor screen.
 *
 * Input policy
 *  - A pointer with TOOL_TYPE_STYLUS always draws and takes priority over fingers.
 *  - TOOL_TYPE_ERASER (the flipped end of a stylus) or the barrel button erases while held.
 *  - Palm rejection: while a stylus is in use, finger pointers are ignored for
 *    [PALM_WINDOW_MS]; oversized contacts (touchMajor above [palmMajorPx]) are ignored too.
 *    This uses only public APIs, so quality depends on the hardware. On devices with no
 *    stylus digitiser there is nothing to reject and the finger policy applies instead.
 *  - [fingerPolicy] lets the user choose what a finger does: draw, scroll, zoom-only, ignore.
 *
 * Coordinates: ink is stored in page points. Screen = page * [scale] + pan.
 */
class InkCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Mode { DRAW, ERASE_STROKE, ERASE_PIXEL, LASSO, PAN }
    enum class FingerPolicy { DRAW, SCROLL, ZOOM_ONLY, IGNORE }

    interface Listener {
        fun onInkChanged() {}
        fun onViewportChanged(zoom: Float, panX: Float, panY: Float) {}
        fun onSelectionChanged(count: Int) {}
        fun onHistoryChanged(canUndo: Boolean, canRedo: Boolean) {}
        fun onShapeRecognized(shape: ShapeRecognizer.Shape) {}
    }

    // ------------------------------------------------------------------ state
    var document: InkDocument = InkDocument()
        set(value) { field = value; history.clear(); clearSelection(); invalidate(); notifyHistory() }

    var pageSpec: PageSpec = PageSpec()
        set(value) { field = value; invalidate() }

    var brush: InkBrush = InkBrush()
    var mode: Mode = Mode.DRAW
        set(value) { field = value; if (value != Mode.LASSO) clearSelection(); invalidate() }

    var fingerPolicy: FingerPolicy = FingerPolicy.SCROLL
    var shapeSnapEnabled: Boolean = false
    var snapToGrid: Boolean = false
    var zoomLocked: Boolean = false
    /** Ruler: when non-null, strokes are constrained to this angle (degrees). */
    var rulerAngleDeg: Float? = null
    var eraserRadiusPt: Float = 8f
    var listener: Listener? = null

    val history = InkHistory()
    private val renderer = InkRenderer()
    private val templates = TemplateRenderer()

    // viewport
    private var scale = 1f
    private var panX = 0f
    private var panY = 0f
    private var fitted = false

    // wet stroke
    private var wetBuffer = FloatArray(1024 * STRIDE)
    private var wetCount = 0
    private var wetId = -1L
    private var activePointerId = -1
    private var drawingToolType = MotionEvent.TOOL_TYPE_FINGER
    private val liveFilter = StrokeSmoother.LiveFilter()
    private var strokeStart = PointF()

    // palm rejection
    private var lastStylusAt = 0L
    private var stylusEverSeen = false
    private val palmMajorPx by lazy { 26f * resources.displayMetrics.density }

    // lasso selection
    private val lassoPath = Path()
    private val lassoPoints = ArrayList<Float>()
    private var selection = mutableListOf<Stroke>()
    private var selectionBounds = RectF()
    private var movingSelection = false
    private var moveStart = PointF()
    private var moveAccum = PointF()
    private var selectionOriginals: List<Pair<Int, Stroke>> = emptyList()
    private var clipboard: List<Stroke> = emptyList()

    // paints for chrome (drawn in screen space)
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(40, 0, 0, 0); style = Paint.Style.FILL
    }
    private val sheetEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 0, 0, 0); style = Paint.Style.STROKE; strokeWidth = 1f
    }
    private val lassoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0E7C7B"); style = Paint.Style.STROKE; strokeWidth = 2f
        pathEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f)
    }
    private val selectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0E7C7B"); style = Paint.Style.STROKE; strokeWidth = 2f
        pathEffect = DashPathEffect(floatArrayOf(14f, 8f), 0f)
    }
    private val eraserPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 220, 60, 60); style = Paint.Style.STROKE; strokeWidth = 2f
    }
    private val infiniteGrid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 0.8f
    }
    private var eraserCursor: PointF? = null

    // ------------------------------------------------------------------ gestures
    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            if (zoomLocked) return true
            val factor = detector.scaleFactor
            val newScale = (scale * factor).coerceIn(minScale(), MAX_SCALE)
            val fx = detector.focusX
            val fy = detector.focusY
            panX = fx - (fx - panX) * (newScale / scale)
            panY = fy - (fy - panY) * (newScale / scale)
            scale = newScale
            invalidate()
            listener?.onViewportChanged(scale, panX, panY)
            return true
        }
    })

    private val tapDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (zoomLocked) return false
            if (scale > fitScale() * 1.2f) fitToWidth() else zoomAround(e.x, e.y, 2f)
            return true
        }
    })

    // ------------------------------------------------------------------ public API
    fun setViewport(zoom: Float, px: Float, py: Float) {
        scale = zoom.coerceIn(0.05f, MAX_SCALE); panX = px; panY = py; fitted = true; invalidate()
    }

    fun currentZoom() = scale
    fun currentPan() = panX to panY

    fun fitToWidth() {
        scale = fitScale()
        panX = (width - pageSpec.widthPt * scale) / 2f
        panY = PAGE_MARGIN_PX
        fitted = true
        invalidate()
        listener?.onViewportChanged(scale, panX, panY)
    }

    fun undo() { if (history.undo(document)) { clearSelection(); invalidate(); listener?.onInkChanged(); notifyHistory() } }
    fun redo() { if (history.redo(document)) { clearSelection(); invalidate(); listener?.onInkChanged(); notifyHistory() } }

    fun clearPage() {
        if (document.strokes.isEmpty()) return
        val removed = document.strokes.mapIndexed { i, s -> i to s }
        history.push(InkHistory.RemoveStrokes(removed))
        document.clear()
        invalidate(); listener?.onInkChanged(); notifyHistory()
    }

    fun hasSelection() = selection.isNotEmpty()

    fun deleteSelection() {
        if (selection.isEmpty()) return
        val removed = selection.map { s -> document.strokes.indexOf(s) to s }
        history.push(InkHistory.RemoveStrokes(removed))
        removed.forEach { document.remove(it.second.id) }
        clearSelection(); invalidate(); listener?.onInkChanged(); notifyHistory()
    }

    fun copySelection() { clipboard = selection.map { it.copy() } }

    fun duplicateSelection() {
        if (selection.isEmpty()) return
        val copies = selection.map { it.translated(16f, 16f).copy(id = document.newId()) }
        copies.forEach { it.recomputeBounds(); document.add(it) }
        history.push(InkHistory.AddStrokes(copies))
        setSelection(copies); invalidate(); listener?.onInkChanged(); notifyHistory()
    }

    fun paste() {
        if (clipboard.isEmpty()) return
        val copies = clipboard.map { it.translated(24f, 24f).copy(id = document.newId()) }
        copies.forEach { it.recomputeBounds(); document.add(it) }
        history.push(InkHistory.AddStrokes(copies))
        setSelection(copies); invalidate(); listener?.onInkChanged(); notifyHistory()
    }

    /** Uniform scale about the selection centre (lasso resize). */
    fun scaleSelection(factor: Float) = transformSelection { cx, cy ->
        floatArrayOf(factor, 0f, cx - factor * cx, 0f, factor, cy - factor * cy)
    }

    /** Rotate the selection about its centre (lasso rotate). */
    fun rotateSelection(degrees: Float) = transformSelection { cx, cy ->
        val r = Math.toRadians(degrees.toDouble())
        val c = cos(r).toFloat(); val s = sin(r).toFloat()
        floatArrayOf(c, -s, cx - c * cx + s * cy, s, c, cy - s * cx - c * cy)
    }

    private fun transformSelection(matrixFor: (Float, Float) -> FloatArray) {
        if (selection.isEmpty()) return
        val cx = selectionBounds.centerX(); val cy = selectionBounds.centerY()
        val m = matrixFor(cx, cy)
        val scaleForWidth = hypot(m[0], m[3])
        val before = selection.map { s -> document.strokes.indexOf(s) to s }
        val after = selection.map { it.transformed(m, scaleForWidth) }
        history.push(InkHistory.ReplaceStrokes(before, after))
        before.forEach { document.remove(it.second.id) }
        after.forEach { document.add(it) }
        setSelection(after); invalidate(); listener?.onInkChanged(); notifyHistory()
    }

    /** Replaces strokes atomically (used by beautify / smoothing). */
    fun replaceStrokes(before: List<Stroke>, after: List<Stroke>) {
        val indexed = before.map { s -> document.strokes.indexOf(s) to s }
        history.push(InkHistory.ReplaceStrokes(indexed, after))
        indexed.forEach { document.remove(it.second.id) }
        after.forEach { document.add(it) }
        clearSelection(); invalidate(); listener?.onInkChanged(); notifyHistory()
    }

    fun selectedStrokes(): List<Stroke> = selection.toList()

    fun selectAll() = setSelection(document.copyOfStrokes())

    // ------------------------------------------------------------------ drawing
    override fun onDraw(canvas: Canvas) {
        if (!fitted && width > 0) fitToWidth()
        super.onDraw(canvas)

        canvas.save()
        canvas.translate(panX, panY)
        canvas.scale(scale, scale)

        if (pageSpec.size == PageSizePreset.INFINITE) {
            drawInfiniteBackground(canvas)
        } else {
            canvas.drawRect(-2f, -2f, pageSpec.widthPt + 6f, pageSpec.heightPt + 6f, shadowPaint)
            templates.draw(canvas, pageSpec)
            canvas.drawRect(0f, 0f, pageSpec.widthPt, pageSpec.heightPt, sheetEdge)
        }

        // visible page-space rectangle for cheap culling
        val l = -panX / scale
        val t = -panY / scale
        val r = l + width / scale
        val b = t + height / scale
        renderer.drawAll(canvas, document.strokes, l, t, r, b)

        if (wetCount > 0) {
            val wet = Stroke(wetId, brush, wetBuffer, wetCount).also { it.recomputeBounds() }
            renderer.draw(canvas, wet)
        }

        if (selection.isNotEmpty()) {
            canvas.drawRect(selectionBounds, selectionPaint)
        }
        if (!lassoPath.isEmpty) canvas.drawPath(lassoPath, lassoPaint)

        eraserCursor?.let { canvas.drawCircle(it.x, it.y, eraserRadiusPt, eraserPaint) }

        rulerAngleDeg?.let { angle ->
            val cx = l + (r - l) / 2f
            val cy = t + (b - t) / 2f
            val len = max(r - l, b - t)
            val rad = Math.toRadians(angle.toDouble())
            canvas.drawLine(
                cx - len * cos(rad).toFloat(), cy - len * sin(rad).toFloat(),
                cx + len * cos(rad).toFloat(), cy + len * sin(rad).toFloat(), lassoPaint
            )
        }

        canvas.restore()
    }

    private fun drawInfiniteBackground(canvas: Canvas) {
        val l = -panX / scale; val t = -panY / scale
        val r = l + width / scale; val b = t + height / scale
        val bg = Paint().apply { color = pageSpec.backgroundArgb }
        canvas.drawRect(l, t, r, b, bg)
        val step = pageSpec.gridSpacingMm * pageSpec.ptPerMm
        if (step > 2f) {
            infiniteGrid.color = pageSpec.lineArgb
            var x = Math.floor((l / step).toDouble()).toFloat() * step
            while (x < r) { canvas.drawLine(x, t, x, b, infiniteGrid); x += step }
            var y = Math.floor((t / step).toDouble()).toFloat() * step
            while (y < b) { canvas.drawLine(l, y, r, y, infiniteGrid); y += step }
        }
    }

    // ------------------------------------------------------------------ input
    override fun onTouchEvent(event: MotionEvent): Boolean {
        tapDetector.onTouchEvent(event)

        val toolType = event.getToolType(event.actionIndex.coerceAtMost(event.pointerCount - 1))
        if (toolType == MotionEvent.TOOL_TYPE_STYLUS || toolType == MotionEvent.TOOL_TYPE_ERASER) {
            stylusEverSeen = true
            lastStylusAt = System.currentTimeMillis()
        }

        // Two or more pointers -> navigation gesture (pinch zoom + pan), unless the stylus
        // is mid stroke, in which case extra contacts are palm and must be ignored.
        if (event.pointerCount >= 2 && drawingToolType != MotionEvent.TOOL_TYPE_STYLUS) {
            if (fingerPolicy == FingerPolicy.IGNORE && toolType == MotionEvent.TOOL_TYPE_FINGER) return true
            cancelWetStroke()
            scaleDetector.onTouchEvent(event)
            handleTwoFingerPan(event)
            return true
        }

        if (shouldIgnore(event, toolType)) return true

        val erasing = toolType == MotionEvent.TOOL_TYPE_ERASER ||
            (event.buttonState and MotionEvent.BUTTON_STYLUS_PRIMARY) != 0
        val effectiveMode = when {
            erasing -> Mode.ERASE_STROKE
            toolType == MotionEvent.TOOL_TYPE_FINGER && fingerPolicy == FingerPolicy.SCROLL -> Mode.PAN
            toolType == MotionEvent.TOOL_TYPE_FINGER && fingerPolicy == FingerPolicy.ZOOM_ONLY -> Mode.PAN
            else -> mode
        }

        return when (effectiveMode) {
            Mode.DRAW -> handleDraw(event, toolType)
            Mode.ERASE_STROKE, Mode.ERASE_PIXEL -> handleErase(event, effectiveMode)
            Mode.LASSO -> handleLasso(event)
            Mode.PAN -> handlePan(event)
        }
    }

    private fun shouldIgnore(event: MotionEvent, toolType: Int): Boolean {
        if (toolType != MotionEvent.TOOL_TYPE_FINGER) return false
        if (fingerPolicy == FingerPolicy.IGNORE) return true
        // palm rejection window after stylus activity
        if (stylusEverSeen && System.currentTimeMillis() - lastStylusAt < PALM_WINDOW_MS) return true
        // very large contact area = palm / knuckle
        val index = event.actionIndex.coerceAtMost(event.pointerCount - 1)
        if (stylusEverSeen && event.getTouchMajor(index) > palmMajorPx) return true
        return false
    }

    private var lastPan = PointF()

    private fun handleTwoFingerPan(event: MotionEvent) {
        val cx = (event.getX(0) + event.getX(1)) / 2f
        val cy = (event.getY(0) + event.getY(1)) / 2f
        when (event.actionMasked) {
            MotionEvent.ACTION_POINTER_DOWN -> lastPan.set(cx, cy)
            MotionEvent.ACTION_MOVE -> {
                panX += cx - lastPan.x
                panY += cy - lastPan.y
                lastPan.set(cx, cy)
                invalidate()
                listener?.onViewportChanged(scale, panX, panY)
            }
        }
    }

    private fun handlePan(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> lastPan.set(event.x, event.y)
            MotionEvent.ACTION_MOVE -> {
                panX += event.x - lastPan.x
                panY += event.y - lastPan.y
                lastPan.set(event.x, event.y)
                invalidate()
                listener?.onViewportChanged(scale, panX, panY)
            }
        }
        return true
    }

    private fun handleDraw(event: MotionEvent, toolType: Int): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activePointerId = event.getPointerId(0)
                drawingToolType = toolType
                wetCount = 0
                wetId = document.newId()
                liveFilter.reset()
                val p = toPage(event.x, event.y)
                strokeStart.set(p.x, p.y)
                appendWet(p.x, p.y, pressureOf(event, 0), event.eventTime)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val index = event.findPointerIndex(activePointerId)
                if (index < 0) return true
                // batched samples: the real reason we use a View + MotionEvent
                for (h in 0 until event.historySize) {
                    val hp = toPage(event.getHistoricalX(index, h), event.getHistoricalY(index, h))
                    appendWet(hp.x, hp.y, event.getHistoricalPressure(index, h), event.getHistoricalEventTime(h))
                }
                val p = toPage(event.getX(index), event.getY(index))
                appendWet(p.x, p.y, pressureOf(event, index), event.eventTime)
                invalidate()
            }
            MotionEvent.ACTION_UP -> { commitWetStroke(); drawingToolType = MotionEvent.TOOL_TYPE_FINGER }
            MotionEvent.ACTION_CANCEL -> { cancelWetStroke(); drawingToolType = MotionEvent.TOOL_TYPE_FINGER }
        }
        return true
    }

    private fun pressureOf(event: MotionEvent, index: Int): Float {
        val raw = event.getPressure(index)
        // Many capacitive panels report a constant 1.0 for fingers; keep a sane mid value.
        return if (raw <= 0.01f || raw >= 2f) 0.6f else raw
    }

    private fun appendWet(xIn: Float, yIn: Float, pressure: Float, time: Long) {
        var x = xIn
        var y = yIn
        rulerAngleDeg?.let { angle ->
            val rad = Math.toRadians(angle.toDouble())
            val dx = x - strokeStart.x
            val dy = y - strokeStart.y
            val proj = dx * cos(rad).toFloat() + dy * sin(rad).toFloat()
            x = strokeStart.x + proj * cos(rad).toFloat()
            y = strokeStart.y + proj * sin(rad).toFloat()
        }
        if (snapToGrid && wetCount == 0) {
            val step = pageSpec.gridSpacingMm * pageSpec.ptPerMm
            x = Math.round(x / step) * step
            y = Math.round(y / step) * step
        }
        val filtered = liveFilter.filter(x, y)
        if (wetCount > 0) {
            val lx = wetBuffer[(wetCount - 1) * STRIDE]
            val ly = wetBuffer[(wetCount - 1) * STRIDE + 1]
            if (hypot(filtered[0] - lx, filtered[1] - ly) < 0.35f) return // drop duplicates
        }
        if ((wetCount + 1) * STRIDE >= wetBuffer.size) {
            wetBuffer = wetBuffer.copyOf(wetBuffer.size * 2)
        }
        val base = wetCount * STRIDE
        wetBuffer[base] = filtered[0]
        wetBuffer[base + 1] = filtered[1]
        wetBuffer[base + 2] = pressure
        wetBuffer[base + 3] = (time % 1_000_000L).toFloat()
        wetCount++
    }

    private fun commitWetStroke() {
        if (wetCount == 0) return
        StrokeSmoother.smoothPressure(wetBuffer, wetCount)
        val (points, count) = StrokeSmoother.resampleCatmullRom(wetBuffer, wetCount)
        var stroke = Stroke(wetId, brush, points, count).also { it.recomputeBounds() }

        if (shapeSnapEnabled) {
            ShapeRecognizer.recognize(stroke)?.let { result ->
                stroke = result.stroke
                listener?.onShapeRecognized(result.shape)
            }
        }

        document.add(stroke)
        history.push(InkHistory.AddStrokes(listOf(stroke)))
        wetCount = 0
        invalidate()
        listener?.onInkChanged()
        notifyHistory()
    }

    private fun cancelWetStroke() { if (wetCount > 0) { wetCount = 0; invalidate() } }

    // ---- erasers ----
    private val erasedThisGesture = mutableListOf<Pair<Int, Stroke>>()
    private val pixelReplacements = mutableListOf<Pair<Pair<Int, Stroke>, List<Stroke>>>()

    private fun handleErase(event: MotionEvent, eraseMode: Mode): Boolean {
        val p = toPage(event.x, event.y)
        eraserCursor = p
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { erasedThisGesture.clear(); pixelReplacements.clear(); eraseAt(p, eraseMode) }
            MotionEvent.ACTION_MOVE -> {
                for (h in 0 until event.historySize) {
                    eraseAt(toPage(event.getHistoricalX(h), event.getHistoricalY(h)), eraseMode)
                }
                eraseAt(p, eraseMode)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                eraserCursor = null
                if (erasedThisGesture.isNotEmpty()) {
                    history.push(InkHistory.RemoveStrokes(erasedThisGesture.toList()))
                    erasedThisGesture.clear()
                    listener?.onInkChanged(); notifyHistory()
                }
                if (pixelReplacements.isNotEmpty()) {
                    history.push(
                        InkHistory.ReplaceStrokes(
                            pixelReplacements.map { it.first },
                            pixelReplacements.flatMap { it.second }
                        )
                    )
                    pixelReplacements.clear()
                    listener?.onInkChanged(); notifyHistory()
                }
            }
        }
        invalidate()
        return true
    }

    private fun eraseAt(p: PointF, eraseMode: Mode) {
        val r = eraserRadiusPt
        val candidates = document.strokes.filter { it.intersectsRect(p.x - r, p.y - r, p.x + r, p.y + r) }
        for (stroke in candidates) {
            if (eraseMode == Mode.ERASE_STROKE) {
                if (hits(stroke, p, r)) {
                    val index = document.strokes.indexOf(stroke)
                    erasedThisGesture += index to stroke
                    document.remove(stroke.id)
                }
            } else {
                val pieces = splitAround(stroke, p, r) ?: continue
                val index = document.strokes.indexOf(stroke)
                document.remove(stroke.id)
                pieces.forEach { document.add(it) }
                pixelReplacements += (index to stroke) to pieces
            }
        }
    }

    private fun hits(stroke: Stroke, p: PointF, r: Float): Boolean {
        for (i in 0 until stroke.pointCount) {
            if (hypot(stroke.x(i) - p.x, stroke.y(i) - p.y) <= r) return true
        }
        return false
    }

    /** Pixel ("partial") eraser: cuts a stroke into the pieces outside the eraser disc. */
    private fun splitAround(stroke: Stroke, p: PointF, r: Float): List<Stroke>? {
        var touched = false
        val pieces = mutableListOf<Stroke>()
        var current = ArrayList<Float>()
        for (i in 0 until stroke.pointCount) {
            val inside = hypot(stroke.x(i) - p.x, stroke.y(i) - p.y) <= r
            if (inside) {
                touched = true
                if (current.size >= 2 * STRIDE) pieces += pieceFrom(current, stroke)
                current = ArrayList()
            } else {
                current.add(stroke.x(i)); current.add(stroke.y(i))
                current.add(stroke.pressure(i)); current.add(stroke.timeMs(i))
            }
        }
        if (!touched) return null
        if (current.size >= 2 * STRIDE) pieces += pieceFrom(current, stroke)
        return pieces
    }

    private fun pieceFrom(values: List<Float>, source: Stroke): Stroke {
        val array = FloatArray(values.size) { values[it] }
        return Stroke(document.newId(), source.brush, array, array.size / STRIDE).also { it.recomputeBounds() }
    }

    // ---- lasso ----
    private fun handleLasso(event: MotionEvent): Boolean {
        val p = toPage(event.x, event.y)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (selection.isNotEmpty() && selectionBounds.contains(p.x, p.y)) {
                    movingSelection = true
                    moveStart.set(p.x, p.y)
                    moveAccum.set(0f, 0f)
                    selectionOriginals = selection.map { s -> document.strokes.indexOf(s) to s }
                } else {
                    clearSelection()
                    lassoPoints.clear()
                    lassoPath.rewind()
                    lassoPath.moveTo(p.x, p.y)
                    lassoPoints.add(p.x); lassoPoints.add(p.y)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (movingSelection) {
                    val dx = p.x - moveStart.x
                    val dy = p.y - moveStart.y
                    moveStart.set(p.x, p.y)
                    moveAccum.offset(dx, dy)
                    val moved = selection.map { it.translated(dx, dy) }
                    selection.forEach { document.remove(it.id) }
                    moved.forEach { document.add(it) }
                    selection = moved.toMutableList()
                    recomputeSelectionBounds()
                } else {
                    lassoPath.lineTo(p.x, p.y)
                    lassoPoints.add(p.x); lassoPoints.add(p.y)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (movingSelection) {
                    movingSelection = false
                    if (abs(moveAccum.x) > 0.1f || abs(moveAccum.y) > 0.1f) {
                        history.push(InkHistory.ReplaceStrokes(selectionOriginals, selection.toList()))
                        listener?.onInkChanged(); notifyHistory()
                    }
                } else {
                    lassoPath.close()
                    setSelection(strokesInsideLasso())
                    lassoPath.rewind()
                    lassoPoints.clear()
                }
            }
        }
        invalidate()
        return true
    }

    private fun strokesInsideLasso(): List<Stroke> {
        if (lassoPoints.size < 6) return emptyList()
        return document.strokes.filter { stroke ->
            var inside = 0
            val step = max(1, stroke.pointCount / 12)
            var checked = 0
            var i = 0
            while (i < stroke.pointCount) {
                if (pointInPolygon(stroke.x(i), stroke.y(i))) inside++
                checked++
                i += step
            }
            checked > 0 && inside.toFloat() / checked > 0.6f
        }
    }

    private fun pointInPolygon(x: Float, y: Float): Boolean {
        var inside = false
        val n = lassoPoints.size / 2
        var j = n - 1
        for (i in 0 until n) {
            val xi = lassoPoints[i * 2]; val yi = lassoPoints[i * 2 + 1]
            val xj = lassoPoints[j * 2]; val yj = lassoPoints[j * 2 + 1]
            if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi + 0.0001f) + xi) inside = !inside
            j = i
        }
        return inside
    }

    private fun setSelection(strokes: List<Stroke>) {
        selection = strokes.toMutableList()
        recomputeSelectionBounds()
        listener?.onSelectionChanged(selection.size)
    }

    private fun clearSelection() {
        if (selection.isNotEmpty()) { selection.clear(); listener?.onSelectionChanged(0) }
        selectionBounds.setEmpty()
    }

    private fun recomputeSelectionBounds() {
        if (selection.isEmpty()) { selectionBounds.setEmpty(); return }
        var l = Float.MAX_VALUE; var t = Float.MAX_VALUE
        var r = -Float.MAX_VALUE; var b = -Float.MAX_VALUE
        selection.forEach {
            l = min(l, it.minX); t = min(t, it.minY); r = max(r, it.maxX); b = max(b, it.maxY)
        }
        selectionBounds.set(l - 4f, t - 4f, r + 4f, b + 4f)
    }

    // ------------------------------------------------------------------ helpers
    private fun toPage(x: Float, y: Float) = PointF((x - panX) / scale, (y - panY) / scale)

    private fun fitScale(): Float {
        if (width == 0) return 1f
        val usable = width - PAGE_MARGIN_PX * 2
        return (usable / pageSpec.widthPt).coerceAtLeast(0.05f)
    }

    private fun minScale() = fitScale() * 0.5f

    private fun zoomAround(fx: Float, fy: Float, factor: Float) {
        val newScale = (scale * factor).coerceIn(minScale(), MAX_SCALE)
        panX = fx - (fx - panX) * (newScale / scale)
        panY = fy - (fy - panY) * (newScale / scale)
        scale = newScale
        invalidate()
        listener?.onViewportChanged(scale, panX, panY)
    }

    private fun notifyHistory() = listener?.onHistoryChanged(history.canUndo, history.canRedo)

    companion object {
        private const val MAX_SCALE = 12f
        private const val PAGE_MARGIN_PX = 24f
        /** Fingers are ignored for this long after any stylus sample. */
        private const val PALM_WINDOW_MS = 900L
    }
}
