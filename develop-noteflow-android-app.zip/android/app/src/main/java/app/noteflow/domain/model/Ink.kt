package app.noteflow.domain.model

/**
 * Vector ink model.
 *
 * A stroke is stored as real sampled input — never as a flattened bitmap — so it can be
 * re-rendered at any zoom level, re-coloured, erased stroke-wise, selected, exported to a
 * vector PDF and (later) beautified.
 *
 * Coordinates are in PAGE SPACE (points, origin top-left of the sheet), not screen pixels,
 * so zoom/pan and different device densities never change the stored data.
 */
enum class InkTool(val id: String, val label: String) {
    PEN("PEN", "Pen"),
    BALLPOINT("BALLPOINT", "Ballpoint"),
    FOUNTAIN("FOUNTAIN", "Fountain pen"),
    PENCIL("PENCIL", "Pencil"),
    BRUSH("BRUSH", "Brush"),
    CALLIGRAPHY("CALLIGRAPHY", "Calligraphy"),
    HIGHLIGHTER("HIGHLIGHTER", "Highlighter");

    companion object { fun fromId(id: String?) = entries.firstOrNull { it.id == id } ?: PEN }
}

/** Tool configuration chosen in the pen toolbar. */
data class InkBrush(
    val tool: InkTool = InkTool.PEN,
    val colorArgb: Int = 0xFF101418.toInt(),
    /** Nominal width in points at pressure 1.0. */
    val widthPt: Float = 2.2f,
    val opacity: Float = 1f,
    /** 0 = ignore pressure (constant width), 1 = full pressure response. */
    val pressureResponse: Float = 0.75f,
    /** Calligraphy / fountain nib angle in degrees. */
    val nibAngleDeg: Float = 45f
) {
    val isHighlighter: Boolean get() = tool == InkTool.HIGHLIGHTER
}

/**
 * Packed point buffer: [x, y, pressure, tMs] repeated. A FloatArray keeps allocation and
 * GC pressure low while drawing, which matters for latency.
 */
const val STRIDE = 4

data class Stroke(
    val id: Long,
    val brush: InkBrush,
    val points: FloatArray,
    val pointCount: Int,
    var minX: Float = 0f,
    var minY: Float = 0f,
    var maxX: Float = 0f,
    var maxY: Float = 0f
) {
    fun x(i: Int) = points[i * STRIDE]
    fun y(i: Int) = points[i * STRIDE + 1]
    fun pressure(i: Int) = points[i * STRIDE + 2]
    fun timeMs(i: Int) = points[i * STRIDE + 3]

    fun recomputeBounds() {
        if (pointCount == 0) return
        var nx = Float.MAX_VALUE; var ny = Float.MAX_VALUE
        var xx = -Float.MAX_VALUE; var xy = -Float.MAX_VALUE
        for (i in 0 until pointCount) {
            val px = x(i); val py = y(i)
            if (px < nx) nx = px
            if (py < ny) ny = py
            if (px > xx) xx = px
            if (py > xy) xy = py
        }
        val pad = brush.widthPt
        minX = nx - pad; minY = ny - pad; maxX = xx + pad; maxY = xy + pad
    }

    fun translated(dx: Float, dy: Float): Stroke {
        val moved = points.copyOf()
        for (i in 0 until pointCount) {
            moved[i * STRIDE] += dx
            moved[i * STRIDE + 1] += dy
        }
        return copy(points = moved).also { it.recomputeBounds() }
    }

    /** Affine transform used by lasso move / resize / rotate. */
    fun transformed(m: FloatArray, scaleForWidth: Float = 1f): Stroke {
        val mapped = points.copyOf()
        for (i in 0 until pointCount) {
            val px = mapped[i * STRIDE]; val py = mapped[i * STRIDE + 1]
            mapped[i * STRIDE] = m[0] * px + m[1] * py + m[2]
            mapped[i * STRIDE + 1] = m[3] * px + m[4] * py + m[5]
        }
        val b = brush.copy(widthPt = brush.widthPt * scaleForWidth)
        return copy(points = mapped, brush = b).also { it.recomputeBounds() }
    }

    fun intersectsRect(l: Float, t: Float, r: Float, b: Float): Boolean =
        !(maxX < l || minX > r || maxY < t || minY > b)

    override fun equals(other: Any?) = other is Stroke && other.id == id
    override fun hashCode() = id.hashCode()
}

/** One page worth of ink. Mutated by the engine, serialised by InkCodec. */
class InkDocument(val strokes: MutableList<Stroke> = mutableListOf()) {
    var nextId: Long = 1L
        private set

    fun add(stroke: Stroke) {
        strokes += stroke
        if (stroke.id >= nextId) nextId = stroke.id + 1
    }

    fun newId(): Long = nextId++

    fun remove(id: Long): Stroke? {
        val index = strokes.indexOfFirst { it.id == id }
        return if (index >= 0) strokes.removeAt(index) else null
    }

    fun clear() = strokes.clear()

    fun copyOfStrokes(): List<Stroke> = strokes.toList()
}
