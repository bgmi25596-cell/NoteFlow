package app.noteflow.data.local.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import app.noteflow.data.local.entity.AttachmentEntity
import app.noteflow.data.local.entity.PageEntity
import app.noteflow.data.local.entity.TemplatePresetEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PageDao {

    @Upsert
    suspend fun upsert(page: PageEntity)

    @Upsert
    suspend fun upsertAll(pages: List<PageEntity>)

    @Query("SELECT * FROM pages WHERE noteId = :noteId ORDER BY pageIndex ASC")
    fun observePages(noteId: String): Flow<List<PageEntity>>

    @Query("SELECT * FROM pages WHERE noteId = :noteId ORDER BY pageIndex ASC")
    suspend fun pagesOf(noteId: String): List<PageEntity>

    @Query("SELECT * FROM pages WHERE id = :id")
    suspend fun findById(id: String): PageEntity?

    @Query("SELECT COUNT(*) FROM pages WHERE noteId = :noteId")
    suspend fun countOf(noteId: String): Int

    @Query("DELETE FROM pages WHERE id = :id")
    suspend fun delete(id: String)

    @Query("UPDATE pages SET pageIndex = :index WHERE id = :id")
    suspend fun setIndex(id: String, index: Int)

    @Query("UPDATE pages SET viewZoom = :zoom, viewPanX = :panX, viewPanY = :panY WHERE id = :id")
    suspend fun saveViewport(id: String, zoom: Float, panX: Float, panY: Float)

    @Query("UPDATE pages SET inkFile = :file, updatedAt = :now WHERE id = :id")
    suspend fun setInkFile(id: String, file: String?, now: Long = System.currentTimeMillis())

    @Query("UPDATE pages SET textJson = :json, updatedAt = :now WHERE id = :id")
    suspend fun setTextJson(id: String, json: String?, now: Long = System.currentTimeMillis())

    /** Re-numbers pages after a reorder/delete so indices stay 0..n-1 with no gaps. */
    @Transaction
    suspend fun renumber(noteId: String) {
        pagesOf(noteId).forEachIndexed { index, page ->
            if (page.pageIndex != index) setIndex(page.id, index)
        }
    }

    @Query("SELECT * FROM pages")
    suspend fun allForBackup(): List<PageEntity>

    // --- attachments ---

    @Upsert
    suspend fun upsertAttachment(attachment: AttachmentEntity)

    @Query("SELECT * FROM attachments WHERE noteId = :noteId ORDER BY createdAt ASC")
    fun observeAttachments(noteId: String): Flow<List<AttachmentEntity>>

    @Query("SELECT * FROM attachments WHERE id = :id")
    suspend fun attachment(id: String): AttachmentEntity?

    @Query("DELETE FROM attachments WHERE id = :id")
    suspend fun deleteAttachment(id: String)

    @Query("SELECT * FROM attachments")
    suspend fun allAttachmentsForBackup(): List<AttachmentEntity>

    // --- template presets ---

    @Upsert
    suspend fun upsertPreset(preset: TemplatePresetEntity)

    @Query("SELECT * FROM template_presets ORDER BY builtIn DESC, sortIndex ASC, LOWER(name) ASC")
    fun observePresets(): Flow<List<TemplatePresetEntity>>

    @Query("SELECT COUNT(*) FROM template_presets WHERE builtIn = 1")
    suspend fun builtInPresetCount(): Int

    @Query("DELETE FROM template_presets WHERE id = :id AND builtIn = 0")
    suspend fun deletePreset(id: String)

    @Query("SELECT * FROM template_presets")
    suspend fun allPresetsForBackup(): List<TemplatePresetEntity>
}
