package app.noteflow.ui

import androidx.compose.material3.windowsizeclass.WindowSizeClass
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.NavType
import app.noteflow.ui.editor.EditorScreen
import app.noteflow.ui.home.HomeScreen
import app.noteflow.ui.home.HomeViewModel
import app.noteflow.ui.onboarding.WelcomeScreen
import app.noteflow.ui.settings.SettingsScreen
import app.noteflow.ui.theme.NoteFlowTheme

object Routes {
    const val WELCOME = "welcome"
    const val HOME = "home"
    const val EDITOR = "editor/{noteId}"
    const val SETTINGS = "settings"
    fun editor(noteId: String) = "editor/$noteId"
}

@Composable
fun NoteFlowApp(windowSizeClass: WindowSizeClass) {
    val homeViewModel: HomeViewModel = viewModel()
    val settings by homeViewModel.settings.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val expanded = windowSizeClass.widthSizeClass != WindowWidthSizeClass.Compact

    NoteFlowTheme(themeMode = settings.themeMode, accentIndex = settings.accentIndex) {
        NavHost(
            navController = navController,
            startDestination = if (settings.firstRunDone) Routes.HOME else Routes.WELCOME
        ) {
            composable(Routes.WELCOME) {
                WelcomeScreen(
                    onFinished = {
                        navController.navigate(Routes.HOME) {
                            popUpTo(Routes.WELCOME) { inclusive = true }
                        }
                    }
                )
            }
            composable(Routes.HOME) {
                HomeScreen(
                    viewModel = homeViewModel,
                    expanded = expanded,
                    largeTargets = settings.largeTouchTargets,
                    onOpenNote = { navController.navigate(Routes.editor(it)) },
                    onOpenSettings = { navController.navigate(Routes.SETTINGS) }
                )
            }
            composable(
                route = Routes.EDITOR,
                arguments = listOf(navArgument("noteId") { type = NavType.StringType })
            ) { entry ->
                EditorScreen(
                    noteId = entry.arguments?.getString("noteId").orEmpty(),
                    expanded = expanded,
                    largeTargets = settings.largeTouchTargets,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}
