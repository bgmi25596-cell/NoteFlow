package app.noteflow.ui.editor

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.noteflow.container
import app.noteflow.data.local.entity.NoteEntity
import app.noteflow.data.local.entity.PageEntity
import app.noteflow.data.local.entity.TemplatePresetEntity
import app.noteflow.data.repository.toSpec
import app.noteflow.domain.beautify.HandwritingRefiner
import app.noteflow.domain.model.InkBrush
import app.noteflow.domain.model.InkDocument
import app.noteflow.domain.model.PageSpec
import app.noteflow.domain.model.Stroke
import app.noteflow.ink.InkCanvasView
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

/** What the compact "saving" chip in the top bar shows. */
sealed interface SaveStatus {
    data object Idle : SaveStatus
    data object Saving : SaveStatus
    data class Saved(val at: Long) : SaveStatus
    data class Error(val message: String) : SaveStatus
}

data class EditorUiState(
    val note: NoteEntity? = null,
    val pages: List<PageEntity> = emptyList(),
    val pageIndex: Int = 0,
    val spec: PageSpec = PageSpec(),
    val brush: InkBrush = InkBrush(),
    val mode: InkCanvasView.Mode = InkCanvasView.Mode.DRAW,
    val fingerPolicy: InkCanvasView.FingerPolicy = InkCanvasView.FingerPolicy.SCROLL,
    val shapeSnap: Boolean = false,
    val zoomLocked: Boolean = false,
    val rulerAngle: Float? = null,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val selectionCount: Int = 0,
    val saveStatus: SaveStatus = SaveStatus.Idle,
    val message: String? = null,
    val loading: Boolean = true
) {
    val currentPage: PageEntity? get() = pages.getOrNull(pageIndex)
}

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = app.container.repository
    private val settingsStore = app.container.settings
    private val pdfExporter = app.container.pdfExporter

    private val _state = MutableStateFlow(EditorUiState())
    val state: StateFlow<EditorUiState> = _state

    val presets: StateFlow<List<TemplatePresetEntity>> =
        repo.observePresets().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** The live document owned by the canvas; the view mutates it, we persist it. */
    var document: InkDocument = InkDocument()
        private set

    private var noteId: String? = null
    private var autosaveJob: Job? = null
    private var autosaveSeconds = 2

    /** Snapshot kept while a "Tidy handwriting" preview is on screen. */
    private var beautifyBackup: List<Stroke>? = null
    private var beautifyTargets: List<Stroke> = emptyList()

    init {
        viewModelScope.launch {
            settingsStore.settings.collect { s ->
                autosaveSeconds = s.autosaveSeconds.coerceIn(1, 15)
                _state.value = _state.value.copy(
                    fingerPolicy = s.fingerPolicy,
                    shapeSnap = s.shapeSnap,
                    zoomLocked = s.zoomLock,
                    brush = _state.value.brush.copy(pressureResponse = s.pressureResponse)
                )
            }
        }
    }

    fun load(id: String) {
        if (noteId == id) return
        noteId = id
        viewModelScope.launch {
            repo.touchOpened(id)
            val note = repo.note(id)
            val pages = repo.pagesOf(id)
            _state.value = _state.value.copy(
                note = note,
                pages = pages,
                pageIndex = 0,
                spec = pages.firstOrNull()?.toSpec() ?: PageSpec(),
                loading = false
            )
            pages.firstOrNull()?.let { openPage(it) }
        }
    }

    private suspend fun openPage(page: PageEntity) {
        document = repo.loadInk(page)
        _state.value = _state.value.copy(spec = page.toSpec())
    }

    fun goToPage(index: Int) {
        val pages = _state.value.pages
        if (index !in pages.indices || index == _state.value.pageIndex) return
        viewModelScope.launch {
            saveNow()
            _state.value = _state.value.copy(pageIndex = index)
            openPage(pages[index])
        }
    }

    // ----------------------------------------------------------- autosave
    /** Called by the canvas after every committed edit. Debounced, never on the UI thread. */
    fun onInkChanged() {
        _state.value = _state.value.copy(saveStatus = SaveStatus.Saving)
        autosaveJob?.cancel()
        autosaveJob = viewModelScope.launch {
            delay(autosaveSeconds * 1000L)
            saveNow()
        }
    }

    /** Flushes immediately (used on pause/stop and before navigating away). */
    fun saveNow() {
        val page = _state.value.currentPage ?: return
        autosaveJob?.cancel()
        viewModelScope.launch {
            _state.value = _state.value.copy(saveStatus = SaveStatus.Saving)
            val ok = repo.saveInk(page, document)
            _state.value = if (ok) {
                val strokes = document.strokes.size
                repo.updateSnippet(page.noteId, "$strokes handwritten stroke${if (strokes == 1) "" else "s"}")
                _state.value.copy(saveStatus = SaveStatus.Saved(System.currentTimeMillis()))
            } else {
                _state.value.copy(
                    saveStatus = SaveStatus.Error("Could not save — check free storage space."),
                    message = "Saving failed. Your work is still on screen; free up space and tap Retry."
                )
            }
        }
    }

    fun retrySave() = saveNow()

    fun saveViewport(zoom: Float, panX: Float, panY: Float) {
        val page = _state.value.currentPage ?: return
        viewModelScope.launch { repo.saveViewport(page.id, zoom, panX, panY) }
    }

    // ----------------------------------------------------------- toolbar state
    fun setBrush(brush: InkBrush) { _state.value = _state.value.copy(brush = brush) }
    fun setMode(mode: InkCanvasView.Mode) { _state.value = _state.value.copy(mode = mode) }
    fun setRuler(angle: Float?) { _state.value = _state.value.copy(rulerAngle = angle) }
    fun setHistory(canUndo: Boolean, canRedo: Boolean) {
        _state.value = _state.value.copy(canUndo = canUndo, canRedo = canRedo)
    }
    fun setSelectionCount(count: Int) { _state.value = _state.value.copy(selectionCount = count) }
    fun setShapeSnap(enabled: Boolean) = viewModelScope.launch { settingsStore.setShapeSnap(enabled) }
    fun setZoomLock(enabled: Boolean) = viewModelScope.launch { settingsStore.setZoomLock(enabled) }
    fun setFingerPolicy(policy: InkCanvasView.FingerPolicy) =
        viewModelScope.launch { settingsStore.setFingerPolicy(policy) }
    fun consumeMessage() { _state.value = _state.value.copy(message = null) }
    fun showMessage(text: String) { _state.value = _state.value.copy(message = text) }

    // ----------------------------------------------------------- pages
    fun addPage(spec: PageSpec = _state.value.spec) {
        val id = noteId ?: return
        viewModelScope.launch {
            saveNow()
            repo.addPage(id, spec, atIndex = _state.value.pageIndex + 1)
            refreshPages(select = _state.value.pageIndex + 1)
        }
    }

    fun duplicateCurrentPage() {
        val page = _state.value.currentPage ?: return
        viewModelScope.launch {
            saveNow()
            repo.duplicatePage(page.id)
            refreshPages(select = _state.value.pageIndex + 1)
        }
    }

    fun deleteCurrentPage() {
        val page = _state.value.currentPage ?: return
        if (_state.value.pages.size <= 1) { showMessage("A note always keeps at least one page."); return }
        viewModelScope.launch {
            repo.deletePage(page.id)
            refreshPages(select = (_state.value.pageIndex - 1).coerceAtLeast(0))
        }
    }

    fun movePage(from: Int, to: Int) {
        val page = _state.value.pages.getOrNull(from) ?: return
        viewModelScope.launch {
            repo.movePage(page.id, to)
            refreshPages(select = to)
        }
    }

    fun applySpec(spec: PageSpec) {
        val page = _state.value.currentPage ?: return
        viewModelScope.launch {
            repo.updatePageSpec(page.id, spec)
            refreshPages(select = _state.value.pageIndex)
            _state.value = _state.value.copy(spec = spec)
        }
    }

    fun saveCurrentAsPreset(name: String) {
        val spec = _state.value.spec
        viewModelScope.launch {
            repo.savePreset(
                TemplatePresetEntity(
                    id = UUID.randomUUID().toString(),
                    name = name.ifBlank { "My template" },
                    builtIn = false,
                    templateId = spec.template.id,
                    pageSizeId = spec.size.id,
                    orientation = spec.orientation.name,
                    backgroundArgb = spec.backgroundArgb,
                    lineArgb = spec.lineArgb,
                    gridSpacingMm = spec.gridSpacingMm,
                    marginMm = spec.marginMm
                )
            )
            showMessage("Template preset saved.")
        }
    }

    fun deletePreset(id: String) = viewModelScope.launch { repo.deletePreset(id) }

    private suspend fun refreshPages(select: Int) {
        val id = noteId ?: return
        val pages = repo.pagesOf(id)
        val index = select.coerceIn(0, (pages.size - 1).coerceAtLeast(0))
        _state.value = _state.value.copy(pages = pages, pageIndex = index)
        pages.getOrNull(index)?.let { openPage(it) }
    }

    fun rename(title: String) {
        val id = noteId ?: return
        viewModelScope.launch {
            repo.rename(id, title)
            _state.value = _state.value.copy(note = _state.value.note?.copy(title = title))
        }
    }

    // ----------------------------------------------------------- tidy handwriting
    /**
     * Geometric refinement preview. Returns the proposed strokes; the caller swaps them into
     * the canvas. The originals are kept here until the user accepts or rejects.
     */
    fun beautifyPreview(targets: List<Stroke>, options: HandwritingRefiner.Options): List<Stroke> {
        beautifyBackup = targets.map { it.copy() }
        beautifyTargets = targets
        return HandwritingRefiner.refine(targets, options)
    }

    fun acceptBeautify() {
        beautifyBackup = null
        beautifyTargets = emptyList()
        onInkChanged()
    }

    /** Puts the untouched originals back; also reachable afterwards with normal Undo. */
    fun rejectBeautify(): List<Stroke>? {
        val restore = beautifyBackup
        beautifyBackup = null
        beautifyTargets = emptyList()
        return restore
    }

    // ----------------------------------------------------------- export
    fun exportPdf(target: Uri, onDone: (String) -> Unit) {
        val id = noteId ?: return
        viewModelScope.launch {
            saveNow()
            val result = pdfExporter.export(id, target)
            onDone(
                result.fold(
                    onSuccess = { "Exported $it page(s) to PDF." },
                    onFailure = { "PDF export failed: ${it.message}" }
                )
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        // Best effort flush; the editor screen also calls saveNow() on ON_PAUSE.
        saveNow()
    }
}
