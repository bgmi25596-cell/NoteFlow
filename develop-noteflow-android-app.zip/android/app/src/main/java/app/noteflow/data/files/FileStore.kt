package app.noteflow.data.files

import android.content.Context
import android.os.StatFs
import android.util.Log
import java.io.File
import java.io.IOException
import java.util.UUID

/**
 * Local file store for everything too large for SQLite: vector ink documents, images,
 * audio recordings and imported PDFs.
 *
 * Layout (all inside the app sandbox, no permissions required):
 *
 *   filesDir/
 *     notes/<noteId>/ink/<pageId>.nfink      vector strokes (binary, versioned)
 *     notes/<noteId>/media/<uuid>.<ext>      images / audio / pdf
 *     backups/<timestamp>.noteflow.json      local JSON backups
 *   cacheDir/
 *     exports/                               temporary PDFs shared via FileProvider
 *
 * Safety:
 *  - Writes go to "<name>.tmp" and are atomically renamed, so a crash or battery death
 *    can never leave a half-written stroke file.
 *  - [hasRoomFor] is checked before big writes to report "low storage" instead of crashing.
 */
class FileStore(private val context: Context) {

    private val root: File get() = context.filesDir

    val notesDir: File get() = File(root, "notes").ensure()
    val backupsDir: File get() = File(root, "backups").ensure()
    val exportsDir: File get() = File(context.cacheDir, "exports").ensure()

    fun inkDir(noteId: String): File = File(notesDir, "$noteId/ink").ensure()
    fun mediaDir(noteId: String): File = File(notesDir, "$noteId/media").ensure()

    fun inkFileName(noteId: String, pageId: String) = "notes/$noteId/ink/$pageId.nfink"

    fun resolve(relativePath: String): File = File(root, relativePath)

    fun newMediaFile(noteId: String, extension: String): Pair<String, File> {
        val name = "${UUID.randomUUID()}.${extension.trimStart('.')}"
        val file = File(mediaDir(noteId), name)
        return "notes/$noteId/media/$name" to file
    }

    /** Atomic write: temp file + rename. Returns false and logs if the write failed. */
    fun writeAtomically(target: File, block: (java.io.OutputStream) -> Unit): Boolean {
        val tmp = File(target.parentFile, target.name + ".tmp")
        return try {
            target.parentFile?.ensure()
            tmp.outputStream().buffered().use(block)
            if (target.exists() && !target.delete()) throw IOException("cannot replace ${target.name}")
            if (!tmp.renameTo(target)) throw IOException("cannot rename ${tmp.name}")
            true
        } catch (t: Throwable) {
            Log.e(TAG, "Atomic write failed for ${target.name}", t)
            tmp.delete()
            false
        }
    }

    fun deleteNoteFiles(noteId: String) {
        File(notesDir, noteId).deleteRecursively()
    }

    fun deleteQuietly(relativePath: String?) {
        if (relativePath.isNullOrBlank()) return
        runCatching { resolve(relativePath).delete() }
    }

    fun sizeOf(relativePath: String): Long = runCatching { resolve(relativePath).length() }.getOrDefault(0L)

    /** Free bytes on the internal volume; used to warn before imports/exports. */
    fun freeBytes(): Long = runCatching {
        val stat = StatFs(root.absolutePath)
        stat.availableBlocksLong * stat.blockSizeLong
    }.getOrDefault(Long.MAX_VALUE)

    fun hasRoomFor(bytes: Long): Boolean = freeBytes() > bytes + SAFETY_MARGIN

    /** Deletes export scratch files older than a day. Called on app start. */
    fun pruneExportCache(maxAgeMs: Long = 24 * 60 * 60 * 1000L) {
        val cutoff = System.currentTimeMillis() - maxAgeMs
        exportsDir.listFiles()?.forEach { if (it.lastModified() < cutoff) it.delete() }
    }

    /** Removes ink/media folders whose note row no longer exists (e.g. after Empty Bin). */
    fun pruneOrphans(liveNoteIds: Set<String>) {
        notesDir.listFiles()?.forEach { dir ->
            if (dir.isDirectory && dir.name !in liveNoteIds) dir.deleteRecursively()
        }
    }

    private fun File.ensure(): File = apply { if (!exists()) mkdirs() }

    companion object {
        private const val TAG = "FileStore"
        private const val SAFETY_MARGIN = 20L * 1024 * 1024 // keep 20 MB headroom
    }
}
