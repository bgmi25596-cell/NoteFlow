package app.noteflow.ui.editor

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.outlined.AutoFixHigh
import androidx.compose.material.icons.outlined.Brush
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.CleaningServices
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Gesture
import androidx.compose.material.icons.outlined.Highlight
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.PanTool
import androidx.compose.material.icons.outlined.Straighten
import androidx.compose.material3.AssistChip
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import app.noteflow.domain.model.InkTool
import app.noteflow.ink.InkCanvasView
import app.noteflow.ui.home.TextPromptDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val PenColors = listOf(
    Color(0xFF101418), Color(0xFF0E7C7B), Color(0xFF2B5BD7), Color(0xFFB3261E),
    Color(0xFF1B7F3B), Color(0xFFB4690E), Color(0xFF7B3FA0), Color(0xFFEC6B9D),
    Color(0xFFFFFFFF)
)

/**
 * The writing screen: compact top bar, full-bleed ink canvas and a customisable pen
 * toolbar. The canvas itself is the native [InkCanvasView]; Compose only draws chrome,
 * which keeps stroke latency away from recomposition.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    noteId: String,
    expanded: Boolean,
    largeTargets: Boolean,
    onBack: () -> Unit
) {
    val vm: EditorViewModel = viewModel()
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var canvasRef by remember { mutableStateOf<InkCanvasView?>(null) }
    var showPageSheet by remember { mutableStateOf(false) }
    var showTidySheet by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    LaunchedEffect(noteId) { vm.load(noteId) }

    // Flush autosave when the app goes to the background or the screen is left.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) vm.saveNow()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer); vm.saveNow() }
    }

    LaunchedEffect(state.message) {
        state.message?.let { snackbar.showSnackbar(it); vm.consumeMessage() }
    }

    val pdfLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) vm.exportPdf(uri) { msg -> Toast.makeText(context, msg, Toast.LENGTH_LONG).show() }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            state.note?.title?.ifBlank { "Untitled note" } ?: "Note",
                            style = MaterialTheme.typography.titleMedium
                        )
                        SaveStatusLabel(state.saveStatus, onRetry = vm::retrySave)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { vm.saveNow(); onBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(enabled = state.canUndo, onClick = { canvasRef?.undo() }) {
                        Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "Undo")
                    }
                    IconButton(enabled = state.canRedo, onClick = { canvasRef?.redo() }) {
                        Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "Redo")
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = "More")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(text = { Text("Rename note") }, onClick = { showRename = true; menuOpen = false })
                            DropdownMenuItem(text = { Text("Page setup & templates") }, onClick = { showPageSheet = true; menuOpen = false })
                            DropdownMenuItem(text = { Text("Tidy handwriting (geometric)") }, onClick = { showTidySheet = true; menuOpen = false })
                            HorizontalDivider()
                            DropdownMenuItem(text = { Text("Add page") }, onClick = { vm.addPage(); menuOpen = false })
                            DropdownMenuItem(text = { Text("Duplicate page") }, onClick = { vm.duplicateCurrentPage(); menuOpen = false })
                            DropdownMenuItem(text = { Text("Delete page") }, onClick = { vm.deleteCurrentPage(); menuOpen = false })
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Export note as PDF") },
                                onClick = {
                                    menuOpen = false
                                    val name = (state.note?.title?.ifBlank { "NoteFlow" } ?: "NoteFlow") + ".pdf"
                                    pdfLauncher.launch(name)
                                }
                            )
                            DropdownMenuItem(text = { Text("Clear this page") }, onClick = { canvasRef?.clearPage(); menuOpen = false })
                        }
                    }
                }
            )
        },
        bottomBar = {
            Column {
                if (state.selectionCount > 0) {
                    SelectionBar(
                        count = state.selectionCount,
                        onDelete = { canvasRef?.deleteSelection() },
                        onDuplicate = { canvasRef?.duplicateSelection() },
                        onCopy = { canvasRef?.copySelection() },
                        onPaste = { canvasRef?.paste() },
                        onScaleUp = { canvasRef?.scaleSelection(1.1f) },
                        onScaleDown = { canvasRef?.scaleSelection(0.9f) },
                        onRotate = { canvasRef?.rotateSelection(15f) }
                    )
                }
                PenToolbar(
                    state = state,
                    largeTargets = largeTargets,
                    onBrush = { vm.setBrush(it); canvasRef?.brush = it },
                    onMode = { vm.setMode(it); canvasRef?.mode = it },
                    onToggleRuler = {
                        val next = if (state.rulerAngle == null) 0f else null
                        vm.setRuler(next); canvasRef?.rulerAngleDeg = next
                    },
                    onRulerAngle = { vm.setRuler(it); canvasRef?.rulerAngleDeg = it },
                    onToggleShapeSnap = { vm.setShapeSnap(!state.shapeSnap) },
                    onToggleZoomLock = { vm.setZoomLock(!state.zoomLocked) },
                    onFingerPolicy = { vm.setFingerPolicy(it) }
                )
                PageBar(
                    index = state.pageIndex,
                    total = state.pages.size,
                    sizeLabel = state.spec.size.label,
                    onPrev = { vm.goToPage(state.pageIndex - 1) },
                    onNext = { vm.goToPage(state.pageIndex + 1) },
                    onAdd = { vm.addPage() },
                    onSetup = { showPageSheet = true }
                )
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    InkCanvasView(ctx).apply {
                        canvasRef = this
                        listener = object : InkCanvasView.Listener {
                            override fun onInkChanged() = vm.onInkChanged()
                            override fun onViewportChanged(zoom: Float, panX: Float, panY: Float) =
                                vm.saveViewport(zoom, panX, panY)
                            override fun onSelectionChanged(count: Int) = vm.setSelectionCount(count)
                            override fun onHistoryChanged(canUndo: Boolean, canRedo: Boolean) =
                                vm.setHistory(canUndo, canRedo)
                            override fun onShapeRecognized(shape: app.noteflow.ink.ShapeRecognizer.Shape) {
                                vm.showMessage("Snapped to ${shape.name.lowercase()}")
                            }
                        }
                    }
                },
                update = { view ->
                    if (view.document !== vm.document) view.document = vm.document
                    view.pageSpec = state.spec
                    view.brush = state.brush
                    view.mode = state.mode
                    view.fingerPolicy = state.fingerPolicy
                    view.shapeSnapEnabled = state.shapeSnap
                    view.zoomLocked = state.zoomLocked
                    view.rulerAngleDeg = state.rulerAngle
                }
            )
            if (state.loading) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {}
            }
        }
    }

    if (showRename) {
        TextPromptDialog(
            title = "Rename note",
            initial = state.note?.title.orEmpty(),
            confirmLabel = "Save",
            onDismiss = { showRename = false },
            onConfirm = { vm.rename(it); showRename = false }
        )
    }

    if (showPageSheet) {
        PageSetupSheet(
            vm = vm,
            state = state,
            onDismiss = { showPageSheet = false }
        )
    }

    if (showTidySheet) {
        TidyHandwritingSheet(
            vm = vm,
            canvas = canvasRef,
            onDismiss = { showTidySheet = false }
        )
    }
}

@Composable
private fun SaveStatusLabel(status: SaveStatus, onRetry: () -> Unit) {
    val time = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
    when (status) {
        SaveStatus.Idle -> Text("Local note", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        SaveStatus.Saving -> Text("Saving…", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        is SaveStatus.Saved -> Text(
            "Saved ${time.format(Date(status.at))}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        is SaveStatus.Error -> Row(verticalAlignment = Alignment.CenterVertically) {
            Text(status.message, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.width(8.dp))
            AssistChip(onClick = onRetry, label = { Text("Retry") })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PenToolbar(
    state: EditorUiState,
    largeTargets: Boolean,
    onBrush: (app.noteflow.domain.model.InkBrush) -> Unit,
    onMode: (InkCanvasView.Mode) -> Unit,
    onToggleRuler: () -> Unit,
    onRulerAngle: (Float) -> Unit,
    onToggleShapeSnap: () -> Unit,
    onToggleZoomLock: () -> Unit,
    onFingerPolicy: (InkCanvasView.FingerPolicy) -> Unit
) {
    var showWidth by remember { mutableStateOf(false) }
    var fingerMenu by remember { mutableStateOf(false) }
    val buttonSize = if (largeTargets) 56.dp else 48.dp

    Surface(tonalElevation = 3.dp) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                items(InkTool.entries.size) { index ->
                    val tool = InkTool.entries[index]
                    FilterChip(
                        selected = state.mode == InkCanvasView.Mode.DRAW && state.brush.tool == tool,
                        onClick = {
                            onMode(InkCanvasView.Mode.DRAW)
                            onBrush(
                                state.brush.copy(
                                    tool = tool,
                                    widthPt = if (tool == InkTool.HIGHLIGHTER) 14f else state.brush.widthPt.coerceAtMost(8f),
                                    opacity = if (tool == InkTool.HIGHLIGHTER) 0.35f else 1f
                                )
                            )
                        },
                        leadingIcon = {
                            Icon(
                                if (tool == InkTool.HIGHLIGHTER) Icons.Outlined.Highlight else Icons.Outlined.Brush,
                                null
                            )
                        },
                        label = { Text(tool.label) }
                    )
                }
                item {
                    FilterChip(
                        selected = state.mode == InkCanvasView.Mode.ERASE_STROKE,
                        onClick = { onMode(InkCanvasView.Mode.ERASE_STROKE) },
                        leadingIcon = { Icon(Icons.Outlined.CleaningServices, null) },
                        label = { Text("Erase stroke") }
                    )
                }
                item {
                    FilterChip(
                        selected = state.mode == InkCanvasView.Mode.ERASE_PIXEL,
                        onClick = { onMode(InkCanvasView.Mode.ERASE_PIXEL) },
                        leadingIcon = { Icon(Icons.Outlined.CleaningServices, null) },
                        label = { Text("Erase part") }
                    )
                }
                item {
                    FilterChip(
                        selected = state.mode == InkCanvasView.Mode.LASSO,
                        onClick = { onMode(InkCanvasView.Mode.LASSO) },
                        leadingIcon = { Icon(Icons.Outlined.Gesture, null) },
                        label = { Text("Lasso") }
                    )
                }
                item {
                    FilterChip(
                        selected = state.mode == InkCanvasView.Mode.PAN,
                        onClick = { onMode(InkCanvasView.Mode.PAN) },
                        leadingIcon = { Icon(Icons.Outlined.PanTool, null) },
                        label = { Text("Pan") }
                    )
                }
                item {
                    FilterChip(
                        selected = state.shapeSnap,
                        onClick = onToggleShapeSnap,
                        leadingIcon = { Icon(Icons.Outlined.Category, null) },
                        label = { Text("Shapes") }
                    )
                }
                item {
                    FilterChip(
                        selected = state.rulerAngle != null,
                        onClick = onToggleRuler,
                        leadingIcon = { Icon(Icons.Outlined.Straighten, null) },
                        label = { Text("Ruler") }
                    )
                }
                item {
                    FilterChip(
                        selected = state.zoomLocked,
                        onClick = onToggleZoomLock,
                        leadingIcon = { Icon(if (state.zoomLocked) Icons.Outlined.Lock else Icons.Outlined.LockOpen, null) },
                        label = { Text("Zoom lock") }
                    )
                }
                item {
                    Box {
                        FilterChip(
                            selected = false,
                            onClick = { fingerMenu = true },
                            leadingIcon = { Icon(Icons.Outlined.PanTool, null) },
                            label = { Text("Finger: ${state.fingerPolicy.name.lowercase()}") }
                        )
                        DropdownMenu(expanded = fingerMenu, onDismissRequest = { fingerMenu = false }) {
                            InkCanvasView.FingerPolicy.entries.forEach { policy ->
                                DropdownMenuItem(
                                    text = { Text(policy.name.lowercase().replaceFirstChar { it.uppercase() }) },
                                    leadingIcon = { if (policy == state.fingerPolicy) Icon(Icons.Filled.Check, null) },
                                    onClick = { onFingerPolicy(policy); fingerMenu = false }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                    items(PenColors.size) { index ->
                        val color = PenColors[index]
                        val selected = state.brush.colorArgb == color.toArgb()
                        Surface(
                            shape = CircleShape,
                            color = color,
                            border = if (selected)
                                androidx.compose.foundation.BorderStroke(3.dp, MaterialTheme.colorScheme.primary)
                            else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.size(if (largeTargets) 40.dp else 32.dp)
                        ) {
                            Box(Modifier.fillMaxSize().androidxClickable { onBrush(state.brush.copy(colorArgb = color.toArgb())) })
                        }
                    }
                }
                IconButton(onClick = { showWidth = !showWidth }, modifier = Modifier.size(buttonSize)) {
                    Icon(Icons.Outlined.Brush, contentDescription = "Stroke options")
                }
            }

            if (showWidth) {
                Text("Width ${"%.1f".format(state.brush.widthPt)} pt", style = MaterialTheme.typography.labelSmall)
                Slider(
                    value = state.brush.widthPt,
                    onValueChange = { onBrush(state.brush.copy(widthPt = it)) },
                    valueRange = 0.5f..30f
                )
                Text("Opacity ${(state.brush.opacity * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
                Slider(
                    value = state.brush.opacity,
                    onValueChange = { onBrush(state.brush.copy(opacity = it)) },
                    valueRange = 0.05f..1f
                )
                Text("Pressure response ${(state.brush.pressureResponse * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
                Slider(
                    value = state.brush.pressureResponse,
                    onValueChange = { onBrush(state.brush.copy(pressureResponse = it)) },
                    valueRange = 0f..1f
                )
                if (state.rulerAngle != null) {
                    Text("Ruler angle ${state.rulerAngle?.toInt()}°", style = MaterialTheme.typography.labelSmall)
                    Slider(
                        value = state.rulerAngle ?: 0f,
                        onValueChange = onRulerAngle,
                        valueRange = -90f..90f
                    )
                }
            }
        }
    }
}

@Composable
private fun SelectionBar(
    count: Int,
    onDelete: () -> Unit,
    onDuplicate: () -> Unit,
    onCopy: () -> Unit,
    onPaste: () -> Unit,
    onScaleUp: () -> Unit,
    onScaleDown: () -> Unit,
    onRotate: () -> Unit
) {
    Surface(tonalElevation = 6.dp) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("$count selected", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onCopy) { Icon(Icons.Outlined.ContentCopy, "Copy") }
            IconButton(onClick = onPaste) { Icon(Icons.Outlined.ContentPaste, "Paste") }
            IconButton(onClick = onDuplicate) { Icon(Icons.Filled.Add, "Duplicate") }
            IconButton(onClick = onScaleDown) { Icon(Icons.Filled.ChevronLeft, "Smaller") }
            IconButton(onClick = onScaleUp) { Icon(Icons.Filled.ChevronRight, "Bigger") }
            IconButton(onClick = onRotate) { Icon(Icons.Outlined.AutoFixHigh, "Rotate 15°") }
            IconButton(onClick = onDelete) { Icon(Icons.Outlined.Delete, "Delete") }
        }
    }
}

@Composable
private fun PageBar(
    index: Int,
    total: Int,
    sizeLabel: String,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onAdd: () -> Unit,
    onSetup: () -> Unit
) {
    Surface(tonalElevation = 1.dp) {
        Row(
            Modifier.fillMaxWidth().height(46.dp).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(enabled = index > 0, onClick = onPrev) { Icon(Icons.Filled.ChevronLeft, "Previous page") }
            Text("Page ${index + 1} / $total", style = MaterialTheme.typography.labelLarge)
            IconButton(enabled = index < total - 1, onClick = onNext) { Icon(Icons.Filled.ChevronRight, "Next page") }
            Spacer(Modifier.weight(1f))
            AssistChip(onClick = onSetup, label = { Text(sizeLabel) })
            IconButton(onClick = onAdd) { Icon(Icons.Filled.Add, "Add page") }
        }
    }
}

private fun Modifier.androidxClickable(onClick: () -> Unit): Modifier =
    this.then(Modifier.clickable { onClick() })
