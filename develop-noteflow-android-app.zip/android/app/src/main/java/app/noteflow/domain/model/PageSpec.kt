package app.noteflow.domain.model

/**
 * True physical page geometry.
 *
 * Everything is stored in PostScript points (1 pt = 1/72 inch), which is exactly what
 * Android's PdfDocument.PageInfo and every PDF reader expect. Millimetre sizes are
 * converted once here, so a page is the same physical size on screen, on paper and in
 * an exported PDF.
 *
 *   pt = mm * 72 / 25.4
 *
 *   A2 420 x 594 mm -> 1190.55 x 1683.78 pt
 *   A3 297 x 420 mm ->  841.89 x 1190.55 pt
 *   A4 210 x 297 mm ->  595.28 x  841.89 pt
 *   A5 148 x 210 mm ->  419.53 x  595.28 pt
 *   A6 105 x 148 mm ->  297.64 x  419.53 pt
 */
object Units {
    const val MM_PER_INCH = 25.4f
    const val PT_PER_INCH = 72f
    fun mmToPt(mm: Float): Float = mm * PT_PER_INCH / MM_PER_INCH
    fun ptToMm(pt: Float): Float = pt * MM_PER_INCH / PT_PER_INCH
}

enum class PageSizePreset(
    val id: String,
    val label: String,
    val widthMm: Float,
    val heightMm: Float
) {
    A2("A2", "A2 · 420 × 594 mm", 420f, 594f),
    A3("A3", "A3 · 297 × 420 mm", 297f, 420f),
    A4("A4", "A4 · 210 × 297 mm", 210f, 297f),
    A5("A5", "A5 · 148 × 210 mm", 148f, 210f),
    A6("A6", "A6 · 105 × 148 mm", 105f, 148f),
    LETTER("LETTER", "US Letter · 8.5 × 11 in", 215.9f, 279.4f),

    /**
     * Not a sheet of paper: a scrollable surface. It still has a *nominal* size so that
     * export can tile it, but the editor clearly labels it "Infinite canvas".
     */
    INFINITE("INFINITE", "Infinite canvas", 297f, 420f);

    val widthPt: Float get() = Units.mmToPt(widthMm)
    val heightPt: Float get() = Units.mmToPt(heightMm)
    val isFixedSheet: Boolean get() = this != INFINITE

    companion object {
        fun fromId(id: String?): PageSizePreset = entries.firstOrNull { it.id == id } ?: A4
    }
}

enum class PageOrientation { PORTRAIT, LANDSCAPE;
    companion object {
        fun fromId(id: String?) = if (id == "LANDSCAPE") LANDSCAPE else PORTRAIT
    }
}

enum class PageKind { INK, TEXT, PDF;
    companion object { fun fromId(id: String?) = entries.firstOrNull { it.name == id } ?: INK }
}

enum class PageTemplate(val id: String, val label: String) {
    BLANK("BLANK", "Blank"),
    LINED("LINED", "Lined"),
    RULED("RULED", "Wide ruled"),
    DOTTED("DOTTED", "Dot grid"),
    GRID("GRID", "Square grid"),
    GRAPH("GRAPH", "Graph (5 mm + major)"),
    CORNELL("CORNELL", "Cornell notes"),
    PLANNER("PLANNER", "Daily planner"),
    TIMETABLE("TIMETABLE", "Weekly timetable"),
    MUSIC("MUSIC", "Music staves"),
    ENGINEERING("ENGINEERING", "Engineering pad");

    companion object { fun fromId(id: String?) = entries.firstOrNull { it.id == id } ?: BLANK }
}

/** Fully resolved description of one page, independent of Room and of Compose. */
data class PageSpec(
    val size: PageSizePreset = PageSizePreset.A4,
    val orientation: PageOrientation = PageOrientation.PORTRAIT,
    val template: PageTemplate = PageTemplate.BLANK,
    val backgroundArgb: Int = 0xFFFFFFFF.toInt(),
    val lineArgb: Int = 0xFFBFD7D6.toInt(),
    val gridSpacingMm: Float = 5f,
    val marginMm: Float = 0f
) {
    val widthPt: Float
        get() = if (orientation == PageOrientation.PORTRAIT) size.widthPt else size.heightPt
    val heightPt: Float
        get() = if (orientation == PageOrientation.PORTRAIT) size.heightPt else size.widthPt

    val aspectRatio: Float get() = widthPt / heightPt

    /** Points per millimetre is constant (72/25.4); handy for template maths. */
    val ptPerMm: Float get() = Units.PT_PER_INCH / Units.MM_PER_INCH
}
