package app.noteflow.data.files

import android.util.Log
import app.noteflow.domain.model.InkBrush
import app.noteflow.domain.model.InkDocument
import app.noteflow.domain.model.InkTool
import app.noteflow.domain.model.STRIDE
import app.noteflow.domain.model.Stroke
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream

/**
 * Binary format for one page of vector ink (".nfink").
 *
 * Layout:
 *   magic   : 6 bytes  "NFINK\u0001"
 *   version : int
 *   strokes : int
 *   per stroke:
 *     id int64, toolId utf, colorArgb int, widthPt float, opacity float,
 *     pressureResponse float, nibAngleDeg float, pointCount int,
 *     pointCount * (x float, y float, pressure float, tMs float)
 *
 * Why a custom binary format instead of JSON: a dense A4 page can hold 30k+ points.
 * Floats cost 4 bytes here vs ~10 characters in JSON, parsing is ~10x faster, and the
 * reader can bail out safely on a truncated file (returns what it managed to read).
 */
object InkCodec {

    private const val TAG = "InkCodec"
    private val MAGIC = byteArrayOf('N'.code.toByte(), 'F'.code.toByte(), 'I'.code.toByte(), 'N'.code.toByte(), 'K'.code.toByte(), 1)
    const val VERSION = 1

    fun write(out: OutputStream, doc: InkDocument) {
        val data = DataOutputStream(out)
        data.write(MAGIC)
        data.writeInt(VERSION)
        data.writeInt(doc.strokes.size)
        for (s in doc.strokes) {
            data.writeLong(s.id)
            data.writeUTF(s.brush.tool.id)
            data.writeInt(s.brush.colorArgb)
            data.writeFloat(s.brush.widthPt)
            data.writeFloat(s.brush.opacity)
            data.writeFloat(s.brush.pressureResponse)
            data.writeFloat(s.brush.nibAngleDeg)
            data.writeInt(s.pointCount)
            for (i in 0 until s.pointCount * STRIDE) data.writeFloat(s.points[i])
        }
        data.flush()
    }

    /** Tolerant reader: a truncated file yields the strokes that were fully written. */
    fun read(input: InputStream): InkDocument {
        val doc = InkDocument()
        val data = DataInputStream(input)
        return try {
            val magic = ByteArray(MAGIC.size)
            data.readFully(magic)
            require(magic.contentEquals(MAGIC)) { "not a NoteFlow ink file" }
            val version = data.readInt()
            require(version <= VERSION) { "ink file version $version is newer than this app" }
            val count = data.readInt()
            repeat(count) {
                val id = data.readLong()
                val brush = InkBrush(
                    tool = InkTool.fromId(data.readUTF()),
                    colorArgb = data.readInt(),
                    widthPt = data.readFloat(),
                    opacity = data.readFloat(),
                    pressureResponse = data.readFloat(),
                    nibAngleDeg = data.readFloat()
                )
                val pointCount = data.readInt()
                val points = FloatArray(pointCount * STRIDE)
                for (i in points.indices) points[i] = data.readFloat()
                doc.add(Stroke(id, brush, points, pointCount).also { it.recomputeBounds() })
            }
            doc
        } catch (t: Throwable) {
            Log.w(TAG, "Recovered ${doc.strokes.size} strokes from a damaged ink file", t)
            doc
        }
    }

    fun readFile(file: File): InkDocument =
        if (!file.exists()) InkDocument() else file.inputStream().buffered().use { read(it) }

    fun writeFile(store: FileStore, file: File, doc: InkDocument): Boolean =
        store.writeAtomically(file) { write(it, doc) }
}
