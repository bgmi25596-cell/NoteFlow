package app.noteflow.data.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import app.noteflow.ink.InkCanvasView
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("noteflow_settings")

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val firstRunDone: Boolean = false,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accentIndex: Int = 0,
    val defaultPageSizeId: String = "A4",
    val defaultTemplateId: String = "BLANK",
    val defaultOrientation: String = "PORTRAIT",
    val fingerPolicy: InkCanvasView.FingerPolicy = InkCanvasView.FingerPolicy.SCROLL,
    val shapeSnap: Boolean = false,
    val zoomLock: Boolean = false,
    val pressureResponse: Float = 0.75f,
    val largeTouchTargets: Boolean = false,
    val autosaveSeconds: Int = 2
)

/**
 * All user preferences, stored locally with Jetpack DataStore (no cloud sync).
 * Everything is a plain value so the settings screen can be fully driven by state.
 */
class SettingsStore(private val context: Context) {

    private object Keys {
        val firstRun = booleanPreferencesKey("first_run_done")
        val theme = stringPreferencesKey("theme_mode")
        val accent = intPreferencesKey("accent_index")
        val pageSize = stringPreferencesKey("default_page_size")
        val template = stringPreferencesKey("default_template")
        val orientation = stringPreferencesKey("default_orientation")
        val finger = stringPreferencesKey("finger_policy")
        val shapeSnap = booleanPreferencesKey("shape_snap")
        val zoomLock = booleanPreferencesKey("zoom_lock")
        val pressure = floatPreferencesKey("pressure_response")
        val largeTargets = booleanPreferencesKey("large_touch_targets")
        val autosave = intPreferencesKey("autosave_seconds")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        AppSettings(
            firstRunDone = p[Keys.firstRun] ?: false,
            themeMode = runCatching { ThemeMode.valueOf(p[Keys.theme] ?: "SYSTEM") }.getOrDefault(ThemeMode.SYSTEM),
            accentIndex = p[Keys.accent] ?: 0,
            defaultPageSizeId = p[Keys.pageSize] ?: "A4",
            defaultTemplateId = p[Keys.template] ?: "BLANK",
            defaultOrientation = p[Keys.orientation] ?: "PORTRAIT",
            fingerPolicy = runCatching {
                InkCanvasView.FingerPolicy.valueOf(p[Keys.finger] ?: "SCROLL")
            }.getOrDefault(InkCanvasView.FingerPolicy.SCROLL),
            shapeSnap = p[Keys.shapeSnap] ?: false,
            zoomLock = p[Keys.zoomLock] ?: false,
            pressureResponse = p[Keys.pressure] ?: 0.75f,
            largeTouchTargets = p[Keys.largeTargets] ?: false,
            autosaveSeconds = p[Keys.autosave] ?: 2
        )
    }

    suspend fun setFirstRunDone() = context.dataStore.edit { it[Keys.firstRun] = true }
    suspend fun setTheme(mode: ThemeMode) = context.dataStore.edit { it[Keys.theme] = mode.name }
    suspend fun setAccent(index: Int) = context.dataStore.edit { it[Keys.accent] = index }
    suspend fun setDefaultPage(sizeId: String, templateId: String, orientation: String) =
        context.dataStore.edit {
            it[Keys.pageSize] = sizeId; it[Keys.template] = templateId; it[Keys.orientation] = orientation
        }
    suspend fun setFingerPolicy(policy: InkCanvasView.FingerPolicy) =
        context.dataStore.edit { it[Keys.finger] = policy.name }
    suspend fun setShapeSnap(enabled: Boolean) = context.dataStore.edit { it[Keys.shapeSnap] = enabled }
    suspend fun setZoomLock(enabled: Boolean) = context.dataStore.edit { it[Keys.zoomLock] = enabled }
    suspend fun setPressure(value: Float) = context.dataStore.edit { it[Keys.pressure] = value }
    suspend fun setLargeTargets(enabled: Boolean) = context.dataStore.edit { it[Keys.largeTargets] = enabled }
    suspend fun setAutosaveSeconds(value: Int) = context.dataStore.edit { it[Keys.autosave] = value }
}
