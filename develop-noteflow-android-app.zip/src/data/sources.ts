import workflowRaw from "../../.github/workflows/android-build.yml?raw";

/**
 * The browser loads the REAL Android source files from this repository at build time,
 * so nothing shown on this page can drift away from the code that is actually shipped.
 */
const androidFiles = import.meta.glob("../../android/**/*.{kt,kts,xml,pro,properties,md}", {
  query: "?raw",
  import: "default",
  eager: true,
}) as Record<string, string>;

const docFiles = import.meta.glob("../../docs/*.md", {
  query: "?raw",
  import: "default",
  eager: true,
}) as Record<string, string>;

export type SourceFile = {
  path: string;
  name: string;
  dir: string;
  content: string;
  lines: number;
  bytes: number;
  language: string;
  group: string;
};

function languageOf(path: string): string {
  if (path.endsWith(".kt")) return "Kotlin";
  if (path.endsWith(".kts")) return "Kotlin DSL";
  if (path.endsWith(".xml")) return "XML";
  if (path.endsWith(".md")) return "Markdown";
  if (path.endsWith(".yml") || path.endsWith(".yaml")) return "YAML";
  if (path.endsWith(".pro")) return "ProGuard";
  if (path.endsWith(".properties")) return "Properties";
  return "Text";
}

function groupOf(path: string): string {
  if (path.startsWith("docs/")) return "Documentation";
  if (path.startsWith(".github/")) return "CI / APK build";
  if (path.includes("/src/test/")) return "Tests";
  if (path.includes("/res/")) return "Android resources";
  if (path.includes("/ui/")) return "UI · Compose";
  if (path.includes("/ink/")) return "Rendering · ink engine";
  if (path.includes("/domain/")) return "Domain";
  if (path.includes("/data/")) return "Data · storage";
  if (path.includes("/export/")) return "Export";
  if (path.endsWith(".kts") || path.endsWith(".properties") || path.endsWith(".pro")) return "Build config";
  if (path.endsWith("AndroidManifest.xml")) return "Build config";
  if (path.endsWith(".md")) return "Documentation";
  return "App";
}

function build(): SourceFile[] {
  const entries: Array<[string, string]> = [];

  for (const [key, content] of Object.entries(androidFiles)) {
    entries.push([key.replace("../../", ""), content]);
  }
  for (const [key, content] of Object.entries(docFiles)) {
    entries.push([key.replace("../../", ""), content]);
  }
  entries.push([".github/workflows/android-build.yml", workflowRaw]);

  return entries
    .map(([path, content]) => {
      const parts = path.split("/");
      return {
        path,
        name: parts[parts.length - 1],
        dir: parts.slice(0, -1).join("/"),
        content,
        lines: content.split("\n").length,
        bytes: new Blob([content]).size,
        language: languageOf(path),
        group: groupOf(path),
      };
    })
    .sort((a, b) => a.path.localeCompare(b.path));
}

export const sourceFiles: SourceFile[] = build();

export const sourceStats = {
  files: sourceFiles.length,
  lines: sourceFiles.reduce((sum, f) => sum + f.lines, 0),
  kotlinFiles: sourceFiles.filter((f) => f.language.startsWith("Kotlin")).length,
  kotlinLines: sourceFiles
    .filter((f) => f.language.startsWith("Kotlin"))
    .reduce((sum, f) => sum + f.lines, 0),
  testFiles: sourceFiles.filter((f) => f.group === "Tests").length,
};

export function fileByPath(path: string): SourceFile | undefined {
  return sourceFiles.find((f) => f.path === path);
}

export const groups = Array.from(new Set(sourceFiles.map((f) => f.group))).sort();
