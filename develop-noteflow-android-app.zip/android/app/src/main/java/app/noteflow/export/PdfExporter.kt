package app.noteflow.export

import android.content.Context
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.util.Log
import app.noteflow.data.repository.NotesRepository
import app.noteflow.data.repository.toSpec
import app.noteflow.ink.InkRenderer
import app.noteflow.ink.TemplateRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * PDF export built on the Android platform's own [PdfDocument] (android.graphics.pdf) —
 * no third-party PDF library, no licence question, no download size.
 *
 * PdfDocument.PageInfo takes its width/height in PostScript points, which is exactly how
 * NoteFlow stores page geometry, so an A4 page exports as a true 595.28 × 841.89 pt page
 * and the 5 mm grid measures 5 mm on paper. Strokes are drawn with the same [InkRenderer]
 * used on screen, into the PDF's vector canvas — the output is not a screenshot.
 */
class PdfExporter(
    private val context: Context,
    private val repository: NotesRepository
) {
    private val inkRenderer = InkRenderer()
    private val templateRenderer = TemplateRenderer()

    data class Progress(val page: Int, val total: Int)

    suspend fun export(
        noteId: String,
        target: Uri,
        includeTemplate: Boolean = true,
        onProgress: (Progress) -> Unit = {}
    ): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val pages = repository.pagesOf(noteId)
            require(pages.isNotEmpty()) { "This note has no pages." }
            val document = PdfDocument()
            try {
                pages.forEachIndexed { index, pageEntity ->
                    onProgress(Progress(index + 1, pages.size))
                    val spec = pageEntity.toSpec()
                    val info = PdfDocument.PageInfo.Builder(
                        Math.round(spec.widthPt),
                        Math.round(spec.heightPt),
                        index + 1
                    ).create()
                    val page = document.startPage(info)
                    if (includeTemplate) templateRenderer.draw(page.canvas, spec)
                    val ink = repository.loadInk(pageEntity)
                    inkRenderer.drawAll(page.canvas, ink.strokes)
                    document.finishPage(page)
                }
                context.contentResolver.openOutputStream(target, "wt")?.use { document.writeTo(it) }
                    ?: error("Could not open the chosen location for writing.")
            } finally {
                document.close()
            }
            pages.size
        }.onFailure { Log.e(TAG, "PDF export failed", it) }
    }

    companion object { private const val TAG = "PdfExporter" }
}
