package app.noteflow.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import app.noteflow.data.local.dao.FolderDao
import app.noteflow.data.local.dao.NoteDao
import app.noteflow.data.local.dao.PageDao
import app.noteflow.data.local.entity.AttachmentEntity
import app.noteflow.data.local.entity.FolderEntity
import app.noteflow.data.local.entity.NoteEntity
import app.noteflow.data.local.entity.NoteTagCrossRef
import app.noteflow.data.local.entity.PageEntity
import app.noteflow.data.local.entity.TagEntity
import app.noteflow.data.local.entity.TemplatePresetEntity

@Database(
    entities = [
        NoteEntity::class,
        FolderEntity::class,
        PageEntity::class,
        TagEntity::class,
        NoteTagCrossRef::class,
        AttachmentEntity::class,
        TemplatePresetEntity::class
    ],
    version = NoteFlowDatabase.VERSION,
    exportSchema = true
)
abstract class NoteFlowDatabase : RoomDatabase() {

    abstract fun noteDao(): NoteDao
    abstract fun folderDao(): FolderDao
    abstract fun pageDao(): PageDao

    companion object {
        const val VERSION = 1
        private const val NAME = "noteflow.db"

        @Volatile private var instance: NoteFlowDatabase? = null

        fun get(context: Context): NoteFlowDatabase = instance ?: synchronized(this) {
            instance ?: build(context.applicationContext).also { instance = it }
        }

        private fun build(context: Context): NoteFlowDatabase =
            Room.databaseBuilder(context, NoteFlowDatabase::class.java, NAME)
                // Every schema change ships a real migration (see Migrations.kt).
                // Destructive fallback is deliberately NOT enabled: user notes must never
                // be wiped silently by an upgrade.
                .addMigrations(*Migrations.ALL)
                .addCallback(object : Callback() {
                    override fun onConfigure(db: SupportSQLiteDatabase) {
                        db.execSQL("PRAGMA foreign_keys = ON;")
                    }
                })
                .build()
    }
}
