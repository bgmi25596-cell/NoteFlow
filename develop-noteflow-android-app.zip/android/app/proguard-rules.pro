# Keep kotlinx.serialization generated serializers used by the JSON backup format.
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
-keepclassmembers class app.noteflow.** {
    *** Companion;
}
-keepclasseswithmembers class app.noteflow.** {
    kotlinx.serialization.KSerializer serializer(...);
}
# Room entities are referenced reflectively by generated code.
-keep class app.noteflow.data.local.entity.** { *; }
