# NoteFlow roadmap — small milestones a beginner can continue with AI

Each milestone is sized so you can ask an AI assistant for *one* file at a time, upload it
to GitHub, run the build workflow and see the result on your phone.

## Done

### Phase 1 — skeleton, storage, autosave ✅
* `NoteFlowApplication` + `AppContainer`, `MainActivity`, Compose navigation
* Room schema (notes, folders, pages, tags, attachments, presets) + DAOs + migration policy
* `FileStore` with atomic writes, orphan pruning, free-space checks
* Home screen (search, folders, tags, sort, pin, archive, bin) and editor shell
* Debounced autosave with visible status and a Retry action

### Phase 2 — ink engine ✅
* `InkCanvasView`: MotionEvent + historical samples, stylus priority, palm-rejection window,
  configurable finger policy, pinch/pan/zoom-lock
* 7 pens in `InkRenderer`, live + commit smoothing in `StrokeSmoother`
* stroke eraser, partial eraser, lasso (move/scale/rotate/copy/paste/duplicate/delete)
* `InkHistory` command-based undo/redo, `ShapeRecognizer`, ruler, grid snap
* `InkCodec` binary vector format (never a screenshot)

### Phase 3 — pages, templates, themes ✅
* A2–A6 + Letter + infinite canvas, both orientations, exact PDF-point geometry
* 11 templates in `TemplateRenderer` with custom colours, spacing, margins
* built-in + user template presets, multi-page add/duplicate/reorder/delete
* light/dark themes, 6 accents, larger-touch-target option, first-run flow
* PDF export, JSON backup/import with validation

## Next

### Phase 4a — images (start here, ~2 files)
1. `data/media/ImageImporter.kt`: copy a picked image into `FileStore.mediaDir`, downsample
   with `BitmapFactory.Options.inSampleSize` so a 50 MP photo cannot OOM.
2. Extend `InkCanvasView` with an `overlays` list (image rect + rotation) drawn under ink,
   plus a selection handle to move/resize/rotate/crop.
3. Persist overlays in a new `page_overlays` table → **write MIGRATION_1_2** and bump
   `NoteFlowDatabase.VERSION` to 2.

### Phase 4b — text boxes & rich text
* A `TEXT` page kind already exists in the schema; render Compose `BasicTextField`
  overlays positioned in page space, store the content in `pages.textJson`.
* Headings, bullets, checklists as a small JSON block model (keep it simple: a list of
  blocks with `type`, `text`, `checked`).

### Phase 4c — PDF import & annotation
* Render with the platform `android.graphics.pdf.PdfRenderer` (no extra dependency) into a
  tile cache; store the source PDF in `FileStore`, one `PageEntity(kind = "PDF")` per page.
* Export = draw the rendered page into `PdfDocument` + ink on top. (True PDF *annotation
  objects* would need PdfBox-Android; check size/licence before adding it.)

### Phase 4d — audio
* `MediaRecorder` to `FileStore.mediaDir`, `MediaPlayer` for playback, one row per clip in
  `attachments`. Request `RECORD_AUDIO` **only** when the user taps Record, and add the
  permission to the manifest in the same commit.

### Phase 5 — handwriting beautification, honestly
* Keep the geometric refiner as the default.
* If you want to evaluate a model: check licence, size (< ~100 MB), RAM, latency and
  languages first; a realistic free option is an on-device **recognition** model, which
  gives you *text*, not nicer handwriting — if you ship that, label it
  "Convert to typed text".

### Phase 6 — OCR & study tools
* Candidate: Tesseract via `tess-two`/`tesseract4android` (Apache-2.0) — good for printed
  text, weak for cursive handwriting; ~15–30 MB per language data file, downloaded by the
  user, offline afterwards. Be explicit about accuracy in the UI.
* Only build summaries/flashcards on top of text that actually exists; never ship a
  "study AI" that silently needs a server.

### Phase 7 — polish & release
* Profile with Android Studio Profiler / `dumpsys gfxinfo`. Only if a page with 10k+
  strokes drops frames: add a static layer `Bitmap` cache for committed strokes, and only
  if that is still not enough consider an NDK/C++ renderer (not needed so far).
* Write instrumented tests with `MigrationTestHelper` once a real migration exists.
* Generate a release keystore and `assembleRelease` in the workflow.
