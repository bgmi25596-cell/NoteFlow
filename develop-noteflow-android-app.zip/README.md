# NoteFlow

A local-first Android note-taking and handwriting app — **Kotlin · Jetpack Compose ·
custom Canvas ink engine · Room/SQLite** — plus a companion web page that documents and
browses the project.

```
android/          the real Android Studio / Gradle project (this is the app)
.github/workflows build the APK for free on GitHub Actions (no PC required)
docs/             architecture, roadmap, testing checklist, licence inventory
src/              the React page you are looking at (project explorer, not the app)
```

* **Install guide:** `android/README.md`
* **Architecture:** `docs/ARCHITECTURE.md`
* **What works / what does not:** `android/README.md` → “Honest status”
* **Next milestones:** `docs/ROADMAP.md`
* **Licences:** `docs/LICENSES.md`

No account, no subscription, no ads, no analytics, and the Android manifest deliberately
contains **no INTERNET permission**. Notes stay on the device — which is private, but is
not a backup, so export a `.noteflow.json` file regularly.
