package app.noteflow.ui.editor

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.noteflow.domain.beautify.HandwritingRefiner
import app.noteflow.domain.model.PageOrientation
import app.noteflow.domain.model.PageSizePreset
import app.noteflow.domain.model.PageSpec
import app.noteflow.domain.model.PageTemplate
import app.noteflow.ink.InkCanvasView
import app.noteflow.ui.home.TextPromptDialog

private val PageColors = listOf(
    Color(0xFFFFFFFF), Color(0xFFFFFDF5), Color(0xFFF4F7F4),
    Color(0xFFEFF4FA), Color(0xFFFCF0E8), Color(0xFF1C1F1E), Color(0xFF14202B)
)
private val LineColors = listOf(
    Color(0xFFBFD7D6), Color(0xFFD8D8D8), Color(0xFFA9C7F0), Color(0xFFE3C7A9), Color(0xFF3A4442)
)

/** Page size, orientation, template, colours, grid spacing, margins and reusable presets. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PageSetupSheet(vm: EditorViewModel, state: EditorUiState, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val presets by vm.presets.collectAsStateWithLifecycle()
    var spec by remember { mutableStateOf(state.spec) }
    var showSavePreset by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Page setup", style = MaterialTheme.typography.titleLarge)
            Text(
                "Sizes are true physical dimensions in PDF points, so an A4 page prints and " +
                    "exports at exactly 210 × 297 mm.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Text("Presets", style = MaterialTheme.typography.titleMedium)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(presets.size) { index ->
                    val preset = presets[index]
                    AssistChip(
                        onClick = {
                            spec = PageSpec(
                                size = PageSizePreset.fromId(preset.pageSizeId),
                                orientation = PageOrientation.fromId(preset.orientation),
                                template = PageTemplate.fromId(preset.templateId),
                                backgroundArgb = preset.backgroundArgb,
                                lineArgb = preset.lineArgb,
                                gridSpacingMm = preset.gridSpacingMm,
                                marginMm = preset.marginMm
                            )
                        },
                        label = { Text(preset.name) }
                    )
                }
            }

            Text("Paper size", style = MaterialTheme.typography.titleMedium)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                PageSizePreset.entries.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { size ->
                            FilterChip(
                                selected = spec.size == size,
                                onClick = { spec = spec.copy(size = size) },
                                label = { Text(size.id) }
                            )
                        }
                    }
                }
            }
            Text(
                if (spec.size.isFixedSheet)
                    "${spec.size.label} → ${"%.1f".format(spec.widthPt)} × ${"%.1f".format(spec.heightPt)} pt"
                else
                    "Infinite canvas: scrolls in every direction. It is not a fixed sheet, so PDF export crops to the ink bounds.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (spec.size.isFixedSheet) {
                Text("Orientation", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PageOrientation.entries.forEach { o ->
                        FilterChip(
                            selected = spec.orientation == o,
                            onClick = { spec = spec.copy(orientation = o) },
                            label = { Text(o.name.lowercase().replaceFirstChar { it.uppercase() }) }
                        )
                    }
                }
            }

            Text("Template", style = MaterialTheme.typography.titleMedium)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                PageTemplate.entries.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { t ->
                            FilterChip(
                                selected = spec.template == t,
                                onClick = { spec = spec.copy(template = t) },
                                label = { Text(t.label) }
                            )
                        }
                    }
                }
            }

            Text("Page colour", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PageColors.forEach { c ->
                    ColorDot(c, spec.backgroundArgb == c.toArgb()) { spec = spec.copy(backgroundArgb = c.toArgb()) }
                }
            }

            Text("Rule / grid colour", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LineColors.forEach { c ->
                    ColorDot(c, spec.lineArgb == c.toArgb()) { spec = spec.copy(lineArgb = c.toArgb()) }
                }
            }

            Text("Grid spacing ${"%.1f".format(spec.gridSpacingMm)} mm", style = MaterialTheme.typography.labelLarge)
            Slider(
                value = spec.gridSpacingMm,
                onValueChange = { spec = spec.copy(gridSpacingMm = it) },
                valueRange = 2f..20f
            )
            Text("Margin ${"%.0f".format(spec.marginMm)} mm", style = MaterialTheme.typography.labelLarge)
            Slider(
                value = spec.marginMm,
                onValueChange = { spec = spec.copy(marginMm = it) },
                valueRange = 0f..30f
            )

            HorizontalDivider()
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.applySpec(spec); onDismiss() }) { Text("Apply to this page") }
                OutlinedButton(onClick = { vm.addPage(spec); onDismiss() }) { Text("Add new page") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { showSavePreset = true }) { Text("Save as preset") }
                TextButton(onClick = { vm.duplicateCurrentPage(); onDismiss() }) { Text("Duplicate page") }
                TextButton(onClick = { vm.deleteCurrentPage(); onDismiss() }) { Text("Delete page") }
            }
            if (state.pages.size > 1) {
                Text("Reorder pages", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        enabled = state.pageIndex > 0,
                        onClick = { vm.movePage(state.pageIndex, state.pageIndex - 1) }
                    ) { Text("Move earlier") }
                    OutlinedButton(
                        enabled = state.pageIndex < state.pages.size - 1,
                        onClick = { vm.movePage(state.pageIndex, state.pageIndex + 1) }
                    ) { Text("Move later") }
                }
            }
        }
    }

    if (showSavePreset) {
        TextPromptDialog(
            title = "Save template preset",
            initial = "My ${spec.template.label} ${spec.size.id}",
            confirmLabel = "Save",
            onDismiss = { showSavePreset = false },
            onConfirm = { vm.saveCurrentAsPreset(it); showSavePreset = false }
        )
    }
}

@Composable
private fun ColorDot(color: Color, selected: Boolean, onClick: () -> Unit) {
    Surface(
        shape = CircleShape,
        color = color,
        border = androidx.compose.foundation.BorderStroke(
            if (selected) 3.dp else 1.dp,
            if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
        ),
        modifier = Modifier.size(34.dp)
    ) { Box(Modifier.size(34.dp).clickable { onClick() }) }
}

/**
 * "Tidy handwriting" sheet.
 *
 * The copy here is deliberately precise: this is geometric refinement of YOUR strokes,
 * not an AI model that re-writes them. Nothing is downloaded and nothing leaves the phone.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TidyHandwritingSheet(vm: EditorViewModel, canvas: InkCanvasView?, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var neatness by remember { mutableStateOf(0.6f) }
    var baselines by remember { mutableStateOf(true) }
    var heights by remember { mutableStateOf(true) }
    var slant by remember { mutableStateOf(false) }
    var spacing by remember { mutableStateOf(false) }
    var previewing by remember { mutableStateOf(false) }

    val options = HandwritingRefiner.Options(neatness, baselines, heights, slant, spacing)

    ModalBottomSheet(onDismissRequest = { if (previewing) canvas?.undo(); onDismiss() }, sheetState = sheetState) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Tidy handwriting", style = MaterialTheme.typography.titleLarge)
            Text(
                "This is geometric stroke refinement — smoothing, baseline alignment and size " +
                    "evening applied to the strokes you actually wrote. It is NOT an AI model " +
                    "that regenerates handwriting, and it never converts your writing to typed " +
                    "text, so words, maths and diagrams keep their exact meaning.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                "Works fully offline. No model download, no permission, no network.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )

            Text("Strength ${(neatness * 100).toInt()}%", style = MaterialTheme.typography.labelLarge)
            Slider(value = neatness, onValueChange = { neatness = it }, valueRange = 0.1f..1f)

            ToggleRow("Align to baseline", baselines) { baselines = it }
            ToggleRow("Even out letter height", heights) { heights = it }
            ToggleRow("Normalise slant", slant) { slant = it }
            ToggleRow("Even out spacing", spacing) { spacing = it }

            Text(HandwritingRefiner.describe(options), style = MaterialTheme.typography.labelSmall)

            HorizontalDivider()
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        val view = canvas ?: return@Button
                        if (previewing) view.undo()
                        val targets = view.selectedStrokes().ifEmpty { view.document.copyOfStrokes() }
                        if (targets.isEmpty()) { vm.showMessage("Nothing to tidy on this page."); return@Button }
                        val proposed = vm.beautifyPreview(targets, options)
                        view.replaceStrokes(targets, proposed)
                        previewing = true
                    }
                ) { Text(if (previewing) "Update preview" else "Preview") }

                OutlinedButton(
                    enabled = previewing,
                    onClick = { vm.acceptBeautify(); previewing = false; onDismiss() }
                ) { Text("Accept") }

                TextButton(
                    enabled = previewing,
                    onClick = { canvas?.undo(); vm.rejectBeautify(); previewing = false }
                ) { Text("Reject") }
            }
            Text(
                "Tip: select strokes with the lasso first to tidy just one paragraph. " +
                    "Accepting still leaves a normal Undo step.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
