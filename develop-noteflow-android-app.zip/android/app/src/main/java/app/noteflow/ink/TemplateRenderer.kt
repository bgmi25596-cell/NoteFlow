package app.noteflow.ink

import android.graphics.Canvas
import android.graphics.Paint
import app.noteflow.domain.model.PageSpec
import app.noteflow.domain.model.PageTemplate

/**
 * Paints the paper itself: background colour, rules, grids and the structured templates.
 * Drawn in page-point space, so a 5 mm grid is genuinely 5 mm on paper after PDF export.
 */
class TemplateRenderer {

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)

    fun draw(canvas: Canvas, spec: PageSpec) {
        val w = spec.widthPt
        val h = spec.heightPt
        fill.color = spec.backgroundArgb
        canvas.drawRect(0f, 0f, w, h, fill)

        line.color = spec.lineArgb
        dot.color = spec.lineArgb
        val mm = spec.ptPerMm
        val step = (spec.gridSpacingMm.coerceAtLeast(1f)) * mm
        val margin = spec.marginMm * mm
        line.strokeWidth = 0.6f

        when (spec.template) {
            PageTemplate.BLANK -> Unit

            PageTemplate.LINED -> horizontalRules(canvas, w, h, margin, 7f * mm)
            PageTemplate.RULED -> {
                horizontalRules(canvas, w, h, margin, 8.7f * mm)
                line.strokeWidth = 0.9f
                canvas.drawLine(margin + 18f * mm, 0f, margin + 18f * mm, h, line)
            }

            PageTemplate.DOTTED -> {
                var y = margin + step
                while (y < h - margin) {
                    var x = margin + step
                    while (x < w - margin) { canvas.drawCircle(x, y, 0.75f, dot); x += step }
                    y += step
                }
            }

            PageTemplate.GRID -> grid(canvas, w, h, margin, step)

            PageTemplate.GRAPH -> {
                line.strokeWidth = 0.4f
                grid(canvas, w, h, margin, step)
                line.strokeWidth = 0.9f
                grid(canvas, w, h, margin, step * 5)
            }

            PageTemplate.CORNELL -> {
                val cue = w * 0.3f
                val summary = h * 0.82f
                horizontalRules(canvas, w, summary, margin, 8f * mm)
                line.strokeWidth = 1.1f
                canvas.drawLine(cue, 0f, cue, summary, line)
                canvas.drawLine(0f, summary, w, summary, line)
                label(canvas, "Cue", 6f * mm, 12f * mm, mm)
                label(canvas, "Notes", cue + 6f * mm, 12f * mm, mm)
                label(canvas, "Summary", 6f * mm, summary + 8f * mm, mm)
            }

            PageTemplate.PLANNER -> {
                val top = 24f * mm
                line.strokeWidth = 1.2f
                canvas.drawLine(0f, top, w, top, line)
                label(canvas, "Date", 8f * mm, 14f * mm, mm)
                label(canvas, "Priorities", w * 0.62f, 14f * mm, mm)
                line.strokeWidth = 1f
                canvas.drawLine(w * 0.6f, top, w * 0.6f, h, line)
                val rowH = 9.5f * mm
                var y = top + rowH
                var hour = 7
                while (y < h - 4f * mm) {
                    line.strokeWidth = 0.5f
                    canvas.drawLine(0f, y, w * 0.6f, y, line)
                    if (hour <= 22) label(canvas, "%02d:00".format(hour), 3f * mm, y - 2f * mm, mm, 7f)
                    hour++
                    y += rowH
                }
            }

            PageTemplate.TIMETABLE -> {
                val cols = 6 // time + Mon..Fri
                val rows = 11
                val cw = w / cols
                val ch = (h - 12f * mm) / rows
                line.strokeWidth = 0.6f
                for (c in 0..cols) canvas.drawLine(c * cw, 12f * mm, c * cw, h, line)
                for (r in 0..rows) canvas.drawLine(0f, 12f * mm + r * ch, w, 12f * mm + r * ch, line)
                val days = listOf("Time", "Mon", "Tue", "Wed", "Thu", "Fri")
                days.forEachIndexed { i, d -> label(canvas, d, i * cw + 3f * mm, 9f * mm, mm, 9f) }
            }

            PageTemplate.MUSIC -> {
                val staffGap = 1.8f * mm
                val systemGap = 16f * mm
                var y = 20f * mm
                line.strokeWidth = 0.5f
                while (y + staffGap * 4 < h - 10f * mm) {
                    for (i in 0 until 5) canvas.drawLine(10f * mm, y + i * staffGap, w - 10f * mm, y + i * staffGap, line)
                    y += systemGap
                }
            }

            PageTemplate.ENGINEERING -> {
                line.strokeWidth = 0.35f
                grid(canvas, w, h, margin, 2.5f * mm)
                line.strokeWidth = 0.8f
                grid(canvas, w, h, margin, 25f * mm)
                line.strokeWidth = 1.4f
                canvas.drawRect(12f * mm, 12f * mm, w - 12f * mm, h - 18f * mm, line)
                canvas.drawRect(w - 70f * mm, h - 18f * mm, w - 12f * mm, h - 4f * mm, line)
            }
        }

        if (spec.marginMm > 0f && spec.template != PageTemplate.BLANK) {
            line.strokeWidth = 0.8f
            canvas.drawRect(margin, margin, w - margin, h - margin, line)
        }
    }

    private fun grid(canvas: Canvas, w: Float, h: Float, margin: Float, step: Float) {
        var x = margin
        while (x <= w - margin + 0.01f) { canvas.drawLine(x, margin, x, h - margin, line); x += step }
        var y = margin
        while (y <= h - margin + 0.01f) { canvas.drawLine(margin, y, w - margin, y, line); y += step }
    }

    private fun horizontalRules(canvas: Canvas, w: Float, h: Float, margin: Float, step: Float) {
        var y = margin + step
        while (y < h - margin) { canvas.drawLine(margin, y, w - margin, y, line); y += step }
    }

    private fun label(canvas: Canvas, s: String, x: Float, y: Float, mm: Float, sizeMm: Float = 3.2f) {
        text.color = line.color
        text.textSize = sizeMm * mm / 2.6f * 2.6f * 0.9f
        canvas.drawText(s, x, y, text)
    }
}
