package app.noteflow.ui.onboarding

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.Brush
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.noteflow.NoteFlowApplication
import app.noteflow.data.settings.ThemeMode
import app.noteflow.ui.theme.Accents
import kotlinx.coroutines.launch

/**
 * First run. No account, no email, no permission prompts — just three choices that can all
 * be changed later in Settings. Finishing writes `first_run_done` to DataStore.
 */
@Composable
fun WelcomeScreen(onFinished: () -> Unit) {
    val context = LocalContext.current
    val container = (context.applicationContext as NoteFlowApplication).container
    val scope = rememberCoroutineScope()
    val settings by container.settings.settings.collectAsStateWithLifecycle(
        initialValue = app.noteflow.data.settings.AppSettings()
    )

    var accent by remember { mutableIntStateOf(0) }
    var theme by remember { mutableStateOf(ThemeMode.SYSTEM) }
    var pageSize by remember { mutableStateOf("A4") }

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(64.dp)
            ) {
                Icon(
                    Icons.Outlined.Brush, contentDescription = null,
                    modifier = Modifier.padding(16.dp),
                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }

            Text("Welcome to NoteFlow", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Write, draw and organise. Everything stays on this device.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            PromiseCard(Icons.Outlined.Lock, "No account, ever", "There is no sign-in screen, no subscription and no premium tier.")
            PromiseCard(Icons.Outlined.CloudOff, "Works offline", "The app has no internet permission at all, so notes cannot leave your phone.")
            PromiseCard(
                Icons.Outlined.Description,
                "Back up yourself",
                "On-device storage is not a backup. Use Settings → Backup to save a .noteflow.json file somewhere safe."
            )

            Text("Pick an accent", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Accents.forEachIndexed { index, palette ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = palette.primary,
                        modifier = Modifier
                            .size(40.dp)
                            .clickableAccent { accent = index }
                    ) {
                        if (accent == index) {
                            Icon(Icons.Filled.Check, null, tint = palette.onPrimary, modifier = Modifier.padding(8.dp))
                        }
                    }
                }
            }

            Text("Theme", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(
                        selected = theme == mode,
                        onClick = { theme = mode },
                        label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) }
                    )
                }
            }

            Text("Default page size", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("A4", "A5", "A6").forEach { size ->
                    FilterChip(selected = pageSize == size, onClick = { pageSize = size }, label = { Text(size) })
                }
            }

            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    scope.launch {
                        container.settings.setAccent(accent)
                        container.settings.setTheme(theme)
                        container.settings.setDefaultPage(pageSize, settings.defaultTemplateId, "PORTRAIT")
                        container.settings.setFirstRunDone()
                        onFinished()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Start writing") }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun PromiseCard(icon: ImageVector, title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

private fun Modifier.clickableAccent(onClick: () -> Unit): Modifier =
    this.then(Modifier.clickable { onClick() })
