package app.noteflow

import app.noteflow.domain.beautify.HandwritingRefiner
import app.noteflow.domain.model.InkBrush
import app.noteflow.domain.model.Stroke
import app.noteflow.ink.ShapeRecognizer
import app.noteflow.ink.StrokeSmoother
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.cos
import kotlin.math.sin

class InkToolsTest {

    private fun strokeOf(points: List<Pair<Float, Float>>, id: Long = 1): Stroke {
        val buffer = FloatArray(points.size * 4)
        points.forEachIndexed { i, (x, y) ->
            buffer[i * 4] = x; buffer[i * 4 + 1] = y; buffer[i * 4 + 2] = 1f; buffer[i * 4 + 3] = i.toFloat()
        }
        return Stroke(id, InkBrush(), buffer, points.size).also { it.recomputeBounds() }
    }

    @Test
    fun `resampling keeps the stroke within its original bounds`() {
        val pts = (0..40).map { it * 4f to (50f + 12f * sin(it / 3f)) }
        val s = strokeOf(pts)
        val (out, count) = StrokeSmoother.resampleCatmullRom(s.points, s.pointCount, spacing = 1f)
        assertTrue(count > s.pointCount)
        for (i in 0 until count) {
            assertTrue(out[i * 4] >= -5f && out[i * 4] <= 165f)
        }
    }

    @Test
    fun `a straight drag is recognised as a line`() {
        val s = strokeOf((0..30).map { it * 6f to 100f + (it % 2) * 0.4f })
        val result = ShapeRecognizer.recognize(s)
        assertNotNull(result)
        assertEquals(ShapeRecognizer.Shape.LINE, result!!.shape)
    }

    @Test
    fun `a rough circle is recognised as an ellipse`() {
        val pts = (0..60).map { i ->
            val t = i / 60f * 2f * Math.PI
            (200f + 80f * cos(t).toFloat() + (i % 3) * 0.6f) to (200f + 80f * sin(t).toFloat())
        }
        val result = ShapeRecognizer.recognize(strokeOf(pts))
        assertNotNull(result)
        assertEquals(ShapeRecognizer.Shape.ELLIPSE, result!!.shape)
    }

    @Test
    fun `handwriting-like scribbles are left alone`() {
        val pts = (0..40).map { i -> (i * 3f) to (100f + 18f * sin(i * 1.7f) + 9f * cos(i * 0.6f)) }
        assertNull(ShapeRecognizer.recognize(strokeOf(pts)))
    }

    @Test
    fun `refiner keeps stroke count and rough position`() {
        val words = (0..5).map { w ->
            strokeOf((0..20).map { i -> (w * 40f + i * 1.5f) to (100f + 10f * sin(i / 2f) + w) }, id = w.toLong())
        }
        val refined = HandwritingRefiner.refine(words, HandwritingRefiner.Options(neatness = 0.8f))
        assertEquals(words.size, refined.size)
        refined.forEachIndexed { index, stroke ->
            val original = words[index]
            assertTrue(
                "stroke must stay near its original place",
                kotlin.math.abs(stroke.minX - original.minX) < 25f
            )
        }
    }

    @Test
    fun `line grouping splits two written lines`() {
        val lineA = (0..4).map { strokeOf(listOf(it * 20f to 100f, it * 20f + 10f to 120f), id = it.toLong()) }
        val lineB = (0..4).map { strokeOf(listOf(it * 20f to 300f, it * 20f + 10f to 320f), id = 10L + it) }
        val groups = HandwritingRefiner.groupIntoLines(lineA + lineB)
        assertEquals(2, groups.size)
    }
}
