package app.noteflow.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Junction
import androidx.room.PrimaryKey
import androidx.room.Relation

/**
 * Room schema for NoteFlow (local-only, no server mirror).
 *
 * Design rules:
 *  - Ids are client generated UUID strings so backup/import never collides with auto ids.
 *  - Large binary payloads (ink, images, audio, PDF) are NOT stored in SQLite. The row only
 *    keeps a relative file name resolved by [app.noteflow.data.files.FileStore].
 *  - Soft delete: `deletedAt` != null means "in Recycle Bin". Nothing is hard deleted until
 *    the user empties the bin, so Restore is always possible.
 */

@Entity(
    tableName = "folders",
    indices = [Index("parentId"), Index("name")],
    foreignKeys = [
        ForeignKey(
            entity = FolderEntity::class,
            parentColumns = ["id"],
            childColumns = ["parentId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class FolderEntity(
    @PrimaryKey val id: String,
    val name: String,
    val parentId: String? = null,
    val colorArgb: Int? = null,
    val sortIndex: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

@Entity(
    tableName = "notes",
    indices = [Index("folderId"), Index("updatedAt"), Index("isPinned"), Index("deletedAt")],
    foreignKeys = [
        ForeignKey(
            entity = FolderEntity::class,
            parentColumns = ["id"],
            childColumns = ["folderId"],
            onDelete = ForeignKey.SET_NULL
        )
    ]
)
data class NoteEntity(
    @PrimaryKey val id: String,
    val title: String = "",
    /** Plain-text preview kept in the row so the home list never has to open page files. */
    val snippet: String = "",
    val folderId: String? = null,
    val isPinned: Boolean = false,
    val isFavorite: Boolean = false,
    val isArchived: Boolean = false,
    val accentArgb: Int? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val openedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

@Entity(tableName = "tags", indices = [Index(value = ["name"], unique = true)])
data class TagEntity(
    @PrimaryKey val id: String,
    val name: String,
    val colorArgb: Int? = null
)

@Entity(
    tableName = "note_tags",
    primaryKeys = ["noteId", "tagId"],
    indices = [Index("tagId")],
    foreignKeys = [
        ForeignKey(NoteEntity::class, ["id"], ["noteId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(TagEntity::class, ["id"], ["tagId"], onDelete = ForeignKey.CASCADE)
    ]
)
data class NoteTagCrossRef(val noteId: String, val tagId: String)

/** A page is one physical sheet (A2..A6) or one infinite-canvas surface. */
@Entity(
    tableName = "pages",
    indices = [Index("noteId"), Index(value = ["noteId", "pageIndex"])],
    foreignKeys = [
        ForeignKey(NoteEntity::class, ["id"], ["noteId"], onDelete = ForeignKey.CASCADE)
    ]
)
data class PageEntity(
    @PrimaryKey val id: String,
    val noteId: String,
    val pageIndex: Int,
    /** INK | TEXT | PDF — see app.noteflow.domain.model.PageKind */
    val kind: String = "INK",
    /** A2 | A3 | A4 | A5 | A6 | LETTER | INFINITE — see domain.model.PageSizePreset */
    val pageSizeId: String = "A4",
    /** PORTRAIT | LANDSCAPE */
    val orientation: String = "PORTRAIT",
    /** Real page size in PostScript points (1 pt = 1/72 inch). Used for exact PDF export. */
    val widthPt: Float = 595.28f,
    val heightPt: Float = 841.89f,
    /** BLANK | LINED | RULED | DOTTED | GRID | GRAPH | CORNELL | PLANNER | TIMETABLE | MUSIC | ENGINEERING */
    val templateId: String = "BLANK",
    val backgroundArgb: Int = 0xFFFFFFFF.toInt(),
    val lineArgb: Int = 0xFFBFD7D6.toInt(),
    val gridSpacingMm: Float = 5f,
    val marginMm: Float = 0f,
    /** Relative file name of the vector ink document, e.g. "notes/<noteId>/<pageId>.nfink". */
    val inkFile: String? = null,
    /** Rich-text payload for TEXT pages (JSON produced by domain.richtext). */
    val textJson: String? = null,
    /** Imported PDF attachment id + page index for PDF pages. */
    val pdfAttachmentId: String? = null,
    val pdfPageIndex: Int = 0,
    // Persisted viewport so reopening a page restores the user's position.
    val viewZoom: Float = 1f,
    val viewPanX: Float = 0f,
    val viewPanY: Float = 0f,
    val zoomLocked: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

/** Images, audio recordings and imported PDFs linked to a note. Bytes live on disk. */
@Entity(
    tableName = "attachments",
    indices = [Index("noteId")],
    foreignKeys = [
        ForeignKey(NoteEntity::class, ["id"], ["noteId"], onDelete = ForeignKey.CASCADE)
    ]
)
data class AttachmentEntity(
    @PrimaryKey val id: String,
    val noteId: String,
    /** IMAGE | AUDIO | PDF */
    val kind: String,
    val displayName: String,
    val relativePath: String,
    val mimeType: String,
    val sizeBytes: Long,
    val durationMs: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

/** Reusable page presets: the built-in ones are seeded, users can save their own. */
@Entity(tableName = "template_presets")
data class TemplatePresetEntity(
    @PrimaryKey val id: String,
    val name: String,
    val builtIn: Boolean,
    val templateId: String,
    val pageSizeId: String,
    val orientation: String,
    val backgroundArgb: Int,
    val lineArgb: Int,
    val gridSpacingMm: Float,
    val marginMm: Float,
    val sortIndex: Int = 0
)

/** Relation helper used by the home screen so tags come back with each note in one query. */
data class NoteWithTags(
    @androidx.room.Embedded val note: NoteEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "id",
        associateBy = Junction(NoteTagCrossRef::class, parentColumn = "noteId", entityColumn = "tagId")
    )
    val tags: List<TagEntity>
)
