package app.noteflow.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.noteflow.data.settings.ThemeMode

/**
 * NoteFlow visual identity — original, not a copy of any shipping product.
 * Compact type scale, generous touch targets, teal "ink" accent by default,
 * plus five alternative accents the user can pick in Settings.
 */
data class AccentPalette(val name: String, val primary: Color, val onPrimary: Color, val container: Color)

val Accents = listOf(
    AccentPalette("Ink Teal", Color(0xFF0E7C7B), Color.White, Color(0xFFD2F1EF)),
    AccentPalette("Indigo", Color(0xFF4A54C7), Color.White, Color(0xFFDFE1FF)),
    AccentPalette("Graphite", Color(0xFF3F4A52), Color.White, Color(0xFFDDE3E7)),
    AccentPalette("Amber", Color(0xFFB4690E), Color.White, Color(0xFFFFE2B8)),
    AccentPalette("Rose", Color(0xFFB03A62), Color.White, Color(0xFFFFD9E3)),
    AccentPalette("Forest", Color(0xFF2E6B3E), Color.White, Color(0xFFD3EEDA))
)

private fun lightScheme(a: AccentPalette) = lightColorScheme(
    primary = a.primary,
    onPrimary = a.onPrimary,
    primaryContainer = a.container,
    onPrimaryContainer = Color(0xFF07211F),
    secondary = Color(0xFF50635F),
    background = Color(0xFFFBFAF7),
    onBackground = Color(0xFF14181A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF14181A),
    surfaceVariant = Color(0xFFEFF1EE),
    onSurfaceVariant = Color(0xFF4A5255),
    outline = Color(0xFFBFC6C4),
    error = Color(0xFFB3261E)
)

private fun darkScheme(a: AccentPalette) = darkColorScheme(
    primary = Color(
        red = (a.primary.red + 0.25f).coerceAtMost(1f),
        green = (a.primary.green + 0.25f).coerceAtMost(1f),
        blue = (a.primary.blue + 0.25f).coerceAtMost(1f)
    ),
    onPrimary = Color(0xFF05201F),
    primaryContainer = Color(0xFF17403F),
    onPrimaryContainer = Color(0xFFCFEFEC),
    secondary = Color(0xFFA9C7C2),
    background = Color(0xFF111312),
    onBackground = Color(0xFFE6E9E8),
    surface = Color(0xFF191C1C),
    onSurface = Color(0xFFE6E9E8),
    surfaceVariant = Color(0xFF262B2B),
    onSurfaceVariant = Color(0xFFBFC8C6),
    outline = Color(0xFF4C5553),
    error = Color(0xFFF2B8B5)
)

private val NoteFlowTypography = Typography(
    headlineSmall = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.2).sp),
    titleLarge = TextStyle(fontSize = 19.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium),
    bodyLarge = TextStyle(fontSize = 15.sp, lineHeight = 21.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 19.sp),
    labelLarge = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium)
)

/** Accessible minimum touch target; grows when the user enables "Larger controls". */
val TouchTargetDefault = 48.dp
val TouchTargetLarge = 56.dp

@Composable
fun NoteFlowTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    accentIndex: Int = 0,
    content: @Composable () -> Unit
) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val accent = Accents.getOrElse(accentIndex) { Accents.first() }
    MaterialTheme(
        colorScheme = if (dark) darkScheme(accent) else lightScheme(accent),
        typography = NoteFlowTypography,
        content = content
    )
}
