package app.noteflow.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import androidx.room.Upsert
import app.noteflow.data.local.entity.NoteEntity
import app.noteflow.data.local.entity.NoteTagCrossRef
import app.noteflow.data.local.entity.NoteWithTags
import app.noteflow.data.local.entity.TagEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {

    @Upsert
    suspend fun upsert(note: NoteEntity)

    @Update
    suspend fun update(note: NoteEntity)

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun findById(id: String): NoteEntity?

    @Query("SELECT * FROM notes WHERE id = :id")
    fun observe(id: String): Flow<NoteEntity?>

    /**
     * Single query that powers the whole home screen.
     * Sorting is resolved in SQL to keep large libraries fast:
     *  0 = updated desc, 1 = created desc, 2 = title asc, 3 = title desc, 4 = opened desc
     */
    @Transaction
    @Query(
        """
        SELECT * FROM notes
        WHERE deletedAt IS NULL
          AND isArchived = :archived
          AND (:folderId IS NULL OR folderId = :folderId)
          AND (:onlyFavorites = 0 OR isFavorite = 1)
          AND (:query = '' OR title LIKE '%' || :query || '%' OR snippet LIKE '%' || :query || '%')
        ORDER BY
          isPinned DESC,
          CASE WHEN :sort = 0 THEN updatedAt END DESC,
          CASE WHEN :sort = 1 THEN createdAt END DESC,
          CASE WHEN :sort = 2 THEN LOWER(title) END ASC,
          CASE WHEN :sort = 3 THEN LOWER(title) END DESC,
          CASE WHEN :sort = 4 THEN openedAt END DESC,
          updatedAt DESC
        """
    )
    fun observeLibrary(
        folderId: String?,
        query: String,
        sort: Int,
        archived: Boolean,
        onlyFavorites: Boolean
    ): Flow<List<NoteWithTags>>

    @Transaction
    @Query("SELECT * FROM notes WHERE deletedAt IS NOT NULL ORDER BY deletedAt DESC")
    fun observeRecycleBin(): Flow<List<NoteWithTags>>

    @Transaction
    @Query("SELECT * FROM notes WHERE deletedAt IS NULL ORDER BY openedAt DESC LIMIT :limit")
    fun observeRecent(limit: Int = 8): Flow<List<NoteWithTags>>

    @Query("UPDATE notes SET isPinned = :pinned, updatedAt = :now WHERE id = :id")
    suspend fun setPinned(id: String, pinned: Boolean, now: Long = System.currentTimeMillis())

    @Query("UPDATE notes SET isFavorite = :favorite, updatedAt = :now WHERE id = :id")
    suspend fun setFavorite(id: String, favorite: Boolean, now: Long = System.currentTimeMillis())

    @Query("UPDATE notes SET isArchived = :archived, updatedAt = :now WHERE id = :id")
    suspend fun setArchived(id: String, archived: Boolean, now: Long = System.currentTimeMillis())

    @Query("UPDATE notes SET folderId = :folderId, updatedAt = :now WHERE id = :id")
    suspend fun move(id: String, folderId: String?, now: Long = System.currentTimeMillis())

    @Query("UPDATE notes SET title = :title, updatedAt = :now WHERE id = :id")
    suspend fun rename(id: String, title: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE notes SET deletedAt = :now WHERE id = :id")
    suspend fun moveToBin(id: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE notes SET deletedAt = NULL, updatedAt = :now WHERE id = :id")
    suspend fun restore(id: String, now: Long = System.currentTimeMillis())

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun hardDelete(id: String)

    @Query("DELETE FROM notes WHERE deletedAt IS NOT NULL")
    suspend fun emptyBin()

    @Query("SELECT id FROM notes WHERE deletedAt IS NOT NULL")
    suspend fun binIds(): List<String>

    @Query("UPDATE notes SET openedAt = :now WHERE id = :id")
    suspend fun touchOpened(id: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE notes SET snippet = :snippet, updatedAt = :now WHERE id = :id")
    suspend fun updateSnippet(id: String, snippet: String, now: Long = System.currentTimeMillis())

    @Query("SELECT * FROM notes")
    suspend fun allForBackup(): List<NoteEntity>

    // --- tags ---

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertTag(tag: TagEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun link(ref: NoteTagCrossRef)

    @Query("DELETE FROM note_tags WHERE noteId = :noteId AND tagId = :tagId")
    suspend fun unlink(noteId: String, tagId: String)

    @Query("SELECT * FROM tags ORDER BY LOWER(name) ASC")
    fun observeTags(): Flow<List<TagEntity>>

    @Query("SELECT * FROM tags")
    suspend fun allTagsForBackup(): List<TagEntity>

    @Query("SELECT * FROM note_tags")
    suspend fun allTagLinksForBackup(): List<NoteTagCrossRef>

    @Query("SELECT name FROM tags WHERE id = :id")
    suspend fun tagName(id: String): String?

    @Transaction
    @Query(
        """
        SELECT notes.* FROM notes
        INNER JOIN note_tags ON notes.id = note_tags.noteId
        WHERE note_tags.tagId = :tagId AND notes.deletedAt IS NULL
        ORDER BY notes.isPinned DESC, notes.updatedAt DESC
        """
    )
    fun observeByTag(tagId: String): Flow<List<NoteWithTags>>
}
