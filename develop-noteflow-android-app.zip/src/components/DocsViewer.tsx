import { useMemo, useState } from "react";
import { sourceFiles } from "../data/sources";
import { renderMarkdown } from "../lib/markdown";
import { cn } from "../utils/cn";

const docOrder = [
  { path: "android/README.md", label: "Read me & install" },
  { path: "docs/ARCHITECTURE.md", label: "Architecture" },
  { path: "docs/ROADMAP.md", label: "Roadmap" },
  { path: "docs/TESTING.md", label: "Testing" },
  { path: "docs/LICENSES.md", label: "Licences" },
];

export default function DocsViewer() {
  const docs = useMemo(
    () =>
      docOrder
        .map((entry) => ({ ...entry, file: sourceFiles.find((f) => f.path === entry.path) }))
        .filter((entry) => entry.file),
    [],
  );
  const [active, setActive] = useState(docs[0]?.path ?? "");
  const current = docs.find((d) => d.path === active);

  return (
    <div>
      <div className="mb-5 flex flex-wrap gap-2">
        {docs.map((doc) => (
          <button
            key={doc.path}
            onClick={() => setActive(doc.path)}
            className={cn(
              "rounded-full border px-4 py-1.5 text-sm transition",
              doc.path === active
                ? "border-teal-400/60 bg-teal-500/15 text-teal-200"
                : "border-slate-700 text-slate-400 hover:border-slate-500 hover:text-slate-200",
            )}
          >
            {doc.label}
          </button>
        ))}
      </div>
      <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-6 md:p-8">
        {current?.file ? (
          <div
            className="text-[15px]"
            dangerouslySetInnerHTML={{ __html: renderMarkdown(current.file.content) }}
          />
        ) : (
          <p className="text-slate-500">Document not found.</p>
        )}
      </div>
    </div>
  );
}
