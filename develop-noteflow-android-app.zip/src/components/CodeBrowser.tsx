import { useMemo, useState } from "react";
import { groups, sourceFiles, type SourceFile } from "../data/sources";
import { cn } from "../utils/cn";

function Highlighted({ file }: { file: SourceFile }) {
  const lines = file.content.split("\n");
  return (
    <pre className="min-w-full overflow-x-auto px-4 py-4 text-[12.5px] leading-[1.65]">
      <code>
        {lines.map((line, index) => (
          <div key={index} className="grid grid-cols-[3.2rem_1fr] hover:bg-slate-800/30">
            <span className="select-none pr-4 text-right text-slate-600">{index + 1}</span>
            <span className={cn("whitespace-pre text-slate-300", commentClass(line))}>{line || " "}</span>
          </div>
        ))}
      </code>
    </pre>
  );
}

function commentClass(line: string) {
  const trimmed = line.trim();
  if (trimmed.startsWith("//") || trimmed.startsWith("*") || trimmed.startsWith("/*") || trimmed.startsWith("#")) {
    return "text-slate-500 italic";
  }
  if (trimmed.startsWith("@") || trimmed.startsWith("<!--")) return "text-teal-300/80";
  return "";
}

export default function CodeBrowser() {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(
    sourceFiles.find((f) => f.path.endsWith("ink/InkCanvasView.kt"))?.path ?? sourceFiles[0]?.path,
  );
  const [copied, setCopied] = useState(false);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return sourceFiles;
    return sourceFiles.filter(
      (f) => f.path.toLowerCase().includes(q) || f.content.toLowerCase().includes(q),
    );
  }, [query]);

  const current = sourceFiles.find((f) => f.path === selected);

  const copy = async () => {
    if (!current) return;
    try {
      await navigator.clipboard.writeText(current.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[320px_1fr]">
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60">
        <div className="border-b border-slate-800 p-3">
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search file names and code…"
            className="w-full rounded-lg border border-slate-700 bg-slate-950/60 px-3 py-2 text-sm text-slate-200 outline-none placeholder:text-slate-600 focus:border-teal-500"
          />
          <p className="mt-2 text-xs text-slate-500">
            {filtered.length} of {sourceFiles.length} files
          </p>
        </div>
        <div className="max-h-[560px] overflow-y-auto p-2">
          {groups.map((group) => {
            const items = filtered.filter((f) => f.group === group);
            if (items.length === 0) return null;
            return (
              <div key={group} className="mb-3">
                <p className="px-2 py-1 text-[11px] font-semibold uppercase tracking-wider text-teal-400/80">
                  {group}
                </p>
                {items.map((file) => (
                  <button
                    key={file.path}
                    onClick={() => setSelected(file.path)}
                    className={cn(
                      "block w-full truncate rounded-lg px-2 py-1.5 text-left text-[13px] transition",
                      file.path === selected
                        ? "bg-teal-500/15 text-teal-200"
                        : "text-slate-400 hover:bg-slate-800/60 hover:text-slate-200",
                    )}
                    title={file.path}
                  >
                    {file.name}
                    <span className="ml-2 text-[11px] text-slate-600">{file.lines} ln</span>
                  </button>
                ))}
              </div>
            );
          })}
        </div>
      </div>

      <div className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-950/70">
        {current ? (
          <>
            <div className="flex flex-wrap items-center gap-3 border-b border-slate-800 bg-slate-900/70 px-4 py-3">
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-slate-200">{current.path}</p>
                <p className="text-xs text-slate-500">
                  {current.language} · {current.lines} lines · {(current.bytes / 1024).toFixed(1)} KB
                </p>
              </div>
              <button
                onClick={copy}
                className="rounded-lg border border-slate-700 px-3 py-1.5 text-xs text-slate-300 transition hover:border-teal-500 hover:text-teal-200"
              >
                {copied ? "Copied" : "Copy file"}
              </button>
            </div>
            <div className="max-h-[560px] overflow-auto">
              <Highlighted file={current} />
            </div>
          </>
        ) : (
          <p className="p-6 text-sm text-slate-500">Select a file.</p>
        )}
      </div>
    </div>
  );
}
