/**
 * Deliberately tiny Markdown → HTML renderer: just enough for the project docs
 * (headings, lists, tables, fenced code, inline code, bold, links, rules).
 * Input is our own repository content, and all HTML is escaped before formatting.
 */
function escapeHtml(input: string): string {
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function inline(text: string): string {
  return escapeHtml(text)
    .replace(/`([^`]+)`/g, '<code class="rounded bg-slate-800/80 px-1.5 py-0.5 text-[0.85em] text-teal-200">$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong class="font-semibold text-slate-100">$1</strong>')
    .replace(/\*([^*]+)\*/g, '<em class="italic">$1</em>')
    .replace(
      /\[([^\]]+)\]\(([^)]+)\)/g,
      '<a class="text-teal-300 underline underline-offset-2" href="$2">$1</a>',
    );
}

export function renderMarkdown(markdown: string): string {
  const lines = markdown.split("\n");
  const out: string[] = [];
  let i = 0;
  let inList = false;
  let inOrdered = false;

  const closeLists = () => {
    if (inList) {
      out.push("</ul>");
      inList = false;
    }
    if (inOrdered) {
      out.push("</ol>");
      inOrdered = false;
    }
  };

  while (i < lines.length) {
    const line = lines[i];

    if (line.startsWith("```")) {
      closeLists();
      const body: string[] = [];
      i++;
      while (i < lines.length && !lines[i].startsWith("```")) {
        body.push(lines[i]);
        i++;
      }
      i++;
      out.push(
        `<pre class="my-4 overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/80 p-4 text-[12.5px] leading-relaxed text-slate-300"><code>${escapeHtml(
          body.join("\n"),
        )}</code></pre>`,
      );
      continue;
    }

    if (/^\|(.+)\|$/.test(line.trim()) && i + 1 < lines.length && /^\|[\s:|-]+\|$/.test(lines[i + 1].trim())) {
      closeLists();
      const header = line.trim().slice(1, -1).split("|");
      i += 2;
      const rows: string[][] = [];
      while (i < lines.length && /^\|(.*)\|$/.test(lines[i].trim())) {
        rows.push(lines[i].trim().slice(1, -1).split("|"));
        i++;
      }
      out.push(
        `<div class="my-4 overflow-x-auto"><table class="w-full border-collapse text-left text-sm"><thead><tr>${header
          .map(
            (h) =>
              `<th class="border-b border-slate-700 px-3 py-2 font-semibold text-slate-200">${inline(h.trim())}</th>`,
          )
          .join("")}</tr></thead><tbody>${rows
          .map(
            (r) =>
              `<tr class="align-top">${r
                .map(
                  (c) =>
                    `<td class="border-b border-slate-800/70 px-3 py-2 text-slate-400">${inline(c.trim())}</td>`,
                )
                .join("")}</tr>`,
          )
          .join("")}</tbody></table></div>`,
      );
      continue;
    }

    const heading = /^(#{1,6})\s+(.*)$/.exec(line);
    if (heading) {
      closeLists();
      const level = heading[1].length;
      const sizes: Record<number, string> = {
        1: "mt-2 mb-3 text-2xl font-semibold text-white",
        2: "mt-7 mb-3 text-xl font-semibold text-white",
        3: "mt-6 mb-2 text-lg font-semibold text-slate-100",
        4: "mt-5 mb-2 text-base font-semibold text-slate-200",
        5: "mt-4 mb-2 text-sm font-semibold text-slate-200",
        6: "mt-4 mb-2 text-sm font-semibold text-slate-300",
      };
      out.push(`<h${level} class="${sizes[level]}">${inline(heading[2])}</h${level}>`);
      i++;
      continue;
    }

    if (/^(-{3,}|\*{3,})$/.test(line.trim())) {
      closeLists();
      out.push('<hr class="my-6 border-slate-800" />');
      i++;
      continue;
    }

    const bullet = /^\s*[-*]\s+(.*)$/.exec(line);
    if (bullet) {
      if (inOrdered) {
        out.push("</ol>");
        inOrdered = false;
      }
      if (!inList) {
        out.push('<ul class="my-3 ml-5 list-disc space-y-1.5 text-slate-400">');
        inList = true;
      }
      out.push(`<li>${inline(bullet[1])}</li>`);
      i++;
      continue;
    }

    const ordered = /^\s*(\d+)\.\s+(.*)$/.exec(line);
    if (ordered) {
      if (inList) {
        out.push("</ul>");
        inList = false;
      }
      if (!inOrdered) {
        out.push('<ol class="my-3 ml-5 list-decimal space-y-1.5 text-slate-400">');
        inOrdered = true;
      }
      out.push(`<li>${inline(ordered[2])}</li>`);
      i++;
      continue;
    }

    if (line.trim() === "") {
      closeLists();
      i++;
      continue;
    }

    closeLists();
    out.push(`<p class="my-3 leading-relaxed text-slate-400">${inline(line)}</p>`);
    i++;
  }

  closeLists();
  return out.join("\n");
}
