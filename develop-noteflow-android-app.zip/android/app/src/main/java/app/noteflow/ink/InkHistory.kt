package app.noteflow.ink

import app.noteflow.domain.model.InkDocument
import app.noteflow.domain.model.Stroke

/**
 * Undo / redo for ink editing, implemented as reversible commands rather than page
 * snapshots (snapshots of a dense page would cost megabytes per step).
 *
 * Capacity is bounded so a long study session cannot grow without limit.
 */
class InkHistory(private val capacity: Int = 120) {

    sealed interface Command {
        fun apply(doc: InkDocument)
        fun revert(doc: InkDocument)
    }

    class AddStrokes(private val strokes: List<Stroke>) : Command {
        override fun apply(doc: InkDocument) = strokes.forEach { doc.add(it) }
        override fun revert(doc: InkDocument) { strokes.forEach { doc.remove(it.id) } }
    }

    class RemoveStrokes(private val removed: List<Pair<Int, Stroke>>) : Command {
        override fun apply(doc: InkDocument) { removed.sortedByDescending { it.first }.forEach { doc.remove(it.second.id) } }
        override fun revert(doc: InkDocument) {
            removed.sortedBy { it.first }.forEach { (index, stroke) ->
                doc.strokes.add(index.coerceIn(0, doc.strokes.size), stroke)
            }
        }
    }

    /** Lasso move/resize/rotate, shape recognition replacement, beautification. */
    class ReplaceStrokes(
        private val before: List<Pair<Int, Stroke>>,
        private val after: List<Stroke>
    ) : Command {
        override fun apply(doc: InkDocument) {
            before.forEach { doc.remove(it.second.id) }
            after.forEach { doc.add(it) }
        }
        override fun revert(doc: InkDocument) {
            after.forEach { doc.remove(it.id) }
            before.sortedBy { it.first }.forEach { (index, stroke) ->
                doc.strokes.add(index.coerceIn(0, doc.strokes.size), stroke)
            }
        }
    }

    private val undoStack = ArrayDeque<Command>()
    private val redoStack = ArrayDeque<Command>()

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    fun push(command: Command) {
        undoStack.addLast(command)
        if (undoStack.size > capacity) undoStack.removeFirst()
        redoStack.clear()
    }

    fun undo(doc: InkDocument): Boolean {
        val c = undoStack.removeLastOrNull() ?: return false
        c.revert(doc)
        redoStack.addLast(c)
        return true
    }

    fun redo(doc: InkDocument): Boolean {
        val c = redoStack.removeLastOrNull() ?: return false
        c.apply(doc)
        undoStack.addLast(c)
        return true
    }

    fun clear() { undoStack.clear(); redoStack.clear() }
}
