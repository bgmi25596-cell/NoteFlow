# Dependencies and licences

Everything NoteFlow uses is either part of the Android platform or a permissively
licensed open-source library. No proprietary binaries, no paid services, no usage caps.

| Dependency | Version | Licence | Why |
|---|---|---|---|
| Android SDK / platform APIs (`Canvas`, `MotionEvent`, `android.graphics.pdf.PdfDocument`) | compileSdk 34 | Android Software Development Kit Licence | Ink rendering, input, PDF export |
| androidx.core:core-ktx | 1.13.1 | Apache-2.0 | Kotlin extensions |
| androidx.activity:activity-compose | 1.9.2 | Apache-2.0 | Compose host activity, result APIs |
| androidx.lifecycle (runtime-compose, viewmodel-compose) | 2.8.6 | Apache-2.0 | State collection, ViewModels |
| androidx.navigation:navigation-compose | 2.8.2 | Apache-2.0 | Screen navigation |
| androidx.compose BOM + ui/material3/icons | 2024.09.03 | Apache-2.0 | All UI |
| androidx.compose.material3:material3-window-size-class | BOM | Apache-2.0 | Phone/tablet layouts |
| androidx.window:window | 1.3.0 | Apache-2.0 | Window metrics |
| androidx.room (runtime, ktx, compiler) | 2.6.1 | Apache-2.0 | SQLite persistence + migrations |
| androidx.datastore:datastore-preferences | 1.1.1 | Apache-2.0 | Settings |
| androidx.documentfile | 1.0.1 | Apache-2.0 | Storage Access Framework helpers |
| org.jetbrains.kotlinx:kotlinx-serialization-json | 1.7.3 | Apache-2.0 | Backup file format |
| org.jetbrains.kotlinx:kotlinx-coroutines-android | 1.8.1 | Apache-2.0 | Async work |
| com.google.devtools.ksp | 2.0.21-1.0.25 | Apache-2.0 | Room code generation |
| com.android.tools:desugar_jdk_libs | 2.0.4 | GPL-2.0 **with Classpath Exception** (safe for app distribution, used by Google's own toolchain) | Java 8+ APIs on older devices |
| JUnit 4 | 4.13.2 | EPL-1.0 (test only, not shipped) | Unit tests |
| androidx.test / room-testing / compose ui-test | current | Apache-2.0 (test only) | Instrumented tests |

## Deliberately NOT used

* **PdfBox-Android / iText** — PdfBox-Android is Apache-2.0 and would be acceptable for
  PDF *import*, but it adds ~10 MB and is only needed in Phase 4; iText is AGPL/commercial
  and is therefore excluded. Phase 4 will use the platform `PdfRenderer` for rendering
  imported PDFs first, and only add PdfBox-Android if annotation export demands it.
* **Any cloud AI API** (OpenAI, Gemini, etc.) — would require keys, money and the INTERNET
  permission. Excluded by design.
* **Pretrained handwriting-synthesis weights** — the research checkpoints found are either
  non-commercial, unlicensed, or far too large/slow for a phone. Nothing is bundled, and
  the app does not pretend to run a model. See `android/app/src/main/java/app/noteflow/domain/beautify/HandwritingRefiner.kt`.
* **Analytics / crash SDKs** — none. The app cannot reach the network.

## Project licence

The NoteFlow source in this repository is original work and is released under the
MIT licence (see `LICENSE`). It contains no decompiled, leaked or proprietary code, and
no third-party trademarks or assets. The launcher icon is an original vector drawn in
`res/drawable/ic_launcher_foreground.xml`.
