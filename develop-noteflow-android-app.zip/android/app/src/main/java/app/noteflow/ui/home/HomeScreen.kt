package app.noteflow.ui.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.CreateNewFolder
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Notes
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Sort
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PermanentDrawerSheet
import androidx.compose.material3.PermanentNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.noteflow.data.local.entity.NoteWithTags
import app.noteflow.data.repository.NoteSort
import app.noteflow.ui.theme.TouchTargetDefault
import app.noteflow.ui.theme.TouchTargetLarge
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

/**
 * Notes home: search, folders (with subfolders), pinned + recent sections, tags, sorting,
 * archive and recycle bin. Phone uses a modal drawer, tablet/landscape keeps the folder
 * rail permanently open.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    expanded: Boolean,
    largeTargets: Boolean,
    onOpenNote: (String) -> Unit,
    onOpenSettings: () -> Unit
) {
    val filter by viewModel.filter.collectAsStateWithLifecycle()
    val notes by viewModel.notes.collectAsStateWithLifecycle()
    val folders by viewModel.folders.collectAsStateWithLifecycle()
    val counts by viewModel.folderCounts.collectAsStateWithLifecycle()
    val tags by viewModel.tags.collectAsStateWithLifecycle()

    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showNewFolder by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<Pair<String, String>?>(null) }
    var confirmEmptyBin by remember { mutableStateOf(false) }

    val drawerContent: @Composable () -> Unit = {
        FolderRail(
            folders = folders.map { it to (counts[it.id] ?: 0) },
            selectedFolderId = filter.folderId,
            showingArchive = filter.archived,
            showingBin = filter.showBin,
            favoritesOnly = filter.favoritesOnly,
            onSelectAll = { viewModel.setFolder(null); viewModel.setFavoritesOnly(false) },
            onSelectFavorites = { viewModel.setFavoritesOnly(true) },
            onSelectFolder = { viewModel.setFolder(it) },
            onSelectArchive = { viewModel.setArchived(true) },
            onSelectBin = { viewModel.setShowBin(true) },
            onNewFolder = { showNewFolder = true },
            onRenameFolder = { id, name -> renameTarget = id to name },
            onDeleteFolder = { viewModel.deleteFolder(it) },
            onSettings = onOpenSettings,
            closeDrawer = { scope.launch { drawerState.close() } }
        )
    }

    val body: @Composable () -> Unit = {
        Scaffold(
            topBar = {
                Column {
                    TopAppBar(
                        title = {
                            Text(
                                when {
                                    filter.showBin -> "Recycle bin"
                                    filter.archived -> "Archive"
                                    filter.favoritesOnly -> "Favourites"
                                    filter.tagId != null -> "#" + (tags.firstOrNull { it.id == filter.tagId }?.name ?: "tag")
                                    filter.folderId != null -> folders.firstOrNull { it.id == filter.folderId }?.name ?: "Folder"
                                    else -> "NoteFlow"
                                }
                            )
                        },
                        navigationIcon = {
                            if (!expanded) {
                                IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                    Icon(Icons.Outlined.Folder, contentDescription = "Folders")
                                }
                            }
                        },
                        actions = {
                            SortMenu(current = filter.sort, onSelect = viewModel::setSort)
                            if (filter.showBin && notes.isNotEmpty()) {
                                IconButton(onClick = { confirmEmptyBin = true }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Empty bin")
                                }
                            }
                            IconButton(onClick = onOpenSettings) {
                                Icon(Icons.Outlined.Settings, contentDescription = "Settings")
                            }
                        }
                    )
                    OutlinedTextField(
                        value = filter.query,
                        onValueChange = viewModel::setQuery,
                        placeholder = { Text("Search notes") },
                        leadingIcon = { Icon(Icons.Filled.Search, null) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                    if (tags.isNotEmpty()) {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 6.dp)
                        ) {
                            item {
                                FilterChip(
                                    selected = filter.tagId == null,
                                    onClick = { viewModel.setTag(null) },
                                    label = { Text("All") }
                                )
                            }
                            items(tags.size) { index ->
                                val tag = tags[index]
                                FilterChip(
                                    selected = filter.tagId == tag.id,
                                    onClick = { viewModel.setTag(if (filter.tagId == tag.id) null else tag.id) },
                                    label = { Text("#${tag.name}") }
                                )
                            }
                        }
                    }
                }
            },
            floatingActionButton = {
                if (!filter.showBin) {
                    ExtendedFloatingActionButton(
                        onClick = { viewModel.createNote { onOpenNote(it) } },
                        icon = { Icon(Icons.Filled.Add, null) },
                        text = { Text("New note") }
                    )
                }
            }
        ) { padding ->
            if (notes.isEmpty()) {
                EmptyState(filter, Modifier.padding(padding))
            } else {
                val pinned = notes.filter { it.note.isPinned }
                val others = notes.filterNot { it.note.isPinned }
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(if (expanded) 260.dp else 180.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (pinned.isNotEmpty()) {
                        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                            SectionHeader("Pinned")
                        }
                        items(pinned) { item ->
                            NoteCard(item, largeTargets, filter.showBin, viewModel, onOpenNote) { id, name -> renameTarget = id to name }
                        }
                        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                            SectionHeader("All notes")
                        }
                    }
                    items(others) { item ->
                        NoteCard(item, largeTargets, filter.showBin, viewModel, onOpenNote) { id, name -> renameTarget = id to name }
                    }
                }
            }
        }
    }

    if (expanded) {
        PermanentNavigationDrawer(
            drawerContent = { PermanentDrawerSheet(Modifier.width(280.dp)) { drawerContent() } },
            content = { body() }
        )
    } else {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = { ModalDrawerSheet { drawerContent() } },
            content = { body() }
        )
    }

    if (showNewFolder) {
        TextPromptDialog(
            title = "New folder",
            initial = "",
            confirmLabel = "Create",
            onDismiss = { showNewFolder = false },
            onConfirm = { viewModel.createFolder(it, filter.folderId); showNewFolder = false }
        )
    }

    renameTarget?.let { (id, current) ->
        TextPromptDialog(
            title = "Rename",
            initial = current,
            confirmLabel = "Save",
            onDismiss = { renameTarget = null },
            onConfirm = { newName ->
                if (folders.any { it.id == id }) viewModel.renameFolder(id, newName) else viewModel.rename(id, newName)
                renameTarget = null
            }
        )
    }

    if (confirmEmptyBin) {
        AlertDialog(
            onDismissRequest = { confirmEmptyBin = false },
            title = { Text("Empty recycle bin?") },
            text = { Text("All notes in the bin and their handwriting files will be permanently deleted from this device. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = { viewModel.emptyBin(); confirmEmptyBin = false }) { Text("Delete permanently") }
            },
            dismissButton = { TextButton(onClick = { confirmEmptyBin = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NoteCard(
    item: NoteWithTags,
    largeTargets: Boolean,
    inBin: Boolean,
    viewModel: HomeViewModel,
    onOpen: (String) -> Unit,
    onRename: (String, String) -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    val note = item.note
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 132.dp)
            .clickable(enabled = !inBin) { onOpen(note.id) }
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Text(
                    note.title.ifBlank { "Untitled note" },
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Box {
                    IconButton(
                        onClick = { menu = true },
                        modifier = Modifier.size(if (largeTargets) TouchTargetLarge else TouchTargetDefault)
                    ) { Icon(Icons.Filled.MoreVert, contentDescription = "Note options") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        if (inBin) {
                            DropdownMenuItem(text = { Text("Restore") }, onClick = { viewModel.restore(note.id); menu = false })
                            DropdownMenuItem(text = { Text("Delete permanently") }, onClick = { viewModel.deleteForever(note.id); menu = false })
                        } else {
                            DropdownMenuItem(text = { Text("Rename") }, onClick = { onRename(note.id, note.title); menu = false })
                            DropdownMenuItem(text = { Text(if (note.isPinned) "Unpin" else "Pin") }, onClick = { viewModel.pin(note.id, !note.isPinned); menu = false })
                            DropdownMenuItem(text = { Text(if (note.isFavorite) "Remove favourite" else "Add to favourites") }, onClick = { viewModel.favorite(note.id, !note.isFavorite); menu = false })
                            DropdownMenuItem(text = { Text("Duplicate") }, onClick = { viewModel.duplicate(note.id); menu = false })
                            DropdownMenuItem(text = { Text(if (note.isArchived) "Unarchive" else "Archive") }, onClick = { viewModel.archive(note.id, !note.isArchived); menu = false })
                            HorizontalDivider()
                            DropdownMenuItem(text = { Text("Move to bin") }, onClick = { viewModel.delete(note.id); menu = false })
                        }
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                note.snippet.ifBlank { "Empty page" },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false)
            )
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(note.updatedAt)),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.weight(1f))
                if (note.isFavorite) Icon(Icons.Filled.Star, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                if (note.isPinned) Icon(Icons.Outlined.PushPin, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
            }
            if (item.tags.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    item.tags.joinToString(" ") { "#${it.name}" },
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun FolderRail(
    folders: List<Pair<app.noteflow.data.local.entity.FolderEntity, Int>>,
    selectedFolderId: String?,
    showingArchive: Boolean,
    showingBin: Boolean,
    favoritesOnly: Boolean,
    onSelectAll: () -> Unit,
    onSelectFavorites: () -> Unit,
    onSelectFolder: (String) -> Unit,
    onSelectArchive: () -> Unit,
    onSelectBin: () -> Unit,
    onNewFolder: () -> Unit,
    onRenameFolder: (String, String) -> Unit,
    onDeleteFolder: (String) -> Unit,
    onSettings: () -> Unit,
    closeDrawer: () -> Unit
) {
    Column(Modifier.padding(12.dp)) {
        Text("NoteFlow", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(12.dp))
        NavigationDrawerItem(
            label = { Text("All notes") },
            icon = { Icon(Icons.Outlined.Notes, null) },
            selected = selectedFolderId == null && !showingArchive && !showingBin && !favoritesOnly,
            onClick = { onSelectAll(); closeDrawer() }
        )
        NavigationDrawerItem(
            label = { Text("Favourites") },
            icon = { Icon(Icons.Outlined.StarOutline, null) },
            selected = favoritesOnly,
            onClick = { onSelectFavorites(); closeDrawer() }
        )
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        // Subfolders are shown indented under their parent. The tree is flattened first
        // (plain Kotlin, no recursive composable) into (folder, count, depth) rows.
        val flattened = remember(folders) { flattenFolders(folders) }
        flattened.forEach { (folder, countAndDepth) ->
            val (count, depth) = countAndDepth
            run {
                var menu by remember(folder.id) { mutableStateOf(false) }
                NavigationDrawerItem(
                    label = { Text(folder.name) },
                    icon = { Icon(Icons.Outlined.Folder, null) },
                    badge = {
                        // Count + an explicit overflow button, so tapping the row always
                        // selects the folder and only the button opens the menu.
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(count.toString())
                            Box {
                                IconButton(onClick = { menu = true }) {
                                    Icon(Icons.Filled.MoreVert, contentDescription = "Folder options")
                                }
                                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                    DropdownMenuItem(
                                        text = { Text("Rename folder") },
                                        onClick = { onRenameFolder(folder.id, folder.name); menu = false }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Delete folder (keeps notes)") },
                                        onClick = { onDeleteFolder(folder.id); menu = false }
                                    )
                                }
                            }
                        }
                    },
                    selected = selectedFolderId == folder.id,
                    onClick = { onSelectFolder(folder.id); closeDrawer() },
                    modifier = Modifier.padding(start = (depth * 14).dp)
                )
            }
        }

        NavigationDrawerItem(
            label = { Text("New folder") },
            icon = { Icon(Icons.Outlined.CreateNewFolder, null) },
            selected = false,
            onClick = { onNewFolder() }
        )
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        NavigationDrawerItem(
            label = { Text("Archive") },
            icon = { Icon(Icons.Outlined.Archive, null) },
            selected = showingArchive,
            onClick = { onSelectArchive(); closeDrawer() }
        )
        NavigationDrawerItem(
            label = { Text("Recycle bin") },
            icon = { Icon(Icons.Outlined.Delete, null) },
            selected = showingBin,
            onClick = { onSelectBin(); closeDrawer() }
        )
        NavigationDrawerItem(
            label = { Text("Settings") },
            icon = { Icon(Icons.Outlined.Settings, null) },
            selected = false,
            onClick = { onSettings(); closeDrawer() }
        )
    }
}

/** Depth-first flatten of the folder tree into (folder, (noteCount, depth)) rows. */
private fun flattenFolders(
    folders: List<Pair<app.noteflow.data.local.entity.FolderEntity, Int>>
): List<Pair<app.noteflow.data.local.entity.FolderEntity, Pair<Int, Int>>> {
    val byParent = folders.groupBy { it.first.parentId }
    val result = mutableListOf<Pair<app.noteflow.data.local.entity.FolderEntity, Pair<Int, Int>>>()
    fun walk(parentId: String?, depth: Int) {
        byParent[parentId].orEmpty().forEach { (folder, count) ->
            result += folder to (count to depth)
            walk(folder.id, depth + 1)
        }
    }
    walk(null, 0)
    return result
}

@Composable
private fun SortMenu(current: NoteSort, onSelect: (NoteSort) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Outlined.Sort, contentDescription = "Sort") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            NoteSort.entries.forEach { sort ->
                DropdownMenuItem(
                    text = { Text(sort.label) },
                    leadingIcon = { if (sort == current) Icon(Icons.Filled.Check, null) },
                    onClick = { onSelect(sort); open = false }
                )
            }
        }
    }
}

@Composable
private fun EmptyState(filter: HomeFilter, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Outlined.Notes, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.outline)
            Spacer(Modifier.height(12.dp))
            Text(
                when {
                    filter.showBin -> "The recycle bin is empty"
                    filter.query.isNotBlank() -> "No notes match \"${filter.query}\""
                    filter.archived -> "Nothing archived yet"
                    else -> "No notes yet — tap New note"
                },
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun TextPromptDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var value by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = { value = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().height(60.dp)
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(value) }) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
