# NoteFlow architecture

```
┌──────────────────────────── UI (Jetpack Compose) ────────────────────────────┐
│ ui/NoteFlowApp.kt      navigation + theme                                    │
│ ui/onboarding          first run (no account)                                │
│ ui/home                library: search, folders, tags, sort, bin             │
│ ui/editor              top bar, pen toolbar, page bar, bottom sheets         │
│ ui/settings            appearance, writing, backup, honest feature status    │
└───────────────▲──────────────────────────────────────────────▲───────────────┘
                │ StateFlow                                    │ AndroidView
┌───────────────┴──────────── Presentation ────────────────────┴───────────────┐
│ HomeViewModel     filters → repository flows                                 │
│ EditorViewModel   page loading, debounced autosave, save status, page ops    │
└───────────────▲──────────────────────────────────────────────▲───────────────┘
                │                                              │
┌───────────────┴──────── Domain (pure Kotlin, no Android) ────┴───────────────┐
│ domain/model/PageSpec.kt   mm ↔ pt, A2–A6, orientation, templates            │
│ domain/model/Ink.kt        Stroke / InkBrush / InkDocument (vector)          │
│ domain/beautify            HandwritingRefiner (geometric, offline)           │
└───────────────▲──────────────────────────────────────────────▲───────────────┘
                │                                              │
┌───────────────┴──────────── Rendering (ink/) ────────────────┴───────────────┐
│ InkCanvasView    MotionEvent, stylus/palm policy, gestures, modes            │
│ InkRenderer      7 pens, pressure & nib maths (shared with PDF export)       │
│ TemplateRenderer paper: lines, grids, Cornell, planner, music, engineering   │
│ StrokeSmoother   live filter + Catmull-Rom resampling                        │
│ InkHistory       command-based undo/redo                                     │
│ ShapeRecognizer  line/arrow/rect/triangle/ellipse snapping                   │
└───────────────▲──────────────────────────────────────────────▲───────────────┘
                │                                              │
┌───────────────┴──────────────── Data ────────────────────────┴───────────────┐
│ data/repository/NotesRepository   the only API the UI uses                   │
│ data/local        Room: entities, DAOs, database, migrations                 │
│ data/files        FileStore (atomic writes) + InkCodec (.nfink binary)       │
│ data/backup       BackupManager (validated JSON import/export)               │
│ data/settings     SettingsStore (DataStore)                                  │
│ export            PdfExporter (platform PdfDocument)                         │
└──────────────────────────────────────────────────────────────────────────────┘
```

## Key decisions

**Why a `View` for ink and Compose for everything else.** `MotionEvent` exposes batched
historical samples, per-pointer `getToolType`, pressure, `touchMajor` and stylus button
state. Drawing from these directly, outside recomposition, keeps the ink path short:
touch → filter → append to a `FloatArray` → `invalidate()`.

**Two storage systems, one owner.** SQLite holds small, queryable metadata; the file store
holds strokes. Only `NotesRepository` may touch both, so a deleted note can never leave
orphan ink files (and `pruneOrphans()` cleans up after a crash anyway).

**Vector in, vector out.** A stroke is stored as `[x, y, pressure, t]` samples in page
points. The same `InkRenderer` paints the screen and the PDF, so export is resolution
independent and the ink stays editable forever.

**Crash safety.** Every file write is `tmp` + atomic rename; the ink reader tolerates a
truncated file and returns whatever was complete; autosave is debounced and also flushed
on `ON_PAUSE` and in `onCleared()`.

**Migrations.** `fallbackToDestructiveMigration()` is never used. `Migrations.kt` holds the
template to copy for the first real schema change, and Room exports JSON schemas to
`app/schemas` so `MigrationTestHelper` can verify them.

**Process death.** The editor reloads purely from Room + the ink file on the next
composition, so a killed process costs at most the last autosave window (1–10 s, user
configurable).
